import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import ProjectManagement from './pages/project-management';
import VerificationWorkflow from './pages/verification-workflow';
import Dashboard from './pages/dashboard';
import BlockchainIntegration from './pages/blockchain-integration';
import ProjectRegistration from './pages/project-registration';
import MRVDashboard from './pages/mrv-dashboard';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<BlockchainIntegration />} />
        <Route path="/project-management" element={<ProjectManagement />} />
        <Route path="/verification-workflow" element={<VerificationWorkflow />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/blockchain-integration" element={<BlockchainIntegration />} />
        <Route path="/project-registration" element={<ProjectRegistration />} />
        <Route path="/mrv-dashboard" element={<MRVDashboard />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
