import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = ({ onMenuToggle, isMenuOpen = false }) => {
  const [isBlockchainConnected, setIsBlockchainConnected] = useState(false);
  const [userRole, setUserRole] = useState('admin');
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const location = useLocation();

  useEffect(() => {
    // Simulate blockchain connection status
    const checkConnection = () => {
      setIsBlockchainConnected(Math.random() > 0.3);
    };
    
    checkConnection();
    const interval = setInterval(checkConnection, 30000);
    return () => clearInterval(interval);
  }, []);

  const navigationItems = [
    { path: '/dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
    { path: '/project-registration', label: 'Register Project', icon: 'Plus' },
    { path: '/project-management', label: 'Projects', icon: 'FolderOpen' },
    { path: '/mrv-dashboard', label: 'MRV', icon: 'BarChart3' },
    { path: '/verification-workflow', label: 'Verification', icon: 'CheckCircle' }
  ];

  const moreItems = [
    { path: '/blockchain-integration', label: 'Blockchain', icon: 'Link' },
    { path: '/settings', label: 'Settings', icon: 'Settings' },
    { path: '/help', label: 'Help', icon: 'HelpCircle' }
  ];

  const handleLogout = () => {
    console.log('Logout clicked');
    setShowUserMenu(false);
  };

  const handleNavigation = (path) => {
    window.location.href = path;
    setShowMoreMenu(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-card border-b border-border z-1000">
      <div className="flex items-center justify-between h-full px-4">
        {/* Left Section - Logo and Navigation */}
        <div className="flex items-center space-x-8">
          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuToggle}
            className="lg:hidden"
          >
            <Icon name={isMenuOpen ? 'X' : 'Menu'} size={20} />
          </Button>

          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="Waves" size={20} color="white" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-semibold text-foreground">BlueCarbon</h1>
              <p className="text-xs text-muted-foreground -mt-1">Registry</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navigationItems?.map((item) => (
              <Button
                key={item?.path}
                variant={location?.pathname === item?.path ? 'default' : 'ghost'}
                size="sm"
                onClick={() => handleNavigation(item?.path)}
                iconName={item?.icon}
                iconPosition="left"
                iconSize={16}
                className="text-sm"
              >
                {item?.label}
              </Button>
            ))}
            
            {/* More Menu */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowMoreMenu(!showMoreMenu)}
                iconName="MoreHorizontal"
                iconSize={16}
              >
                More
              </Button>
              
              {showMoreMenu && (
                <div className="absolute top-full left-0 mt-1 w-48 bg-popover border border-border rounded-md shadow-modal z-1001">
                  <div className="py-1">
                    {moreItems?.map((item) => (
                      <button
                        key={item?.path}
                        onClick={() => handleNavigation(item?.path)}
                        className="flex items-center w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted transition-smooth"
                      >
                        <Icon name={item?.icon} size={16} className="mr-3" />
                        {item?.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </nav>
        </div>

        {/* Right Section - Status and User */}
        <div className="flex items-center space-x-4">
          {/* Blockchain Status */}
          <div className="hidden sm:flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isBlockchainConnected ? 'bg-success' : 'bg-error'}`} />
            <span className="text-sm text-muted-foreground">
              {isBlockchainConnected ? 'Connected' : 'Disconnected'}
            </span>
          </div>

          {/* Mobile Blockchain Status */}
          <div className="sm:hidden">
            <div className={`w-3 h-3 rounded-full ${isBlockchainConnected ? 'bg-success' : 'bg-error'}`} />
          </div>

          {/* User Menu */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-2"
            >
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Icon name="User" size={16} color="white" />
              </div>
              <span className="hidden md:block text-sm font-medium">Admin User</span>
              <Icon name="ChevronDown" size={16} />
            </Button>

            {showUserMenu && (
              <div className="absolute top-full right-0 mt-1 w-48 bg-popover border border-border rounded-md shadow-modal z-1001">
                <div className="py-1">
                  <div className="px-3 py-2 border-b border-border">
                    <p className="text-sm font-medium text-popover-foreground">Admin User</p>
                    <p className="text-xs text-muted-foreground">{userRole}</p>
                  </div>
                  <button
                    onClick={() => handleNavigation('/profile')}
                    className="flex items-center w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted transition-smooth"
                  >
                    <Icon name="User" size={16} className="mr-3" />
                    Profile
                  </button>
                  <button
                    onClick={() => handleNavigation('/settings')}
                    className="flex items-center w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted transition-smooth"
                  >
                    <Icon name="Settings" size={16} className="mr-3" />
                    Settings
                  </button>
                  <div className="border-t border-border">
                    <button
                      onClick={handleLogout}
                      className="flex items-center w-full px-3 py-2 text-sm text-destructive hover:bg-muted transition-smooth"
                    >
                      <Icon name="LogOut" size={16} className="mr-3" />
                      Logout
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Mobile Navigation Overlay */}
      {isMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-16 bg-background z-999">
          <nav className="p-4 space-y-2">
            {[...navigationItems, ...moreItems]?.map((item) => (
              <Button
                key={item?.path}
                variant={location?.pathname === item?.path ? 'default' : 'ghost'}
                size="sm"
                onClick={() => handleNavigation(item?.path)}
                iconName={item?.icon}
                iconPosition="left"
                iconSize={16}
                fullWidth
                className="justify-start"
              >
                {item?.label}
              </Button>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;