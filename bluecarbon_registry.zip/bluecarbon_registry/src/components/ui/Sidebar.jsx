import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Sidebar = ({ isCollapsed = false, onToggle }) => {
  const [userRole, setUserRole] = useState('admin');
  const [expandedGroups, setExpandedGroups] = useState(['projects', 'monitoring']);
  const location = useLocation();

  const navigationGroups = [
    {
      id: 'overview',
      label: 'Overview',
      items: [
        { path: '/dashboard', label: 'Dashboard', icon: 'LayoutDashboard', roles: ['admin', 'verifier', 'project_owner', 'public'] }
      ]
    },
    {
      id: 'projects',
      label: 'Projects',
      items: [
        { path: '/project-registration', label: 'Register Project', icon: 'Plus', roles: ['admin', 'project_owner'] },
        { path: '/project-management', label: 'Manage Projects', icon: 'FolderOpen', roles: ['admin', 'verifier', 'project_owner'] }
      ]
    },
    {
      id: 'monitoring',
      label: 'Monitoring & Verification',
      items: [
        { path: '/mrv-dashboard', label: 'MRV Dashboard', icon: 'BarChart3', roles: ['admin', 'verifier', 'project_owner'] },
        { path: '/verification-workflow', label: 'Verification', icon: 'CheckCircle', roles: ['admin', 'verifier'] }
      ]
    },
    {
      id: 'blockchain',
      label: 'Infrastructure',
      items: [
        { path: '/blockchain-integration', label: 'Blockchain', icon: 'Link', roles: ['admin'] }
      ]
    }
  ];

  const toggleGroup = (groupId) => {
    if (isCollapsed) return;
    
    setExpandedGroups(prev => 
      prev?.includes(groupId) 
        ? prev?.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };

  const handleNavigation = (path) => {
    window.location.href = path;
  };

  const isItemVisible = (item) => {
    return item?.roles?.includes(userRole);
  };

  const getActiveGroup = () => {
    for (const group of navigationGroups) {
      if (group?.items?.some(item => item?.path === location?.pathname)) {
        return group?.id;
      }
    }
    return null;
  };

  useEffect(() => {
    const activeGroup = getActiveGroup();
    if (activeGroup && !expandedGroups?.includes(activeGroup)) {
      setExpandedGroups(prev => [...prev, activeGroup]);
    }
  }, [location?.pathname]);

  return (
    <aside className={`fixed left-0 top-16 h-[calc(100vh-4rem)] bg-card border-r border-border z-999 transition-all duration-200 ${
      isCollapsed ? 'w-16' : 'w-60'
    }`}>
      <div className="flex flex-col h-full">
        {/* Collapse Toggle */}
        <div className="p-4 border-b border-border">
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggle}
            className="w-full justify-center"
          >
            <Icon name={isCollapsed ? 'ChevronRight' : 'ChevronLeft'} size={20} />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-2">
          <div className="space-y-1">
            {navigationGroups?.map((group) => {
              const visibleItems = group?.items?.filter(isItemVisible);
              if (visibleItems?.length === 0) return null;

              const isExpanded = expandedGroups?.includes(group?.id);
              const hasActiveItem = group?.items?.some(item => item?.path === location?.pathname);

              return (
                <div key={group?.id} className="mb-4">
                  {/* Group Header */}
                  {!isCollapsed && (
                    <button
                      onClick={() => toggleGroup(group?.id)}
                      className="flex items-center justify-between w-full px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-smooth"
                    >
                      <span>{group?.label}</span>
                      <Icon 
                        name="ChevronDown" 
                        size={16} 
                        className={`transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                      />
                    </button>
                  )}
                  {/* Group Items */}
                  <div className={`space-y-1 ${!isCollapsed && !isExpanded ? 'hidden' : ''}`}>
                    {visibleItems?.map((item) => {
                      const isActive = location?.pathname === item?.path;
                      
                      return (
                        <Button
                          key={item?.path}
                          variant={isActive ? 'default' : 'ghost'}
                          size="sm"
                          onClick={() => handleNavigation(item?.path)}
                          className={`w-full justify-start ${isCollapsed ? 'px-2' : 'px-3'}`}
                          title={isCollapsed ? item?.label : undefined}
                        >
                          <Icon name={item?.icon} size={18} className={isCollapsed ? '' : 'mr-3'} />
                          {!isCollapsed && (
                            <span className="text-sm">{item?.label}</span>
                          )}
                        </Button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </nav>

        {/* User Role Indicator */}
        {!isCollapsed && (
          <div className="p-4 border-t border-border">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Icon name="User" size={16} color="white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">Admin User</p>
                <p className="text-xs text-muted-foreground capitalize">{userRole?.replace('_', ' ')}</p>
              </div>
            </div>
          </div>
        )}

        {/* Collapsed User Indicator */}
        {isCollapsed && (
          <div className="p-4 border-t border-border flex justify-center">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <Icon name="User" size={16} color="white" />
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;