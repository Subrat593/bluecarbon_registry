import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const NetworkStatus = () => {
  const [networkStats, setNetworkStats] = useState({
    blockHeight: '45,678,923',
    gasPrice: '25.4',
    networkLoad: 'Medium',
    avgBlockTime: '2.1s',
    lastUpdate: new Date()?.toISOString()
  });

  const [connectionStatus, setConnectionStatus] = useState({
    rpc: 'connected',
    websocket: 'connected',
    ipfs: 'connected',
    subgraph: 'connected'
  });

  const networks = [
    {
      id: 'polygon-mumbai',
      name: 'Polygon Mumbai',
      chainId: '80001',
      rpcUrl: 'https://rpc-mumbai.maticvigil.com',
      explorerUrl: 'https://mumbai.polygonscan.com',
      status: 'active',
      isTestnet: true
    },
    {
      id: 'polygon-mainnet',
      name: 'Polygon Mainnet',
      chainId: '137',
      rpcUrl: 'https://polygon-rpc.com',
      explorerUrl: 'https://polygonscan.com',
      status: 'available',
      isTestnet: false
    },
    {
      id: 'ethereum-goerli',
      name: 'Ethereum Goerli',
      chainId: '5',
      rpcUrl: 'https://goerli.infura.io/v3/...',
      explorerUrl: 'https://goerli.etherscan.io',
      status: 'available',
      isTestnet: true
    }
  ];

  useEffect(() => {
    // Simulate real-time network updates
    const interval = setInterval(() => {
      setNetworkStats(prev => ({
        ...prev,
        blockHeight: (parseInt(prev?.blockHeight?.replace(',', '')) + Math.floor(Math.random() * 3) + 1)?.toLocaleString(),
        gasPrice: (parseFloat(prev?.gasPrice) + (Math.random() - 0.5) * 2)?.toFixed(1),
        lastUpdate: new Date()?.toISOString()
      }));

      // Simulate occasional connection issues
      if (Math.random() < 0.1) {
        const services = ['rpc', 'websocket', 'ipfs', 'subgraph'];
        const randomService = services?.[Math.floor(Math.random() * services?.length)];
        setConnectionStatus(prev => ({
          ...prev,
          [randomService]: Math.random() > 0.5 ? 'connected' : 'disconnected'
        }));
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': case'active': return 'text-success';
      case 'disconnected': return 'text-destructive';
      case 'available': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case 'connected': case'active': return 'bg-success';
      case 'disconnected': return 'bg-destructive';
      case 'available': return 'bg-muted-foreground';
      default: return 'bg-muted-foreground';
    }
  };

  const getLoadColor = (load) => {
    switch (load?.toLowerCase()) {
      case 'low': return 'text-success';
      case 'medium': return 'text-warning';
      case 'high': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const handleSwitchNetwork = (networkId) => {
    console.log(`Switching to network: ${networkId}`);
    // In a real app, this would trigger wallet network switch
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Icon name="Globe" size={24} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Network Status</h3>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
          <span className="text-sm text-muted-foreground">
            Live • Updated {formatDate(networkStats?.lastUpdate)}
          </span>
        </div>
      </div>
      <div className="space-y-6">
        {/* Current Network Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Block Height</span>
              <Icon name="Blocks" size={16} className="text-muted-foreground" />
            </div>
            <span className="text-lg font-semibold text-foreground">{networkStats?.blockHeight}</span>
          </div>

          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Gas Price</span>
              <Icon name="Fuel" size={16} className="text-muted-foreground" />
            </div>
            <div className="flex items-baseline space-x-1">
              <span className="text-lg font-semibold text-foreground">{networkStats?.gasPrice}</span>
              <span className="text-sm text-muted-foreground">gwei</span>
            </div>
          </div>

          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Network Load</span>
              <Icon name="Activity" size={16} className="text-muted-foreground" />
            </div>
            <span className={`text-lg font-semibold ${getLoadColor(networkStats?.networkLoad)}`}>
              {networkStats?.networkLoad}
            </span>
          </div>

          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Block Time</span>
              <Icon name="Clock" size={16} className="text-muted-foreground" />
            </div>
            <span className="text-lg font-semibold text-foreground">{networkStats?.avgBlockTime}</span>
          </div>
        </div>

        {/* Service Status */}
        <div className="border border-border rounded-lg p-4">
          <h4 className="text-md font-medium text-foreground mb-4">Service Status</h4>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(connectionStatus)?.map(([service, status]) => (
              <div key={service} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${getStatusBg(status)}`} />
                  <span className="text-sm font-medium text-foreground capitalize">
                    {service === 'rpc' ? 'RPC' : service}
                  </span>
                </div>
                <span className={`text-xs font-medium ${getStatusColor(status)}`}>
                  {status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Available Networks */}
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-md font-medium text-foreground">Available Networks</h4>
            <Button
              variant="ghost"
              size="sm"
              iconName="RefreshCw"
              iconPosition="left"
              onClick={() => window.location?.reload()}
            >
              Refresh
            </Button>
          </div>
          
          <div className="space-y-3">
            {networks?.map((network) => (
              <div key={network?.id} className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${getStatusBg(network?.status)}`} />
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-foreground">{network?.name}</span>
                      {network?.isTestnet && (
                        <span className="px-2 py-1 bg-warning/10 text-warning text-xs rounded-full font-medium">
                          Testnet
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                      <span>Chain ID: {network?.chainId}</span>
                      <span>•</span>
                      <span className={`${getStatusColor(network?.status)} font-medium`}>
                        {network?.status}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="xs"
                    onClick={() => window.open(network?.explorerUrl, '_blank')}
                    iconName="ExternalLink"
                    iconSize={14}
                  >
                    Explorer
                  </Button>
                  {network?.status === 'available' && (
                    <Button
                      variant="outline"
                      size="xs"
                      onClick={() => handleSwitchNetwork(network?.id)}
                      iconName="ArrowRightLeft"
                      iconSize={14}
                    >
                      Switch
                    </Button>
                  )}
                  {network?.status === 'active' && (
                    <span className="px-2 py-1 bg-success/10 text-success text-xs rounded-full font-medium">
                      Active
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            variant="outline"
            onClick={() => window.open('https://mumbai.polygonscan.com', '_blank')}
            iconName="ExternalLink"
            iconPosition="left"
            fullWidth
          >
            View Block Explorer
          </Button>
          <Button
            variant="outline"
            onClick={() => window.open('https://faucet.polygon.technology', '_blank')}
            iconName="Droplets"
            iconPosition="left"
            fullWidth
          >
            Get Test Tokens
          </Button>
          <Button
            variant="outline"
            onClick={() => navigator.clipboard?.writeText(networks?.[0]?.rpcUrl)}
            iconName="Copy"
            iconPosition="left"
            fullWidth
          >
            Copy RPC URL
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NetworkStatus;