import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const SmartContractPanel = ({ isWalletConnected }) => {
  const [selectedContract, setSelectedContract] = useState('carbon-registry');
  const [projectHash, setProjectHash] = useState('');
  const [isDeploying, setIsDeploying] = useState(false);
  const [isStoring, setIsStoring] = useState(false);
  const [deployedContracts, setDeployedContracts] = useState([
    {
      id: 'carbon-registry',
      name: 'Carbon Registry',
      address: '0x1234567890123456789012345678901234567890',
      status: 'deployed',
      gasUsed: '2,450,000',
      deployedAt: '2025-08-30T10:30:00Z'
    },
    {
      id: 'carbon-token',
      name: 'Carbon Token (ERC-20)',
      address: '0x0987654321098765432109876543210987654321',
      status: 'deployed',
      gasUsed: '1,850,000',
      deployedAt: '2025-08-30T09:15:00Z'
    }
  ]);

  const contractTemplates = [
    {
      id: 'carbon-registry',
      name: 'Carbon Registry',
      description: 'Main registry contract for project registration and verification',
      functions: ['registerProject', 'verifyProject', 'getProjectDetails']
    },
    {
      id: 'carbon-token',
      name: 'Carbon Token (ERC-20)',
      description: 'ERC-20 token contract for carbon credit tokenization',
      functions: ['mint', 'transfer', 'burn', 'balanceOf']
    },
    {
      id: 'verification',
      name: 'Verification Contract',
      description: 'Smart contract for MRV data verification and validation',
      functions: ['submitMRVData', 'validateData', 'approveVerification']
    }
  ];

  const handleDeployContract = async () => {
    if (!isWalletConnected) return;
    
    setIsDeploying(true);
    
    // Simulate contract deployment
    setTimeout(() => {
      const newContract = {
        id: `contract-${Date.now()}`,
        name: contractTemplates?.find(c => c?.id === selectedContract)?.name || 'New Contract',
        address: `0x${Math.random()?.toString(16)?.substr(2, 40)}`,
        status: 'deployed',
        gasUsed: `${Math.floor(Math.random() * 1000000 + 1500000)?.toLocaleString()}`,
        deployedAt: new Date()?.toISOString()
      };
      
      setDeployedContracts(prev => [...prev, newContract]);
      setIsDeploying(false);
    }, 3000);
  };

  const handleStoreProjectHash = async () => {
    if (!isWalletConnected || !projectHash) return;
    
    setIsStoring(true);
    
    // Simulate storing project hash
    setTimeout(() => {
      setProjectHash('');
      setIsStoring(false);
    }, 2000);
  };

  const formatAddress = (address) => {
    return `${address?.slice(0, 6)}...${address?.slice(-4)}`;
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Icon name="FileCode" size={24} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Smart Contract Management</h3>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${isWalletConnected ? 'bg-success' : 'bg-error'}`} />
          <span className="text-sm text-muted-foreground">
            {isWalletConnected ? 'Connected' : 'Disconnected'}
          </span>
        </div>
      </div>
      {!isWalletConnected ? (
        <div className="text-center py-8">
          <Icon name="AlertCircle" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h4 className="text-lg font-medium text-foreground mb-2">Wallet Required</h4>
          <p className="text-muted-foreground">
            Please connect your wallet to interact with smart contracts
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Contract Deployment */}
          <div className="border border-border rounded-lg p-4">
            <h4 className="text-md font-medium text-foreground mb-4">Deploy New Contract</h4>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Contract Template
                </label>
                <select
                  value={selectedContract}
                  onChange={(e) => setSelectedContract(e?.target?.value)}
                  className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground focus:ring-2 focus:ring-ring focus:border-transparent"
                >
                  {contractTemplates?.map((template) => (
                    <option key={template?.id} value={template?.id}>
                      {template?.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="flex items-end">
                <Button
                  variant="default"
                  onClick={handleDeployContract}
                  loading={isDeploying}
                  iconName="Rocket"
                  iconPosition="left"
                  fullWidth
                >
                  {isDeploying ? 'Deploying...' : 'Deploy Contract'}
                </Button>
              </div>
            </div>

            {selectedContract && (
              <div className="bg-muted rounded-lg p-3">
                <p className="text-sm text-muted-foreground mb-2">
                  {contractTemplates?.find(c => c?.id === selectedContract)?.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {contractTemplates?.find(c => c?.id === selectedContract)?.functions?.map((func) => (
                    <span
                      key={func}
                      className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-md font-mono"
                    >
                      {func}()
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Project Hash Storage */}
          <div className="border border-border rounded-lg p-4">
            <h4 className="text-md font-medium text-foreground mb-4">Store Project Hash</h4>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1">
                <Input
                  type="text"
                  placeholder="Enter project hash (e.g., QmX1Y2Z3...)"
                  value={projectHash}
                  onChange={(e) => setProjectHash(e?.target?.value)}
                />
              </div>
              <Button
                variant="outline"
                onClick={handleStoreProjectHash}
                loading={isStoring}
                disabled={!projectHash}
                iconName="Database"
                iconPosition="left"
              >
                {isStoring ? 'Storing...' : 'Store Hash'}
              </Button>
            </div>
            
            <p className="text-xs text-muted-foreground mt-2">
              Store IPFS hash or project identifier on the blockchain for immutable record keeping
            </p>
          </div>

          {/* Deployed Contracts */}
          <div className="border border-border rounded-lg p-4">
            <h4 className="text-md font-medium text-foreground mb-4">Deployed Contracts</h4>
            
            <div className="space-y-3">
              {deployedContracts?.map((contract) => (
                <div key={contract?.id} className="bg-muted rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h5 className="font-medium text-foreground">{contract?.name}</h5>
                      <p className="text-sm text-muted-foreground font-mono">
                        {formatAddress(contract?.address)}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-success rounded-full" />
                      <span className="text-xs text-success font-medium">Active</span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-xs text-muted-foreground">
                    <div>
                      <span className="block">Gas Used</span>
                      <span className="font-medium text-foreground">{contract?.gasUsed}</span>
                    </div>
                    <div>
                      <span className="block">Deployed</span>
                      <span className="font-medium text-foreground">{formatDate(contract?.deployedAt)}</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-3">
                    <Button
                      variant="ghost"
                      size="xs"
                      onClick={() => navigator.clipboard?.writeText(contract?.address)}
                      iconName="Copy"
                      iconSize={14}
                    >
                      Copy Address
                    </Button>
                    <Button
                      variant="ghost"
                      size="xs"
                      onClick={() => window.open(`https://mumbai.polygonscan.com/address/${contract?.address}`, '_blank')}
                      iconName="ExternalLink"
                      iconSize={14}
                    >
                      View on Explorer
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SmartContractPanel;