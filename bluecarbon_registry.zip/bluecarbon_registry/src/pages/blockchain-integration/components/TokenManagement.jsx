import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const TokenManagement = ({ isWalletConnected }) => {
  const [tokenBalance, setTokenBalance] = useState('1,250.75');
  const [mintAmount, setMintAmount] = useState('');
  const [transferAddress, setTransferAddress] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [isMinting, setIsMinting] = useState(false);
  const [isTransferring, setIsTransferring] = useState(false);

  const tokenStats = [
    { label: 'Total Supply', value: '50,000', unit: 'BCC', change: '+2.5%' },
    { label: 'Circulating', value: '35,750', unit: 'BCC', change: '+1.8%' },
    { label: 'Your Balance', value: tokenBalance, unit: 'BCC', change: '+5.2%' },
    { label: 'USD Value', value: '$12,507.50', unit: '', change: '+3.1%' }
  ];

  const recentTransactions = [
    {
      id: '1',
      type: 'mint',
      amount: '500.00',
      to: '0x742d35Cc...8D4',
      hash: '0xabcd1234...5678',
      timestamp: '2025-08-30T16:45:00Z',
      status: 'confirmed'
    },
    {
      id: '2',
      type: 'transfer',
      amount: '250.25',
      to: '0x9876543...321',
      hash: '0xefgh5678...9012',
      timestamp: '2025-08-30T15:30:00Z',
      status: 'confirmed'
    },
    {
      id: '3',
      type: 'burn',
      amount: '100.00',
      to: '0x0000000...000',
      hash: '0xijkl9012...3456',
      timestamp: '2025-08-30T14:15:00Z',
      status: 'confirmed'
    }
  ];

  const handleMintTokens = async () => {
    if (!isWalletConnected || !mintAmount) return;
    
    setIsMinting(true);
    
    // Simulate minting process
    setTimeout(() => {
      const currentBalance = parseFloat(tokenBalance?.replace(',', ''));
      const newBalance = currentBalance + parseFloat(mintAmount);
      setTokenBalance(newBalance?.toLocaleString('en-US', { minimumFractionDigits: 2 }));
      setMintAmount('');
      setIsMinting(false);
    }, 3000);
  };

  const handleTransferTokens = async () => {
    if (!isWalletConnected || !transferAddress || !transferAmount) return;
    
    setIsTransferring(true);
    
    // Simulate transfer process
    setTimeout(() => {
      const currentBalance = parseFloat(tokenBalance?.replace(',', ''));
      const newBalance = currentBalance - parseFloat(transferAmount);
      setTokenBalance(newBalance?.toLocaleString('en-US', { minimumFractionDigits: 2 }));
      setTransferAddress('');
      setTransferAmount('');
      setIsTransferring(false);
    }, 2500);
  };

  const formatAddress = (address) => {
    return `${address?.slice(0, 6)}...${address?.slice(-4)}`;
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTransactionIcon = (type) => {
    switch (type) {
      case 'mint': return 'Plus';
      case 'transfer': return 'Send';
      case 'burn': return 'Flame';
      default: return 'ArrowRight';
    }
  };

  const getTransactionColor = (type) => {
    switch (type) {
      case 'mint': return 'text-success';
      case 'transfer': return 'text-primary';
      case 'burn': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Icon name="Coins" size={24} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Token Management</h3>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm font-medium text-foreground">BCC</span>
          <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
            <Icon name="Leaf" size={14} color="white" />
          </div>
        </div>
      </div>
      {!isWalletConnected ? (
        <div className="text-center py-8">
          <Icon name="Wallet" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h4 className="text-lg font-medium text-foreground mb-2">Wallet Required</h4>
          <p className="text-muted-foreground">
            Connect your wallet to manage carbon credit tokens
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Token Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {tokenStats?.map((stat, index) => (
              <div key={index} className="bg-muted rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">{stat?.label}</span>
                  <span className={`text-xs font-medium ${
                    stat?.change?.startsWith('+') ? 'text-success' : 'text-destructive'
                  }`}>
                    {stat?.change}
                  </span>
                </div>
                <div className="flex items-baseline space-x-1">
                  <span className="text-lg font-semibold text-foreground">{stat?.value}</span>
                  {stat?.unit && (
                    <span className="text-sm text-muted-foreground">{stat?.unit}</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Token Operations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Mint Tokens */}
            <div className="border border-border rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-4">
                <Icon name="Plus" size={20} className="text-success" />
                <h4 className="text-md font-medium text-foreground">Mint Tokens</h4>
              </div>
              
              <div className="space-y-3">
                <Input
                  type="number"
                  label="Amount to Mint"
                  placeholder="Enter amount"
                  value={mintAmount}
                  onChange={(e) => setMintAmount(e?.target?.value)}
                />
                
                <Button
                  variant="default"
                  onClick={handleMintTokens}
                  loading={isMinting}
                  disabled={!mintAmount}
                  iconName="Plus"
                  iconPosition="left"
                  fullWidth
                >
                  {isMinting ? 'Minting...' : 'Mint Tokens'}
                </Button>
                
                <p className="text-xs text-muted-foreground">
                  Mint new carbon credit tokens for verified projects
                </p>
              </div>
            </div>

            {/* Transfer Tokens */}
            <div className="border border-border rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-4">
                <Icon name="Send" size={20} className="text-primary" />
                <h4 className="text-md font-medium text-foreground">Transfer Tokens</h4>
              </div>
              
              <div className="space-y-3">
                <Input
                  type="text"
                  label="Recipient Address"
                  placeholder="0x..."
                  value={transferAddress}
                  onChange={(e) => setTransferAddress(e?.target?.value)}
                />
                
                <Input
                  type="number"
                  label="Amount"
                  placeholder="Enter amount"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e?.target?.value)}
                />
                
                <Button
                  variant="outline"
                  onClick={handleTransferTokens}
                  loading={isTransferring}
                  disabled={!transferAddress || !transferAmount}
                  iconName="Send"
                  iconPosition="left"
                  fullWidth
                >
                  {isTransferring ? 'Transferring...' : 'Transfer Tokens'}
                </Button>
                
                <p className="text-xs text-muted-foreground">
                  Transfer tokens to another wallet address
                </p>
              </div>
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-md font-medium text-foreground">Recent Transactions</h4>
              <Button
                variant="ghost"
                size="sm"
                iconName="ExternalLink"
                iconPosition="left"
                onClick={() => window.open('https://mumbai.polygonscan.com', '_blank')}
              >
                View All
              </Button>
            </div>
            
            <div className="space-y-3">
              {recentTransactions?.map((tx) => (
                <div key={tx?.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full bg-background flex items-center justify-center`}>
                      <Icon 
                        name={getTransactionIcon(tx?.type)} 
                        size={16} 
                        className={getTransactionColor(tx?.type)}
                      />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-foreground capitalize">
                          {tx?.type}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {tx?.amount} BCC
                        </span>
                      </div>
                      <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                        <span>To: {formatAddress(tx?.to)}</span>
                        <span>•</span>
                        <span>{formatDate(tx?.timestamp)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full" />
                    <Button
                      variant="ghost"
                      size="xs"
                      onClick={() => window.open(`https://mumbai.polygonscan.com/tx/${tx?.hash}`, '_blank')}
                      iconName="ExternalLink"
                      iconSize={12}
                    >
                      View
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TokenManagement;