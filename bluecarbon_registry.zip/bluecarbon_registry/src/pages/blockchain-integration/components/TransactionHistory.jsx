import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const TransactionHistory = ({ isWalletConnected }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const transactions = [
    {
      id: '1',
      hash: '0xabcd1234567890abcd1234567890abcd12345678',
      type: 'contract_deployment',
      description: 'Deploy Carbon Registry Contract',
      amount: '0.0',
      gasUsed: '2,450,000',
      gasFee: '0.0245',
      status: 'confirmed',
      timestamp: '2025-08-30T16:45:00Z',
      blockNumber: '45,678,901'
    },
    {
      id: '2',
      hash: '0xefgh5678901234efgh5678901234efgh56789012',
      type: 'token_mint',
      description: 'Mint Carbon Credits for Project #BC-001',
      amount: '500.00',
      gasUsed: '180,000',
      gasFee: '0.0018',
      status: 'confirmed',
      timestamp: '2025-08-30T15:30:00Z',
      blockNumber: '45,678,856'
    },
    {
      id: '3',
      hash: '0xijkl9012345678ijkl9012345678ijkl90123456',
      type: 'token_transfer',
      description: 'Transfer to 0x9876...4321',
      amount: '250.25',
      gasUsed: '65,000',
      gasFee: '0.00065',
      status: 'confirmed',
      timestamp: '2025-08-30T14:15:00Z',
      blockNumber: '45,678,789'
    },
    {
      id: '4',
      hash: '0xmnop3456789012mnop3456789012mnop34567890',
      type: 'project_verification',
      description: 'Store Project Verification Hash',
      amount: '0.0',
      gasUsed: '120,000',
      gasFee: '0.0012',
      status: 'confirmed',
      timestamp: '2025-08-30T13:00:00Z',
      blockNumber: '45,678,723'
    },
    {
      id: '5',
      hash: '0xqrst7890123456qrst7890123456qrst78901234',
      type: 'token_burn',
      description: 'Burn Retired Carbon Credits',
      amount: '100.00',
      gasUsed: '95,000',
      gasFee: '0.00095',
      status: 'confirmed',
      timestamp: '2025-08-30T12:30:00Z',
      blockNumber: '45,678,698'
    },
    {
      id: '6',
      hash: '0xuvwx1234567890uvwx1234567890uvwx12345678',
      type: 'contract_interaction',
      description: 'Update Project Status',
      amount: '0.0',
      gasUsed: '85,000',
      gasFee: '0.00085',
      status: 'pending',
      timestamp: '2025-08-30T11:45:00Z',
      blockNumber: '45,678,645'
    }
  ];

  const transactionTypes = [
    { value: 'all', label: 'All Transactions' },
    { value: 'contract_deployment', label: 'Contract Deployment' },
    { value: 'token_mint', label: 'Token Mint' },
    { value: 'token_transfer', label: 'Token Transfer' },
    { value: 'token_burn', label: 'Token Burn' },
    { value: 'project_verification', label: 'Project Verification' },
    { value: 'contract_interaction', label: 'Contract Interaction' }
  ];

  const filteredTransactions = transactions?.filter(tx => {
    const matchesSearch = tx?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         tx?.hash?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    const matchesType = filterType === 'all' || tx?.type === filterType;
    return matchesSearch && matchesType;
  });

  const totalPages = Math.ceil(filteredTransactions?.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedTransactions = filteredTransactions?.slice(startIndex, startIndex + itemsPerPage);

  const formatAddress = (address) => {
    return `${address?.slice(0, 8)}...${address?.slice(-8)}`;
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTransactionIcon = (type) => {
    switch (type) {
      case 'contract_deployment': return 'Rocket';
      case 'token_mint': return 'Plus';
      case 'token_transfer': return 'Send';
      case 'token_burn': return 'Flame';
      case 'project_verification': return 'CheckCircle';
      case 'contract_interaction': return 'Settings';
      default: return 'ArrowRight';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed': return 'text-success';
      case 'pending': return 'text-warning';
      case 'failed': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case 'confirmed': return 'bg-success/10';
      case 'pending': return 'bg-warning/10';
      case 'failed': return 'bg-destructive/10';
      default: return 'bg-muted';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Icon name="History" size={24} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Transaction History</h3>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">
            {filteredTransactions?.length} transactions
          </span>
        </div>
      </div>
      {!isWalletConnected ? (
        <div className="text-center py-8">
          <Icon name="Clock" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h4 className="text-lg font-medium text-foreground mb-2">No Transaction History</h4>
          <p className="text-muted-foreground">
            Connect your wallet to view transaction history
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <Input
                type="search"
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e?.target?.value)}
              />
            </div>
            <div className="sm:w-48">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e?.target?.value)}
                className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground focus:ring-2 focus:ring-ring focus:border-transparent"
              >
                {transactionTypes?.map((type) => (
                  <option key={type?.value} value={type?.value}>
                    {type?.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Transaction List */}
          <div className="space-y-3">
            {paginatedTransactions?.length === 0 ? (
              <div className="text-center py-8">
                <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h4 className="text-lg font-medium text-foreground mb-2">No Results Found</h4>
                <p className="text-muted-foreground">
                  Try adjusting your search or filter criteria
                </p>
              </div>
            ) : (
              paginatedTransactions?.map((tx) => (
                <div key={tx?.id} className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-smooth">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Icon 
                          name={getTransactionIcon(tx?.type)} 
                          size={20} 
                          className="text-primary"
                        />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-foreground mb-1">{tx?.description}</h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span className="font-mono">{formatAddress(tx?.hash)}</span>
                          <span>•</span>
                          <span>{formatDate(tx?.timestamp)}</span>
                          <span>•</span>
                          <span>Block #{tx?.blockNumber}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {tx?.amount !== '0.0' && (
                        <div className="text-right">
                          <div className="text-sm font-medium text-foreground">
                            {tx?.amount} BCC
                          </div>
                        </div>
                      )}
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBg(tx?.status)} ${getStatusColor(tx?.status)}`}>
                        {tx?.status}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-6 text-xs text-muted-foreground">
                      <div>
                        <span className="block">Gas Used</span>
                        <span className="font-medium text-foreground">{tx?.gasUsed}</span>
                      </div>
                      <div>
                        <span className="block">Gas Fee</span>
                        <span className="font-medium text-foreground">{tx?.gasFee} MATIC</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="xs"
                        onClick={() => navigator.clipboard?.writeText(tx?.hash)}
                        iconName="Copy"
                        iconSize={14}
                      >
                        Copy Hash
                      </Button>
                      <Button
                        variant="ghost"
                        size="xs"
                        onClick={() => window.open(`https://mumbai.polygonscan.com/tx/${tx?.hash}`, '_blank')}
                        iconName="ExternalLink"
                        iconSize={14}
                      >
                        View
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                Showing {startIndex + 1}-{Math.min(startIndex + itemsPerPage, filteredTransactions?.length)} of {filteredTransactions?.length}
              </div>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  iconName="ChevronLeft"
                  iconSize={16}
                >
                  Previous
                </Button>
                
                <div className="flex items-center space-x-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1)?.map((page) => (
                    <Button
                      key={page}
                      variant={currentPage === page ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                      className="w-8 h-8 p-0"
                    >
                      {page}
                    </Button>
                  ))}
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  iconName="ChevronRight"
                  iconSize={16}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default TransactionHistory;