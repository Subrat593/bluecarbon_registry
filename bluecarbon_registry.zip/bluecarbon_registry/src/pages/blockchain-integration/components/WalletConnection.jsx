import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const WalletConnection = ({ onConnectionChange }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');
  const [balance, setBalance] = useState('0.0');
  const [network, setNetwork] = useState('Polygon Testnet');
  const [isConnecting, setIsConnecting] = useState(false);

  // Mock wallet data
  const mockWalletData = {
    address: '0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4',
    balance: '2.4567',
    network: 'Polygon Testnet',
    chainId: '80001'
  };

  useEffect(() => {
    // Simulate checking for existing wallet connection
    const checkConnection = () => {
      const connected = Math.random() > 0.5;
      setIsConnected(connected);
      if (connected) {
        setWalletAddress(mockWalletData?.address);
        setBalance(mockWalletData?.balance);
        setNetwork(mockWalletData?.network);
      }
      onConnectionChange?.(connected);
    };

    checkConnection();
  }, [onConnectionChange]);

  const handleConnect = async () => {
    setIsConnecting(true);
    
    // Simulate wallet connection
    setTimeout(() => {
      setIsConnected(true);
      setWalletAddress(mockWalletData?.address);
      setBalance(mockWalletData?.balance);
      setNetwork(mockWalletData?.network);
      setIsConnecting(false);
      onConnectionChange?.(true);
    }, 2000);
  };

  const handleDisconnect = () => {
    setIsConnected(false);
    setWalletAddress('');
    setBalance('0.0');
    setNetwork('');
    onConnectionChange?.(false);
  };

  const formatAddress = (address) => {
    if (!address) return '';
    return `${address?.slice(0, 6)}...${address?.slice(-4)}`;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-success' : 'bg-error'}`} />
          <h3 className="text-lg font-semibold text-foreground">Wallet Connection</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Icon name="Wallet" size={20} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground">MetaMask</span>
        </div>
      </div>
      {!isConnected ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Wallet" size={32} className="text-muted-foreground" />
          </div>
          <h4 className="text-lg font-medium text-foreground mb-2">Connect Your Wallet</h4>
          <p className="text-muted-foreground mb-6">
            Connect your Web3 wallet to interact with blockchain features
          </p>
          <Button
            variant="default"
            onClick={handleConnect}
            loading={isConnecting}
            iconName="Link"
            iconPosition="left"
            className="px-8"
          >
            {isConnecting ? 'Connecting...' : 'Connect Wallet'}
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Wallet Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-muted rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Address</span>
                <Button
                  variant="ghost"
                  size="xs"
                  onClick={() => navigator.clipboard?.writeText(walletAddress)}
                  iconName="Copy"
                  iconSize={14}
                >
                  Copy
                </Button>
              </div>
              <p className="font-mono text-sm text-foreground">{formatAddress(walletAddress)}</p>
            </div>

            <div className="bg-muted rounded-lg p-4">
              <span className="text-sm text-muted-foreground block mb-2">Balance</span>
              <div className="flex items-center space-x-2">
                <p className="text-lg font-semibold text-foreground">{balance}</p>
                <span className="text-sm text-muted-foreground">MATIC</span>
              </div>
            </div>
          </div>

          {/* Network Info */}
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm text-muted-foreground block mb-1">Network</span>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-success rounded-full" />
                  <span className="text-sm font-medium text-foreground">{network}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-sm text-muted-foreground block mb-1">Chain ID</span>
                <span className="text-sm font-medium text-foreground">{mockWalletData?.chainId}</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => window.open(`https://mumbai.polygonscan.com/address/${walletAddress}`, '_blank')}
              iconName="ExternalLink"
              iconPosition="left"
              fullWidth
            >
              View on Explorer
            </Button>
            <Button
              variant="destructive"
              onClick={handleDisconnect}
              iconName="Unlink"
              iconPosition="left"
              fullWidth
            >
              Disconnect
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default WalletConnection;