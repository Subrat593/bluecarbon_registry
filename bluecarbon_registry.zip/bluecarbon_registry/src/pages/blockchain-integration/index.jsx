import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import WalletConnection from './components/WalletConnection';
import SmartContractPanel from './components/SmartContractPanel';
import TokenManagement from './components/TokenManagement';
import TransactionHistory from './components/TransactionHistory';
import NetworkStatus from './components/NetworkStatus';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const BlockchainIntegration = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isWalletConnected, setIsWalletConnected] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'LayoutDashboard' },
    { id: 'contracts', label: 'Smart Contracts', icon: 'FileCode' },
    { id: 'tokens', label: 'Token Management', icon: 'Coins' },
    { id: 'transactions', label: 'Transactions', icon: 'History' },
    { id: 'network', label: 'Network Status', icon: 'Globe' }
  ];

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleWalletConnectionChange = (connected) => {
    setIsWalletConnected(connected);
  };

  useEffect(() => {
    // Close mobile menu when clicking outside
    const handleClickOutside = (event) => {
      if (isMobileMenuOpen && !event?.target?.closest('aside') && !event?.target?.closest('button[aria-label="Toggle menu"]')) {
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMobileMenuOpen]);

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            <WalletConnection onConnectionChange={handleWalletConnectionChange} />
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <SmartContractPanel isWalletConnected={isWalletConnected} />
              <TokenManagement isWalletConnected={isWalletConnected} />
            </div>
          </div>
        );
      case 'contracts':
        return <SmartContractPanel isWalletConnected={isWalletConnected} />;
      case 'tokens':
        return <TokenManagement isWalletConnected={isWalletConnected} />;
      case 'transactions':
        return <TransactionHistory isWalletConnected={isWalletConnected} />;
      case 'network':
        return <NetworkStatus />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Blockchain Integration - BlueCarbon Registry</title>
        <meta name="description" content="Manage Web3 connectivity, smart contracts, and tokenization processes for verified carbon credits" />
      </Helmet>
      {/* Header */}
      <Header 
        onMenuToggle={handleMobileMenuToggle}
        isMenuOpen={isMobileMenuOpen}
      />
      {/* Sidebar */}
      <Sidebar 
        isCollapsed={isSidebarCollapsed}
        onToggle={handleSidebarToggle}
      />
      {/* Main Content */}
      <main className={`pt-16 transition-all duration-200 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
      }`}>
        <div className="p-6">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="Link" size={24} color="white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Blockchain Integration</h1>
                <p className="text-muted-foreground">
                  Manage Web3 connectivity, smart contracts, and tokenization processes
                </p>
              </div>
            </div>

            {/* Connection Status Banner */}
            <div className={`mt-4 p-4 rounded-lg border ${
              isWalletConnected 
                ? 'bg-success/10 border-success/20 text-success' :'bg-warning/10 border-warning/20 text-warning'
            }`}>
              <div className="flex items-center space-x-3">
                <Icon 
                  name={isWalletConnected ? 'CheckCircle' : 'AlertTriangle'} 
                  size={20} 
                />
                <div>
                  <p className="font-medium">
                    {isWalletConnected ? 'Blockchain Connected' : 'Wallet Connection Required'}
                  </p>
                  <p className="text-sm opacity-80">
                    {isWalletConnected 
                      ? 'Your wallet is connected and ready for blockchain operations'
                      : 'Connect your Web3 wallet to access blockchain features'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="mb-6">
            <div className="border-b border-border">
              <nav className="flex space-x-8 overflow-x-auto">
                {tabs?.map((tab) => (
                  <button
                    key={tab?.id}
                    onClick={() => setActiveTab(tab?.id)}
                    className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors ${
                      activeTab === tab?.id
                        ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground'
                    }`}
                  >
                    <Icon name={tab?.icon} size={18} />
                    <span>{tab?.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          <div className="space-y-6">
            {renderTabContent()}
          </div>

          {/* Quick Actions Footer */}
          <div className="mt-12 p-6 bg-muted rounded-lg">
            <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                variant="outline"
                onClick={() => window.open('https://docs.polygon.technology/', '_blank')}
                iconName="BookOpen"
                iconPosition="left"
                fullWidth
              >
                Documentation
              </Button>
              <Button
                variant="outline"
                onClick={() => window.open('https://faucet.polygon.technology/', '_blank')}
                iconName="Droplets"
                iconPosition="left"
                fullWidth
              >
                Get Test Tokens
              </Button>
              <Button
                variant="outline"
                onClick={() => window.open('https://mumbai.polygonscan.com/', '_blank')}
                iconName="ExternalLink"
                iconPosition="left"
                fullWidth
              >
                Block Explorer
              </Button>
              <Button
                variant="outline"
                onClick={() => setActiveTab('network')}
                iconName="Globe"
                iconPosition="left"
                fullWidth
              >
                Network Status
              </Button>
            </div>
          </div>
        </div>
      </main>
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </div>
  );
};

export default BlockchainIntegration;