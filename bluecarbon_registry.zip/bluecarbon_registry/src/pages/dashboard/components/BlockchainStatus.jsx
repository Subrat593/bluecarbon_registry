import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const BlockchainStatus = () => {
  const [connectionStatus, setConnectionStatus] = useState('connected');
  const [walletAddress, setWalletAddress] = useState('0x742d35Cc6634C0532925a3b8D4C4C0532925a3b8');
  const [networkInfo, setNetworkInfo] = useState({
    name: 'Polygon Mumbai',
    chainId: 80001,
    gasPrice: '2.1 Gwei'
  });
  const [recentTransactions, setRecentTransactions] = useState([]);

  useEffect(() => {
    // Simulate blockchain connection status updates
    const statusInterval = setInterval(() => {
      const statuses = ['connected', 'connecting', 'disconnected'];
      const randomStatus = statuses?.[Math.floor(Math.random() * statuses?.length)];
      setConnectionStatus(randomStatus);
    }, 30000);

    // Mock recent transactions
    const mockTransactions = [
      {
        id: 1,
        hash: '0x7a8b9c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b',
        type: 'Project Registration',
        status: 'confirmed',
        timestamp: new Date(Date.now() - 900000),
        gasUsed: '0.0021 MATIC'
      },
      {
        id: 2,
        hash: '0x1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c',
        type: 'Credit Issuance',
        status: 'pending',
        timestamp: new Date(Date.now() - 1800000),
        gasUsed: '0.0035 MATIC'
      },
      {
        id: 3,
        hash: '0x3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e',
        type: 'Verification Hash',
        status: 'confirmed',
        timestamp: new Date(Date.now() - 3600000),
        gasUsed: '0.0018 MATIC'
      }
    ];
    setRecentTransactions(mockTransactions);

    return () => clearInterval(statusInterval);
  }, []);

  const getStatusColor = (status) => {
    const colors = {
      'connected': 'text-green-600 bg-green-50',
      'connecting': 'text-amber-600 bg-amber-50',
      'disconnected': 'text-red-600 bg-red-50'
    };
    return colors?.[status] || colors?.disconnected;
  };

  const getStatusIcon = (status) => {
    const icons = {
      'connected': 'CheckCircle',
      'connecting': 'Clock',
      'disconnected': 'XCircle'
    };
    return icons?.[status] || icons?.disconnected;
  };

  const getTransactionStatusColor = (status) => {
    return status === 'confirmed' ? 'text-green-600' : status === 'pending' ? 'text-amber-600' : 'text-red-600';
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);

    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  const truncateHash = (hash) => {
    return `${hash?.slice(0, 6)}...${hash?.slice(-4)}`;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">Blockchain Status</h3>
        <p className="text-sm text-muted-foreground">Web3 connectivity and transaction monitoring</p>
      </div>
      {/* Connection Status */}
      <div className="mb-6">
        <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getStatusColor(connectionStatus)}`}>
              <Icon name={getStatusIcon(connectionStatus)} size={20} />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground capitalize">{connectionStatus}</p>
              <p className="text-xs text-muted-foreground">{networkInfo?.name}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Chain ID</p>
            <p className="text-sm font-medium text-foreground">{networkInfo?.chainId}</p>
          </div>
        </div>
      </div>
      {/* Wallet Information */}
      <div className="mb-6">
        <h4 className="text-sm font-medium text-foreground mb-3">Wallet Information</h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-background border border-border rounded-lg">
            <div>
              <p className="text-xs text-muted-foreground">Address</p>
              <p className="text-sm font-mono text-foreground">{truncateHash(walletAddress)}</p>
            </div>
            <button className="text-primary hover:text-primary/80">
              <Icon name="Copy" size={16} />
            </button>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-background border border-border rounded-lg">
            <div>
              <p className="text-xs text-muted-foreground">Gas Price</p>
              <p className="text-sm font-medium text-foreground">{networkInfo?.gasPrice}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Network</p>
              <p className="text-sm font-medium text-foreground">Testnet</p>
            </div>
          </div>
        </div>
      </div>
      {/* Recent Transactions */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-sm font-medium text-foreground">Recent Transactions</h4>
          <button className="text-xs text-primary hover:text-primary/80">View All</button>
        </div>
        
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {recentTransactions?.map((tx) => (
            <div key={tx?.id} className="flex items-center justify-between p-3 bg-background border border-border rounded-lg">
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <p className="text-sm font-medium text-foreground">{tx?.type}</p>
                  <span className={`text-xs font-medium ${getTransactionStatusColor(tx?.status)}`}>
                    {tx?.status}
                  </span>
                </div>
                <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                  <span className="font-mono">{truncateHash(tx?.hash)}</span>
                  <span>{formatTimeAgo(tx?.timestamp)}</span>
                  <span>{tx?.gasUsed}</span>
                </div>
              </div>
              
              <button className="text-primary hover:text-primary/80 ml-2">
                <Icon name="ExternalLink" size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>
      {/* Quick Actions */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="grid grid-cols-2 gap-3">
          <button className="flex items-center justify-center space-x-2 p-2 text-sm font-medium text-primary border border-primary rounded-lg hover:bg-blue-50 transition-smooth">
            <Icon name="Wallet" size={16} />
            <span>Connect Wallet</span>
          </button>
          <button className="flex items-center justify-center space-x-2 p-2 text-sm font-medium text-muted-foreground border border-border rounded-lg hover:bg-muted transition-smooth">
            <Icon name="Settings" size={16} />
            <span>Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default BlockchainStatus;