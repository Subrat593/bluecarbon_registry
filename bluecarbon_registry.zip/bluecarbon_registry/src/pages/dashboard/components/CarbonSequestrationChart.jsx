import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const CarbonSequestrationChart = () => {
  const chartData = [
    { month: 'Jan', mangroves: 1200, wetlands: 800, seagrass: 600, total: 2600 },
    { month: 'Feb', mangroves: 1350, wetlands: 850, seagrass: 650, total: 2850 },
    { month: 'Mar', mangroves: 1400, wetlands: 900, seagrass: 700, total: 3000 },
    { month: 'Apr', mangroves: 1500, wetlands: 950, seagrass: 750, total: 3200 },
    { month: 'May', mangroves: 1600, wetlands: 1000, seagrass: 800, total: 3400 },
    { month: 'Jun', mangroves: 1750, wetlands: 1100, seagrass: 850, total: 3700 },
    { month: 'Jul', mangroves: 1800, wetlands: 1150, seagrass: 900, total: 3850 },
    { month: 'Aug', mangroves: 1900, wetlands: 1200, seagrass: 950, total: 4050 }
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-modal">
          <p className="text-sm font-medium text-foreground mb-2">{`${label} 2024`}</p>
          {payload?.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry?.color }}>
              {`${entry?.name}: ${entry?.value?.toLocaleString()} tCO₂`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">Carbon Sequestration Trends</h3>
        <p className="text-sm text-muted-foreground">Monthly carbon capture by ecosystem type (tCO₂)</p>
      </div>
      
      <div className="w-full h-80" aria-label="Carbon Sequestration Line Chart">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis 
              dataKey="month" 
              stroke="#6B7280"
              fontSize={12}
            />
            <YAxis 
              stroke="#6B7280"
              fontSize={12}
              tickFormatter={(value) => `${value}`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="mangroves" 
              stroke="#059669" 
              strokeWidth={2}
              name="Mangroves"
              dot={{ fill: '#059669', strokeWidth: 2, r: 4 }}
            />
            <Line 
              type="monotone" 
              dataKey="wetlands" 
              stroke="#1E40AF" 
              strokeWidth={2}
              name="Wetlands"
              dot={{ fill: '#1E40AF', strokeWidth: 2, r: 4 }}
            />
            <Line 
              type="monotone" 
              dataKey="seagrass" 
              stroke="#F59E0B" 
              strokeWidth={2}
              name="Seagrass"
              dot={{ fill: '#F59E0B', strokeWidth: 2, r: 4 }}
            />
            <Line 
              type="monotone" 
              dataKey="total" 
              stroke="#7C3AED" 
              strokeWidth={3}
              name="Total"
              dot={{ fill: '#7C3AED', strokeWidth: 2, r: 5 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default CarbonSequestrationChart;