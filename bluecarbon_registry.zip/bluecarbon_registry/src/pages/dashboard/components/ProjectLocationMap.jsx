import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const ProjectLocationMap = () => {
  const [selectedProject, setSelectedProject] = useState(null);

  const projects = [
    {
      id: 1,
      name: "Sundarbans Mangrove Restoration",
      location: "Bangladesh",
      coordinates: { lat: 22.4707, lng: 89.5370 },
      type: "Mangroves",
      status: "Active",
      credits: 15420,
      area: "2,500 hectares"
    },
    {
      id: 2,
      name: "Florida Everglades Conservation",
      location: "Florida, USA",
      coordinates: { lat: 25.2866, lng: -80.8987 },
      type: "Wetlands",
      status: "Verified",
      credits: 8750,
      area: "1,800 hectares"
    },
    {
      id: 3,
      name: "Great Barrier Reef Seagrass",
      location: "Queensland, Australia",
      coordinates: { lat: -16.2839, lng: 145.7781 },
      type: "Seagrass",
      status: "Pending",
      credits: 5200,
      area: "950 hectares"
    },
    {
      id: 4,
      name: "Wadden Sea Protection",
      location: "Netherlands",
      coordinates: { lat: 53.4084, lng: 6.1156 },
      type: "Wetlands",
      status: "Active",
      credits: 12300,
      area: "3,200 hectares"
    }
  ];

  const getStatusColor = (status) => {
    const colors = {
      'Active': 'bg-green-100 text-green-800',
      'Verified': 'bg-blue-100 text-blue-800',
      'Pending': 'bg-amber-100 text-amber-800'
    };
    return colors?.[status] || 'bg-gray-100 text-gray-800';
  };

  const getTypeIcon = (type) => {
    const icons = {
      'Mangroves': 'Trees',
      'Wetlands': 'Waves',
      'Seagrass': 'Leaf'
    };
    return icons?.[type] || 'MapPin';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">Project Locations</h3>
        <p className="text-sm text-muted-foreground">Global distribution of blue carbon projects</p>
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Map Container */}
        <div className="relative">
          <div className="w-full h-64 bg-gray-100 rounded-lg overflow-hidden">
            <iframe
              width="100%"
              height="100%"
              loading="lazy"
              title="Blue Carbon Projects Map"
              referrerPolicy="no-referrer-when-downgrade"
              src="https://www.google.com/maps?q=22.4707,89.5370&z=2&output=embed"
              className="border-0"
            />
          </div>
          
          {/* Map Legend */}
          <div className="absolute top-4 right-4 bg-white rounded-lg p-3 shadow-modal">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-xs text-gray-600">Mangroves</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span className="text-xs text-gray-600">Wetlands</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                <span className="text-xs text-gray-600">Seagrass</span>
              </div>
            </div>
          </div>
        </div>

        {/* Project List */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-foreground mb-3">Active Projects ({projects?.length})</h4>
          <div className="max-h-64 overflow-y-auto space-y-2">
            {projects?.map((project) => (
              <div
                key={project?.id}
                className={`p-3 border rounded-lg cursor-pointer transition-smooth hover:shadow-soft ${
                  selectedProject?.id === project?.id ? 'border-primary bg-blue-50' : 'border-border bg-background'
                }`}
                onClick={() => setSelectedProject(project)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <Icon name={getTypeIcon(project?.type)} size={16} className="text-primary" />
                      <h5 className="text-sm font-medium text-foreground truncate">{project?.name}</h5>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{project?.location}</p>
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(project?.status)}`}>
                        {project?.status}
                      </span>
                      <span className="text-xs text-muted-foreground">{project?.credits?.toLocaleString()} tCO₂</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Selected Project Details */}
      {selectedProject && (
        <div className="mt-6 p-4 bg-muted rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-semibold text-foreground">{selectedProject?.name}</h4>
            <button
              onClick={() => setSelectedProject(null)}
              className="text-muted-foreground hover:text-foreground"
            >
              <Icon name="X" size={16} />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Type:</span>
              <span className="ml-2 text-foreground">{selectedProject?.type}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Area:</span>
              <span className="ml-2 text-foreground">{selectedProject?.area}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Status:</span>
              <span className={`ml-2 px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(selectedProject?.status)}`}>
                {selectedProject?.status}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Credits:</span>
              <span className="ml-2 text-foreground">{selectedProject?.credits?.toLocaleString()} tCO₂</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectLocationMap;