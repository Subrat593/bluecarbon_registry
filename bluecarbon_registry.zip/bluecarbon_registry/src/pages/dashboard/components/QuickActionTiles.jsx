import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';


const QuickActionTiles = ({ userRole = 'admin' }) => {
  const navigate = useNavigate();

  const allActions = [
    {
      id: 'register-project',
      title: 'Register New Project',
      description: 'Start a new blue carbon project registration',
      icon: 'Plus',
      color: 'bg-green-50 border-green-200 hover:bg-green-100',
      iconColor: 'text-green-600',
      path: '/project-registration',
      roles: ['admin', 'project_owner']
    },
    {
      id: 'upload-mrv',
      title: 'Upload MRV Data',
      description: 'Submit monitoring, reporting & verification data',
      icon: 'Upload',
      color: 'bg-blue-50 border-blue-200 hover:bg-blue-100',
      iconColor: 'text-blue-600',
      path: '/mrv-dashboard',
      roles: ['admin', 'project_owner', 'verifier']
    },
    {
      id: 'verify-projects',
      title: 'Verify Projects',
      description: 'Review and verify pending project submissions',
      icon: 'CheckCircle',
      color: 'bg-purple-50 border-purple-200 hover:bg-purple-100',
      iconColor: 'text-purple-600',
      path: '/verification-workflow',
      roles: ['admin', 'verifier']
    },
    {
      id: 'manage-projects',
      title: 'Manage Projects',
      description: 'View and manage your existing projects',
      icon: 'FolderOpen',
      color: 'bg-amber-50 border-amber-200 hover:bg-amber-100',
      iconColor: 'text-amber-600',
      path: '/project-management',
      roles: ['admin', 'project_owner', 'verifier']
    },
    {
      id: 'blockchain-integration',
      title: 'Blockchain Integration',
      description: 'Manage blockchain connections and smart contracts',
      icon: 'Link',
      color: 'bg-indigo-50 border-indigo-200 hover:bg-indigo-100',
      iconColor: 'text-indigo-600',
      path: '/blockchain-integration',
      roles: ['admin']
    },
    {
      id: 'view-analytics',
      title: 'View Analytics',
      description: 'Access detailed project analytics and reports',
      icon: 'BarChart3',
      color: 'bg-teal-50 border-teal-200 hover:bg-teal-100',
      iconColor: 'text-teal-600',
      path: '/mrv-dashboard',
      roles: ['admin', 'verifier', 'project_owner', 'public']
    }
  ];

  const availableActions = allActions?.filter(action => action?.roles?.includes(userRole));

  const handleActionClick = (path) => {
    navigate(path);
  };

  const getGridCols = () => {
    const count = availableActions?.length;
    if (count <= 2) return 'grid-cols-1 md:grid-cols-2';
    if (count <= 3) return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
    if (count <= 4) return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4';
    return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">Quick Actions</h3>
        <p className="text-sm text-muted-foreground">Common tasks based on your role</p>
      </div>
      <div className={`grid gap-4 ${getGridCols()}`}>
        {availableActions?.map((action) => (
          <div
            key={action?.id}
            className={`border rounded-lg p-4 cursor-pointer transition-smooth ${action?.color}`}
            onClick={() => handleActionClick(action?.path)}
          >
            <div className="flex items-start space-x-3">
              <div className={`w-10 h-10 rounded-lg bg-white flex items-center justify-center ${action?.iconColor}`}>
                <Icon name={action?.icon} size={20} />
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-semibold text-foreground mb-1">{action?.title}</h4>
                <p className="text-xs text-muted-foreground line-clamp-2">{action?.description}</p>
              </div>
            </div>
            
            <div className="mt-4 flex justify-end">
              <Icon name="ArrowRight" size={16} className="text-muted-foreground" />
            </div>
          </div>
        ))}
      </div>
      {/* Role-specific Help Text */}
      <div className="mt-6 p-4 bg-muted rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={16} className="text-primary mt-0.5" />
          <div>
            <p className="text-sm font-medium text-foreground mb-1">
              {userRole === 'admin' && 'Administrator Dashboard'}
              {userRole === 'project_owner' && 'Project Owner Dashboard'}
              {userRole === 'verifier' && 'Verifier Dashboard'}
              {userRole === 'public' && 'Public Viewer Dashboard'}
            </p>
            <p className="text-xs text-muted-foreground">
              {userRole === 'admin' && 'You have full access to all platform features including project management, verification, and blockchain integration.'}
              {userRole === 'project_owner' && 'You can register new projects, upload MRV data, and manage your existing blue carbon projects.'}
              {userRole === 'verifier' && 'You can review project submissions, verify MRV data, and approve carbon credit issuance.'}
              {userRole === 'public' && 'You can view verified projects, browse the public registry, and access environmental data.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickActionTiles;