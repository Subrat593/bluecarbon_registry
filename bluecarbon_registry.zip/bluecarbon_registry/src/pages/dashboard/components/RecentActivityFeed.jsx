import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const RecentActivityFeed = () => {
  const [filter, setFilter] = useState('all');

  const activities = [
    {
      id: 1,
      type: 'project_registered',
      title: 'New Project Registered',
      description: 'Mangrove Restoration Project - Phase 2 has been successfully registered',
      user: 'Sarah Johnson',
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      icon: 'Plus',
      color: 'text-green-600'
    },
    {
      id: 2,
      type: 'verification_completed',
      title: 'Verification Completed',
      description: 'Florida Wetlands Conservation project has been verified and approved',
      user: 'Dr. Michael Chen',
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      icon: 'CheckCircle',
      color: 'text-blue-600'
    },
    {
      id: 3,
      type: 'credits_issued',
      title: 'Carbon Credits Issued',
      description: '2,450 tCO₂ credits have been tokenized and issued to blockchain',
      user: 'System',
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      icon: 'Coins',
      color: 'text-amber-600'
    },
    {
      id: 4,
      type: 'data_uploaded',
      title: 'MRV Data Uploaded',
      description: 'Satellite imagery and IoT sensor data uploaded for Q3 monitoring',
      user: 'Alex Rodriguez',
      timestamp: new Date(Date.now() - 10800000), // 3 hours ago
      icon: 'Upload',
      color: 'text-purple-600'
    },
    {
      id: 5,
      type: 'blockchain_transaction',
      title: 'Blockchain Transaction',
      description: 'Project hash stored on Polygon network - Transaction: 0x7a8b9c...',
      user: 'Smart Contract',
      timestamp: new Date(Date.now() - 14400000), // 4 hours ago
      icon: 'Link',
      color: 'text-indigo-600'
    },
    {
      id: 6,
      type: 'project_updated',
      title: 'Project Status Updated',
      description: 'Seagrass Meadow Protection project moved to verification stage',
      user: 'Emma Wilson',
      timestamp: new Date(Date.now() - 18000000), // 5 hours ago
      icon: 'Edit',
      color: 'text-orange-600'
    }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Activities', count: activities?.length },
    { value: 'project_registered', label: 'Registrations', count: activities?.filter(a => a?.type === 'project_registered')?.length },
    { value: 'verification_completed', label: 'Verifications', count: activities?.filter(a => a?.type === 'verification_completed')?.length },
    { value: 'credits_issued', label: 'Credits Issued', count: activities?.filter(a => a?.type === 'credits_issued')?.length },
    { value: 'blockchain_transaction', label: 'Blockchain', count: activities?.filter(a => a?.type === 'blockchain_transaction')?.length }
  ];

  const filteredActivities = filter === 'all' 
    ? activities 
    : activities?.filter(activity => activity?.type === filter);

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-2">Recent Activity</h3>
          <p className="text-sm text-muted-foreground">Latest updates across all projects</p>
        </div>
        <div className="flex items-center space-x-2">
          <Icon name="Activity" size={20} className="text-primary" />
          <span className="text-sm font-medium text-primary">Live</span>
        </div>
      </div>
      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2 mb-6 border-b border-border">
        {filterOptions?.map((option) => (
          <button
            key={option?.value}
            onClick={() => setFilter(option?.value)}
            className={`px-3 py-2 text-sm font-medium rounded-t-lg transition-smooth ${
              filter === option?.value
                ? 'text-primary border-b-2 border-primary bg-blue-50' :'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {option?.label}
            <span className="ml-1 text-xs bg-muted text-muted-foreground px-1.5 py-0.5 rounded-full">
              {option?.count}
            </span>
          </button>
        ))}
      </div>
      {/* Activity List */}
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {filteredActivities?.map((activity) => (
          <div key={activity?.id} className="flex items-start space-x-4 p-3 rounded-lg hover:bg-muted transition-smooth">
            <div className={`w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center ${activity?.color}`}>
              <Icon name={activity?.icon} size={18} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h4 className="text-sm font-medium text-foreground">{activity?.title}</h4>
                <span className="text-xs text-muted-foreground">{formatTimeAgo(activity?.timestamp)}</span>
              </div>
              
              <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{activity?.description}</p>
              
              <div className="flex items-center space-x-2">
                <Icon name="User" size={12} className="text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{activity?.user}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* View All Button */}
      <div className="mt-6 pt-4 border-t border-border">
        <button className="w-full py-2 text-sm font-medium text-primary hover:text-primary/80 transition-smooth">
          View All Activities
          <Icon name="ArrowRight" size={16} className="ml-2 inline" />
        </button>
      </div>
    </div>
  );
};

export default RecentActivityFeed;