import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import SummaryCard from './components/SummaryCard';
import CarbonSequestrationChart from './components/CarbonSequestrationChart';
import ProjectLocationMap from './components/ProjectLocationMap';
import RecentActivityFeed from './components/RecentActivityFeed';
import QuickActionTiles from './components/QuickActionTiles';
import BlockchainStatus from './components/BlockchainStatus';

const Dashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [userRole, setUserRole] = useState('admin');
  const [dashboardData, setDashboardData] = useState({
    totalProjects: 0,
    carbonCredits: 0,
    pendingVerifications: 0,
    blockchainTransactions: 0
  });

  useEffect(() => {
    // Simulate loading dashboard data
    const loadDashboardData = () => {
      setDashboardData({
        totalProjects: 47,
        carbonCredits: 125420,
        pendingVerifications: 8,
        blockchainTransactions: 234
      });
    };

    loadDashboardData();
  }, []);

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const summaryCards = [
    {
      title: 'Total Projects',
      value: dashboardData?.totalProjects?.toLocaleString(),
      change: '+12% from last month',
      changeType: 'increase',
      icon: 'FolderOpen',
      color: 'primary'
    },
    {
      title: 'Carbon Credits Issued',
      value: `${dashboardData?.carbonCredits?.toLocaleString()} tCO₂`,
      change: '+8.5% from last month',
      changeType: 'increase',
      icon: 'Coins',
      color: 'success'
    },
    {
      title: 'Pending Verifications',
      value: dashboardData?.pendingVerifications?.toLocaleString(),
      change: '-15% from last week',
      changeType: 'decrease',
      icon: 'Clock',
      color: 'warning'
    },
    {
      title: 'Blockchain Transactions',
      value: dashboardData?.blockchainTransactions?.toLocaleString(),
      change: '+23% from last month',
      changeType: 'increase',
      icon: 'Link',
      color: 'primary'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onMenuToggle={handleMobileMenuToggle}
        isMenuOpen={isMobileMenuOpen}
      />
      {/* Sidebar */}
      <div className="hidden lg:block">
        <Sidebar 
          isCollapsed={isSidebarCollapsed}
          onToggle={handleSidebarToggle}
        />
      </div>
      {/* Main Content */}
      <main className={`pt-16 transition-all duration-200 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
      }`}>
        <div className="p-4 lg:p-6">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-2">
                  Dashboard
                </h1>
                <p className="text-muted-foreground">
                  Welcome back! Here's an overview of your blue carbon projects and activities.
                </p>
              </div>
              
              {/* Current Date */}
              <div className="hidden md:block text-right">
                <p className="text-sm text-muted-foreground">Today</p>
                <p className="text-lg font-semibold text-foreground">
                  {new Date()?.toLocaleDateString('en-US', { 
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              </div>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
            {summaryCards?.map((card, index) => (
              <SummaryCard
                key={index}
                title={card?.title}
                value={card?.value}
                change={card?.change}
                changeType={card?.changeType}
                icon={card?.icon}
                color={card?.color}
              />
            ))}
          </div>

          {/* Charts and Maps Row */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-8">
            <CarbonSequestrationChart />
            <ProjectLocationMap />
          </div>

          {/* Activity and Status Row */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-8">
            <div className="xl:col-span-2">
              <RecentActivityFeed />
            </div>
            <div>
              <BlockchainStatus />
            </div>
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <QuickActionTiles userRole={userRole} />
          </div>

          {/* Footer */}
          <footer className="mt-12 pt-8 border-t border-border">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="flex items-center space-x-4 mb-4 md:mb-0">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
                    <span className="text-xs font-bold text-white">BC</span>
                  </div>
                  <span className="text-sm font-medium text-foreground">BlueCarbon Registry</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  © {new Date()?.getFullYear()} All rights reserved
                </span>
              </div>
              
              <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                <a href="#" className="hover:text-foreground transition-smooth">Documentation</a>
                <a href="#" className="hover:text-foreground transition-smooth">Support</a>
                <a href="#" className="hover:text-foreground transition-smooth">API</a>
              </div>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;