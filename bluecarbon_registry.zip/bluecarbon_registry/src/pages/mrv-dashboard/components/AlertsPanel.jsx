import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AlertsPanel = ({ alerts = [], onAlertAction }) => {
  const [filter, setFilter] = useState('all');

  const filterOptions = [
    { value: 'all', label: 'All Alerts' },
    { value: 'critical', label: 'Critical' },
    { value: 'warning', label: 'Warning' },
    { value: 'info', label: 'Info' }
  ];

  const getAlertColor = (severity) => {
    switch (severity) {
      case 'critical': return 'border-red-200 bg-red-50 text-red-800';
      case 'warning': return 'border-amber-200 bg-amber-50 text-amber-800';
      case 'info': return 'border-blue-200 bg-blue-50 text-blue-800';
      default: return 'border-gray-200 bg-gray-50 text-gray-800';
    }
  };

  const getAlertIcon = (severity) => {
    switch (severity) {
      case 'critical': return 'AlertCircle';
      case 'warning': return 'AlertTriangle';
      case 'info': return 'Info';
      default: return 'Bell';
    }
  };

  const getAlertIconColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-red-600';
      case 'warning': return 'text-amber-600';
      case 'info': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const alertTime = new Date(timestamp);
    const diffMs = now - alertTime;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  const filteredAlerts = alerts?.filter(alert => {
    if (filter === 'all') return true;
    return alert?.severity === filter;
  });

  const sortedAlerts = [...filteredAlerts]?.sort((a, b) => {
    const severityOrder = { critical: 3, warning: 2, info: 1 };
    if (severityOrder?.[a?.severity] !== severityOrder?.[b?.severity]) {
      return severityOrder?.[b?.severity] - severityOrder?.[a?.severity];
    }
    return new Date(b.timestamp) - new Date(a.timestamp);
  });

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <div className="mb-4 lg:mb-0">
          <h3 className="text-lg font-semibold text-foreground mb-1">System Alerts</h3>
          <p className="text-sm text-muted-foreground">
            Data anomalies and system notifications
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <select
            value={filter}
            onChange={(e) => setFilter(e?.target?.value)}
            className="px-3 py-2 text-sm border border-border rounded-md bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          >
            {filterOptions?.map((option) => (
              <option key={option?.value} value={option?.value}>
                {option?.label}
              </option>
            ))}
          </select>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAlertAction && onAlertAction('mark_all_read')}
            iconName="CheckCheck"
            iconPosition="left"
          >
            Mark All Read
          </Button>
        </div>
      </div>
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {sortedAlerts?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Bell" size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No alerts to display</p>
          </div>
        ) : (
          sortedAlerts?.map((alert) => (
            <div
              key={alert?.id}
              className={`border rounded-lg p-4 transition-smooth ${getAlertColor(alert?.severity)} ${
                !alert?.read ? 'border-l-4' : ''
              }`}
            >
              <div className="flex items-start space-x-3">
                <Icon 
                  name={getAlertIcon(alert?.severity)} 
                  size={20} 
                  className={`mt-0.5 ${getAlertIconColor(alert?.severity)}`}
                />
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-foreground mb-1">
                        {alert?.title}
                        {!alert?.read && (
                          <span className="ml-2 w-2 h-2 bg-primary rounded-full inline-block" />
                        )}
                      </h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        {alert?.message}
                      </p>
                      
                      <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <Icon name="MapPin" size={12} />
                          <span>{alert?.location}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Icon name="Clock" size={12} />
                          <span>{formatTimeAgo(alert?.timestamp)}</span>
                        </div>
                        {alert?.dataSource && (
                          <div className="flex items-center space-x-1">
                            <Icon name="Database" size={12} />
                            <span>{alert?.dataSource}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        alert?.severity === 'critical' ? 'bg-red-100 text-red-800' :
                        alert?.severity === 'warning'? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {alert?.severity}
                      </span>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onAlertAction && onAlertAction('dismiss', alert?.id)}
                        iconName="X"
                        iconSize={14}
                      />
                    </div>
                  </div>
                  
                  {alert?.actions && alert?.actions?.length > 0 && (
                    <div className="flex items-center space-x-2 mt-3 pt-3 border-t border-border/50">
                      {alert?.actions?.map((action, index) => (
                        <Button
                          key={index}
                          variant={action?.primary ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => onAlertAction && onAlertAction(action?.type, alert?.id)}
                          iconName={action?.icon}
                          iconPosition="left"
                          iconSize={14}
                        >
                          {action?.label}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      {sortedAlerts?.length > 0 && (
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
          <p className="text-sm text-muted-foreground">
            {sortedAlerts?.filter(alert => !alert?.read)?.length} unread alerts
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAlertAction && onAlertAction('view_all')}
            iconName="ExternalLink"
            iconPosition="right"
          >
            View All Alerts
          </Button>
        </div>
      )}
    </div>
  );
};

export default AlertsPanel;