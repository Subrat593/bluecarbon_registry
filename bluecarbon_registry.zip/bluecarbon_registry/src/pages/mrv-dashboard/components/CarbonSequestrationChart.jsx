import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CarbonSequestrationChart = ({ data, onFilterChange }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('6months');
  const [selectedEcosystem, setSelectedEcosystem] = useState('all');

  const periodOptions = [
    { value: '1month', label: '1M' },
    { value: '3months', label: '3M' },
    { value: '6months', label: '6M' },
    { value: '1year', label: '1Y' },
    { value: 'all', label: 'All' }
  ];

  const ecosystemOptions = [
    { value: 'all', label: 'All Ecosystems' },
    { value: 'mangroves', label: 'Mangroves' },
    { value: 'wetlands', label: 'Wetlands' },
    { value: 'seagrass', label: 'Seagrass' }
  ];

  const handlePeriodChange = (period) => {
    setSelectedPeriod(period);
    onFilterChange && onFilterChange({ period, ecosystem: selectedEcosystem });
  };

  const handleEcosystemChange = (ecosystem) => {
    setSelectedEcosystem(ecosystem);
    onFilterChange && onFilterChange({ period: selectedPeriod, ecosystem });
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg p-3 shadow-modal">
          <p className="text-sm font-medium text-popover-foreground mb-2">{label}</p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-sm text-popover-foreground">
                {entry?.name}: {entry?.value} tCO₂
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <div className="mb-4 lg:mb-0">
          <h3 className="text-lg font-semibold text-foreground mb-1">Carbon Sequestration Trends</h3>
          <p className="text-sm text-muted-foreground">Track carbon capture rates across different ecosystems</p>
        </div>
        
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
          {/* Period Filter */}
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Period:</span>
            <div className="flex space-x-1">
              {periodOptions?.map((option) => (
                <Button
                  key={option?.value}
                  variant={selectedPeriod === option?.value ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handlePeriodChange(option?.value)}
                  className="px-3 py-1"
                >
                  {option?.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Ecosystem Filter */}
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Ecosystem:</span>
            <select
              value={selectedEcosystem}
              onChange={(e) => handleEcosystemChange(e?.target?.value)}
              className="px-3 py-1 text-sm border border-border rounded-md bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            >
              {ecosystemOptions?.map((option) => (
                <option key={option?.value} value={option?.value}>
                  {option?.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      <div className="h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="month" 
              stroke="#6b7280"
              fontSize={12}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
              label={{ value: 'tCO₂', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="mangroves" 
              stroke="#059669" 
              strokeWidth={2}
              dot={{ fill: '#059669', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6 }}
              name="Mangroves"
            />
            <Line 
              type="monotone" 
              dataKey="wetlands" 
              stroke="#1e40af" 
              strokeWidth={2}
              dot={{ fill: '#1e40af', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6 }}
              name="Wetlands"
            />
            <Line 
              type="monotone" 
              dataKey="seagrass" 
              stroke="#f59e0b" 
              strokeWidth={2}
              dot={{ fill: '#f59e0b', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6 }}
              name="Seagrass"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
          <div className="flex items-center space-x-2">
            <Icon name="TrendingUp" size={16} className="text-emerald-600" />
            <span>Overall trend: +12.5% this quarter</span>
          </div>
        </div>
        <Button variant="outline" size="sm" iconName="Download" iconPosition="left">
          Export Data
        </Button>
      </div>
    </div>
  );
};

export default CarbonSequestrationChart;