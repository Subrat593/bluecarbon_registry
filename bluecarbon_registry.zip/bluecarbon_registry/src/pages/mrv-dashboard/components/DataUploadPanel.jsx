import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DataUploadPanel = ({ onFileUpload, recentUploads = [] }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(null);
  const fileInputRef = useRef(null);

  const acceptedFormats = ['.csv', '.json', '.xlsx'];
  const maxFileSize = 10 * 1024 * 1024; // 10MB

  const handleDragOver = (e) => {
    e?.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e?.dataTransfer?.files);
    handleFiles(files);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e?.target?.files);
    handleFiles(files);
  };

  const handleFiles = (files) => {
    files?.forEach(file => {
      if (validateFile(file)) {
        simulateUpload(file);
      }
    });
  };

  const validateFile = (file) => {
    const fileExtension = '.' + file?.name?.split('.')?.pop()?.toLowerCase();
    
    if (!acceptedFormats?.includes(fileExtension)) {
      alert(`Invalid file format. Please upload ${acceptedFormats?.join(', ')} files only.`);
      return false;
    }
    
    if (file?.size > maxFileSize) {
      alert('File size exceeds 10MB limit.');
      return false;
    }
    
    return true;
  };

  const simulateUpload = (file) => {
    setUploadProgress({ fileName: file?.name, progress: 0 });
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev?.progress >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setUploadProgress(null);
            onFileUpload && onFileUpload({
              id: Date.now(),
              name: file?.name,
              size: file?.size,
              type: file?.type,
              uploadedAt: new Date(),
              status: 'processed'
            });
          }, 500);
          return prev;
        }
        return { ...prev, progress: prev?.progress + 10 };
      });
    }, 200);
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i))?.toFixed(2)) + ' ' + sizes?.[i];
  };

  const getFileIcon = (fileName) => {
    const extension = fileName?.split('.')?.pop()?.toLowerCase();
    switch (extension) {
      case 'csv': return 'FileSpreadsheet';
      case 'json': return 'FileCode';
      case 'xlsx': return 'FileSpreadsheet';
      default: return 'File';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'processed': return 'text-emerald-600';
      case 'processing': return 'text-amber-600';
      case 'error': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-1">Data Upload</h3>
        <p className="text-sm text-muted-foreground">
          Upload monitoring data files (CSV, JSON, XLSX) up to 10MB
        </p>
      </div>
      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-smooth ${
          isDragOver 
            ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept={acceptedFormats?.join(',')}
          onChange={handleFileSelect}
          className="hidden"
        />
        
        <div className="flex flex-col items-center space-y-4">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <Icon name="Upload" size={32} className="text-primary" />
          </div>
          
          <div>
            <p className="text-lg font-medium text-foreground mb-1">
              Drop files here or click to browse
            </p>
            <p className="text-sm text-muted-foreground">
              Supports {acceptedFormats?.join(', ')} files up to 10MB
            </p>
          </div>
          
          <Button
            variant="outline"
            onClick={() => fileInputRef?.current?.click()}
            iconName="FolderOpen"
            iconPosition="left"
          >
            Choose Files
          </Button>
        </div>
      </div>
      {/* Upload Progress */}
      {uploadProgress && (
        <div className="mt-4 p-4 bg-muted rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-foreground">
              Uploading {uploadProgress?.fileName}
            </span>
            <span className="text-sm text-muted-foreground">
              {uploadProgress?.progress}%
            </span>
          </div>
          <div className="w-full bg-border rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${uploadProgress?.progress}%` }}
            />
          </div>
        </div>
      )}
      {/* Recent Uploads */}
      {recentUploads?.length > 0 && (
        <div className="mt-6">
          <h4 className="text-sm font-medium text-foreground mb-3">Recent Uploads</h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {recentUploads?.map((upload) => (
              <div
                key={upload?.id}
                className="flex items-center justify-between p-3 bg-muted rounded-lg"
              >
                <div className="flex items-center space-x-3">
                  <Icon 
                    name={getFileIcon(upload?.name)} 
                    size={20} 
                    className="text-muted-foreground" 
                  />
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {upload?.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(upload?.size)} • {upload?.uploadedAt?.toLocaleDateString()}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className={`text-xs font-medium ${getStatusColor(upload?.status)}`}>
                    {upload?.status}
                  </span>
                  <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Upload Guidelines */}
      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-blue-600 mt-0.5" />
          <div>
            <h5 className="text-sm font-medium text-blue-900 mb-1">Upload Guidelines</h5>
            <ul className="text-xs text-blue-800 space-y-1">
              <li>• CSV files should include headers: date, location, measurement_type, value</li>
              <li>• JSON files must follow the MRV data schema format</li>
              <li>• Ensure data timestamps are in ISO 8601 format</li>
              <li>• Include GPS coordinates for location-based measurements</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataUploadPanel;