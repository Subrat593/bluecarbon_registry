import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import Icon from '../../../components/AppIcon';


const EcosystemHealthChart = ({ data }) => {
  const [selectedMetric, setSelectedMetric] = useState('biodiversity');

  const metricOptions = [
    { value: 'biodiversity', label: 'Biodiversity Index', color: '#059669' },
    { value: 'waterQuality', label: 'Water Quality', color: '#1e40af' },
    { value: 'soilHealth', label: 'Soil Health', color: '#f59e0b' },
    { value: 'vegetation', label: 'Vegetation Cover', color: '#8b5cf6' }
  ];

  const getCurrentMetric = () => {
    return metricOptions?.find(metric => metric?.value === selectedMetric);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      const currentMetric = getCurrentMetric();
      return (
        <div className="bg-popover border border-border rounded-lg p-3 shadow-modal">
          <p className="text-sm font-medium text-popover-foreground mb-2">{label}</p>
          <div className="flex items-center space-x-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: currentMetric?.color }}
            />
            <span className="text-sm text-popover-foreground">
              {currentMetric?.label}: {payload?.[0]?.value}%
            </span>
          </div>
        </div>
      );
    }
    return null;
  };

  const getHealthStatus = (value) => {
    if (value >= 80) return { status: 'Excellent', color: 'text-emerald-600', icon: 'CheckCircle' };
    if (value >= 60) return { status: 'Good', color: 'text-blue-600', icon: 'Info' };
    if (value >= 40) return { status: 'Fair', color: 'text-amber-600', icon: 'AlertTriangle' };
    return { status: 'Poor', color: 'text-red-600', icon: 'AlertCircle' };
  };

  const averageHealth = data?.reduce((sum, item) => sum + item?.[selectedMetric], 0) / data?.length;
  const healthStatus = getHealthStatus(averageHealth);

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <div className="mb-4 lg:mb-0">
          <h3 className="text-lg font-semibold text-foreground mb-1">Ecosystem Health Metrics</h3>
          <p className="text-sm text-muted-foreground">Monitor environmental indicators across project sites</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Icon name={healthStatus?.icon} size={16} className={healthStatus?.color} />
            <span className={`text-sm font-medium ${healthStatus?.color}`}>
              {healthStatus?.status} ({averageHealth?.toFixed(1)}%)
            </span>
          </div>
          
          <select
            value={selectedMetric}
            onChange={(e) => setSelectedMetric(e?.target?.value)}
            className="px-3 py-2 text-sm border border-border rounded-md bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          >
            {metricOptions?.map((option) => (
              <option key={option?.value} value={option?.value}>
                {option?.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="site" 
              stroke="#6b7280"
              fontSize={12}
              angle={-45}
              textAnchor="end"
              height={80}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
              domain={[0, 100]}
              label={{ value: 'Health Score (%)', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar 
              dataKey={selectedMetric} 
              fill={getCurrentMetric()?.color}
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-4 border-t border-border">
        {metricOptions?.map((metric) => {
          const avgValue = data?.reduce((sum, item) => sum + item?.[metric?.value], 0) / data?.length;
          const isSelected = selectedMetric === metric?.value;
          
          return (
            <button
              key={metric?.value}
              onClick={() => setSelectedMetric(metric?.value)}
              className={`p-3 rounded-lg border transition-smooth ${
                isSelected 
                  ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
              }`}
            >
              <div className="flex items-center space-x-2 mb-1">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: metric?.color }}
                />
                <span className="text-xs font-medium text-muted-foreground">
                  {metric?.label}
                </span>
              </div>
              <p className="text-lg font-bold text-foreground">
                {avgValue?.toFixed(1)}%
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default EcosystemHealthChart;