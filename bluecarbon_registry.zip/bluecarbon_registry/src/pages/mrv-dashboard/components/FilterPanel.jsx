import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const FilterPanel = ({ onFilterChange, isCollapsed, onToggle }) => {
  const [filters, setFilters] = useState({
    dateRange: {
      start: '',
      end: ''
    },
    ecosystems: [],
    dataSources: [],
    verificationStatus: [],
    locations: []
  });

  const ecosystemOptions = [
    { id: 'mangroves', label: 'Mangroves', count: 12 },
    { id: 'wetlands', label: 'Wetlands', count: 8 },
    { id: 'seagrass', label: 'Seagrass', count: 15 },
    { id: 'saltmarsh', label: 'Salt Marsh', count: 6 }
  ];

  const dataSourceOptions = [
    { id: 'satellite', label: 'Satellite Data', count: 45 },
    { id: 'iot', label: 'IoT Sensors', count: 32 },
    { id: 'manual', label: 'Manual Surveys', count: 18 },
    { id: 'drone', label: 'Drone Imagery', count: 24 }
  ];

  const verificationStatusOptions = [
    { id: 'verified', label: 'Verified', count: 28 },
    { id: 'pending', label: 'Pending', count: 15 },
    { id: 'in_review', label: 'In Review', count: 12 },
    { id: 'rejected', label: 'Rejected', count: 3 }
  ];

  const locationOptions = [
    { id: 'florida_keys', label: 'Florida Keys', count: 8 },
    { id: 'chesapeake_bay', label: 'Chesapeake Bay', count: 12 },
    { id: 'san_francisco_bay', label: 'San Francisco Bay', count: 6 },
    { id: 'gulf_coast', label: 'Gulf Coast', count: 15 },
    { id: 'pacific_northwest', label: 'Pacific Northwest', count: 9 }
  ];

  const handleCheckboxChange = (category, value, checked) => {
    setFilters(prev => {
      const newFilters = {
        ...prev,
        [category]: checked 
          ? [...prev?.[category], value]
          : prev?.[category]?.filter(item => item !== value)
      };
      
      onFilterChange && onFilterChange(newFilters);
      return newFilters;
    });
  };

  const handleDateChange = (field, value) => {
    setFilters(prev => {
      const newFilters = {
        ...prev,
        dateRange: {
          ...prev?.dateRange,
          [field]: value
        }
      };
      
      onFilterChange && onFilterChange(newFilters);
      return newFilters;
    });
  };

  const clearAllFilters = () => {
    const clearedFilters = {
      dateRange: { start: '', end: '' },
      ecosystems: [],
      dataSources: [],
      verificationStatus: [],
      locations: []
    };
    
    setFilters(clearedFilters);
    onFilterChange && onFilterChange(clearedFilters);
  };

  const getActiveFilterCount = () => {
    return filters?.ecosystems?.length + 
           filters?.dataSources?.length + 
           filters?.verificationStatus?.length + 
           filters?.locations?.length +
           (filters?.dateRange?.start || filters?.dateRange?.end ? 1 : 0);
  };

  const FilterSection = ({ title, options, category, icon }) => (
    <div className="mb-6">
      <div className="flex items-center space-x-2 mb-3">
        <Icon name={icon} size={16} className="text-muted-foreground" />
        <h4 className="text-sm font-medium text-foreground">{title}</h4>
      </div>
      <div className="space-y-2">
        {options?.map((option) => (
          <div key={option?.id} className="flex items-center justify-between">
            <Checkbox
              label={option?.label}
              checked={filters?.[category]?.includes(option?.id)}
              onChange={(e) => handleCheckboxChange(category, option?.id, e?.target?.checked)}
              size="sm"
            />
            <span className="text-xs text-muted-foreground">({option?.count})</span>
          </div>
        ))}
      </div>
    </div>
  );

  if (isCollapsed) {
    return (
      <div className="fixed left-60 top-20 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={onToggle}
          iconName="Filter"
          iconPosition="left"
          className="shadow-modal"
        >
          Filters {getActiveFilterCount() > 0 && `(${getActiveFilterCount()})`}
        </Button>
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border border-border rounded-lg p-6 shadow-soft h-fit">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-foreground" />
          <h3 className="text-lg font-semibold text-foreground">Filters</h3>
          {getActiveFilterCount() > 0 && (
            <span className="px-2 py-1 text-xs font-medium bg-primary text-primary-foreground rounded-full">
              {getActiveFilterCount()}
            </span>
          )}
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggle}
          iconName="X"
          iconSize={16}
        />
      </div>
      <div className="space-y-6 max-h-96 overflow-y-auto">
        {/* Date Range */}
        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="Calendar" size={16} className="text-muted-foreground" />
            <h4 className="text-sm font-medium text-foreground">Date Range</h4>
          </div>
          <div className="space-y-3">
            <Input
              type="date"
              label="Start Date"
              value={filters?.dateRange?.start}
              onChange={(e) => handleDateChange('start', e?.target?.value)}
              className="text-sm"
            />
            <Input
              type="date"
              label="End Date"
              value={filters?.dateRange?.end}
              onChange={(e) => handleDateChange('end', e?.target?.value)}
              className="text-sm"
            />
          </div>
        </div>

        {/* Ecosystem Types */}
        <FilterSection
          title="Ecosystem Types"
          options={ecosystemOptions}
          category="ecosystems"
          icon="Trees"
        />

        {/* Data Sources */}
        <FilterSection
          title="Data Sources"
          options={dataSourceOptions}
          category="dataSources"
          icon="Database"
        />

        {/* Verification Status */}
        <FilterSection
          title="Verification Status"
          options={verificationStatusOptions}
          category="verificationStatus"
          icon="CheckCircle"
        />

        {/* Locations */}
        <FilterSection
          title="Project Locations"
          options={locationOptions}
          category="locations"
          icon="MapPin"
        />
      </div>
      {/* Filter Actions */}
      <div className="flex space-x-2 mt-6 pt-4 border-t border-border">
        <Button
          variant="outline"
          size="sm"
          onClick={clearAllFilters}
          iconName="RotateCcw"
          iconPosition="left"
          fullWidth
        >
          Clear All
        </Button>
        <Button
          variant="default"
          size="sm"
          onClick={() => onFilterChange && onFilterChange(filters)}
          iconName="Search"
          iconPosition="left"
          fullWidth
        >
          Apply
        </Button>
      </div>
      {/* Quick Filters */}
      <div className="mt-4 pt-4 border-t border-border">
        <h5 className="text-xs font-medium text-muted-foreground mb-2">Quick Filters</h5>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="xs"
            onClick={() => handleCheckboxChange('verificationStatus', 'verified', true)}
          >
            Verified Only
          </Button>
          <Button
            variant="outline"
            size="xs"
            onClick={() => handleCheckboxChange('dataSources', 'satellite', true)}
          >
            Satellite Data
          </Button>
          <Button
            variant="outline"
            size="xs"
            onClick={() => {
              handleDateChange('start', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)?.toISOString()?.split('T')?.[0]);
              handleDateChange('end', new Date()?.toISOString()?.split('T')?.[0]);
            }}
          >
            Last 30 Days
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FilterPanel;