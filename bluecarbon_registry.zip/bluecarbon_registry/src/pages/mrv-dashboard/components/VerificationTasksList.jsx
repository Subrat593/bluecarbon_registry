import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VerificationTasksList = ({ tasks = [], onTaskAction }) => {
  const [filter, setFilter] = useState('all');
  const [sortBy, setSortBy] = useState('priority');

  const filterOptions = [
    { value: 'all', label: 'All Tasks' },
    { value: 'pending', label: 'Pending' },
    { value: 'in_progress', label: 'In Progress' },
    { value: 'completed', label: 'Completed' },
    { value: 'overdue', label: 'Overdue' }
  ];

  const sortOptions = [
    { value: 'priority', label: 'Priority' },
    { value: 'dueDate', label: 'Due Date' },
    { value: 'project', label: 'Project' },
    { value: 'status', label: 'Status' }
  ];

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'low': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'text-amber-600 bg-amber-50';
      case 'in_progress': return 'text-blue-600 bg-blue-50';
      case 'completed': return 'text-emerald-600 bg-emerald-50';
      case 'overdue': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending': return 'Clock';
      case 'in_progress': return 'Play';
      case 'completed': return 'CheckCircle';
      case 'overdue': return 'AlertCircle';
      default: return 'Circle';
    }
  };

  const isOverdue = (dueDate) => {
    return new Date(dueDate) < new Date() && dueDate;
  };

  const formatDueDate = (dueDate) => {
    if (!dueDate) return 'No due date';
    const date = new Date(dueDate);
    const now = new Date();
    const diffTime = date - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return `${Math.abs(diffDays)} days overdue`;
    if (diffDays === 0) return 'Due today';
    if (diffDays === 1) return 'Due tomorrow';
    return `Due in ${diffDays} days`;
  };

  const filteredTasks = tasks?.filter(task => {
    if (filter === 'all') return true;
    if (filter === 'overdue') return isOverdue(task?.dueDate);
    return task?.status === filter;
  });

  const sortedTasks = [...filteredTasks]?.sort((a, b) => {
    switch (sortBy) {
      case 'priority':
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return priorityOrder?.[b?.priority] - priorityOrder?.[a?.priority];
      case 'dueDate':
        return new Date(a.dueDate || '9999-12-31') - new Date(b.dueDate || '9999-12-31');
      case 'project':
        return a?.projectName?.localeCompare(b?.projectName);
      case 'status':
        return a?.status?.localeCompare(b?.status);
      default:
        return 0;
    }
  });

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-soft">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <div className="mb-4 lg:mb-0">
          <h3 className="text-lg font-semibold text-foreground mb-1">Verification Tasks</h3>
          <p className="text-sm text-muted-foreground">
            Pending verification activities and deadlines
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
          <select
            value={filter}
            onChange={(e) => setFilter(e?.target?.value)}
            className="px-3 py-2 text-sm border border-border rounded-md bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          >
            {filterOptions?.map((option) => (
              <option key={option?.value} value={option?.value}>
                {option?.label}
              </option>
            ))}
          </select>
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e?.target?.value)}
            className="px-3 py-2 text-sm border border-border rounded-md bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          >
            {sortOptions?.map((option) => (
              <option key={option?.value} value={option?.value}>
                Sort by {option?.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {sortedTasks?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="CheckCircle" size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No verification tasks found</p>
          </div>
        ) : (
          sortedTasks?.map((task) => (
            <div
              key={task?.id}
              className="border border-border rounded-lg p-4 hover:shadow-soft transition-smooth"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <Icon 
                      name={getStatusIcon(task?.status)} 
                      size={16} 
                      className={getStatusColor(task?.status)?.split(' ')?.[0]}
                    />
                    <h4 className="font-medium text-foreground">{task?.title}</h4>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getPriorityColor(task?.priority)}`}>
                      {task?.priority}
                    </span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-3">
                    {task?.description}
                  </p>
                  
                  <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Icon name="Building" size={14} />
                      <span>{task?.projectName}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name="User" size={14} />
                      <span>{task?.assignedTo}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name="Calendar" size={14} />
                      <span className={isOverdue(task?.dueDate) ? 'text-red-600' : ''}>
                        {formatDueDate(task?.dueDate)}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(task?.status)}`}>
                    {task?.status?.replace('_', ' ')}
                  </span>
                  
                  <div className="flex space-x-1">
                    {task?.status === 'pending' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onTaskAction && onTaskAction(task?.id, 'start')}
                        iconName="Play"
                        iconSize={14}
                      >
                        Start
                      </Button>
                    )}
                    
                    {task?.status === 'in_progress' && (
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => onTaskAction && onTaskAction(task?.id, 'complete')}
                        iconName="CheckCircle"
                        iconSize={14}
                      >
                        Complete
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onTaskAction && onTaskAction(task?.id, 'view')}
                      iconName="Eye"
                      iconSize={14}
                    >
                      View
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      {sortedTasks?.length > 0 && (
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
          <p className="text-sm text-muted-foreground">
            Showing {sortedTasks?.length} of {tasks?.length} tasks
          </p>
          <Button variant="outline" size="sm" iconName="Plus" iconPosition="left">
            Add Task
          </Button>
        </div>
      )}
    </div>
  );
};

export default VerificationTasksList;