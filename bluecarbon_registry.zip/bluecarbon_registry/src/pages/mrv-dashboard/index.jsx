import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import KPICard from './components/KPICard';
import CarbonSequestrationChart from './components/CarbonSequestrationChart';
import EcosystemHealthChart from './components/EcosystemHealthChart';
import DataUploadPanel from './components/DataUploadPanel';
import VerificationTasksList from './components/VerificationTasksList';
import AlertsPanel from './components/AlertsPanel';
import FilterPanel from './components/FilterPanel';
import Button from '../../components/ui/Button';


const MRVDashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [recentUploads, setRecentUploads] = useState([]);
  const [activeFilters, setActiveFilters] = useState({});

  // Mock data for KPI cards
  const kpiData = [
    {
      title: "Total Carbon Sequestered",
      value: "2,847",
      unit: "tCO₂",
      change: "+12.5%",
      changeType: "increase",
      icon: "Leaf",
      color: "success"
    },
    {
      title: "Active Data Sources",
      value: "156",
      unit: "sensors",
      change: "+8",
      changeType: "increase",
      icon: "Database",
      color: "primary"
    },
    {
      title: "Verification Progress",
      value: "78%",
      unit: "complete",
      change: "+5.2%",
      changeType: "increase",
      icon: "CheckCircle",
      color: "warning"
    },
    {
      title: "Data Quality Score",
      value: "94.2",
      unit: "/100",
      change: "-1.1%",
      changeType: "decrease",
      icon: "BarChart3",
      color: "error"
    }
  ];

  // Mock data for carbon sequestration chart
  const carbonData = [
    { month: "Jan 2024", mangroves: 245, wetlands: 189, seagrass: 156 },
    { month: "Feb 2024", mangroves: 267, wetlands: 203, seagrass: 178 },
    { month: "Mar 2024", mangroves: 289, wetlands: 221, seagrass: 195 },
    { month: "Apr 2024", mangroves: 312, wetlands: 234, seagrass: 212 },
    { month: "May 2024", mangroves: 334, wetlands: 256, seagrass: 229 },
    { month: "Jun 2024", mangroves: 356, wetlands: 278, seagrass: 246 },
    { month: "Jul 2024", mangroves: 378, wetlands: 295, seagrass: 263 },
    { month: "Aug 2024", mangroves: 401, wetlands: 312, seagrass: 280 }
  ];

  // Mock data for ecosystem health chart
  const ecosystemData = [
    { site: "Florida Keys", biodiversity: 87, waterQuality: 92, soilHealth: 78, vegetation: 85 },
    { site: "Chesapeake Bay", biodiversity: 82, waterQuality: 88, soilHealth: 84, vegetation: 79 },
    { site: "San Francisco Bay", biodiversity: 79, waterQuality: 85, soilHealth: 81, vegetation: 83 },
    { site: "Gulf Coast", biodiversity: 91, waterQuality: 89, soilHealth: 87, vegetation: 88 },
    { site: "Pacific Northwest", biodiversity: 85, waterQuality: 94, soilHealth: 82, vegetation: 86 }
  ];

  // Mock data for verification tasks
  const verificationTasks = [
    {
      id: 1,
      title: "Mangrove Carbon Assessment",
      description: "Verify carbon sequestration data from Florida Keys mangrove restoration project",
      projectName: "Florida Keys Restoration",
      assignedTo: "Dr. Sarah Johnson",
      status: "pending",
      priority: "high",
      dueDate: "2024-09-05"
    },
    {
      id: 2,
      title: "Wetland Biodiversity Survey",
      description: "Review biodiversity monitoring data and field survey results",
      projectName: "Chesapeake Bay Conservation",
      assignedTo: "Mark Thompson",
      status: "in_progress",
      priority: "medium",
      dueDate: "2024-09-10"
    },
    {
      id: 3,
      title: "Seagrass Health Monitoring",
      description: "Validate seagrass coverage and health metrics from satellite imagery",
      projectName: "Pacific Coast Initiative",
      assignedTo: "Dr. Emily Chen",
      status: "completed",
      priority: "low",
      dueDate: "2024-08-28"
    },
    {
      id: 4,
      title: "IoT Sensor Calibration",
      description: "Verify accuracy of water quality sensors and data collection protocols",
      projectName: "Gulf Coast Monitoring",
      assignedTo: "James Wilson",
      status: "overdue",
      priority: "high",
      dueDate: "2024-08-25"
    }
  ];

  // Mock data for alerts
  const systemAlerts = [
    {
      id: 1,
      title: "Data Anomaly Detected",
      message: "Unusual carbon sequestration readings detected in Sector 7. Values are 40% higher than expected baseline.",
      severity: "warning",
      location: "Florida Keys - Sector 7",
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      dataSource: "IoT Sensors",
      read: false,
      actions: [
        { type: "investigate", label: "Investigate", icon: "Search", primary: true },
        { type: "recalibrate", label: "Recalibrate", icon: "Settings" }
      ]
    },
    {
      id: 2,
      title: "Sensor Offline",
      message: "Water quality sensor WQ-045 has been offline for 2 hours. Last reading: pH 7.8, DO 6.2 mg/L.",
      severity: "critical",
      location: "Chesapeake Bay - Station 12",
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      dataSource: "IoT Network",
      read: false,
      actions: [
        { type: "dispatch", label: "Dispatch Tech", icon: "Truck", primary: true },
        { type: "backup", label: "Use Backup", icon: "RefreshCw" }
      ]
    },
    {
      id: 3,
      title: "Verification Deadline Approaching",
      message: "Mangrove Carbon Assessment verification is due in 3 days. Current progress: 65% complete.",
      severity: "info",
      location: "Florida Keys Restoration",
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      dataSource: "Project Management",
      read: true,
      actions: [
        { type: "view_task", label: "View Task", icon: "Eye", primary: true }
      ]
    }
  ];

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleFileUpload = (fileData) => {
    setRecentUploads(prev => [fileData, ...prev?.slice(0, 4)]);
  };

  const handleTaskAction = (taskId, action) => {
    console.log(`Task ${taskId}: ${action}`);
    // Handle task actions (start, complete, view)
  };

  const handleAlertAction = (action, alertId) => {
    console.log(`Alert action: ${action}`, alertId);
    // Handle alert actions (dismiss, investigate, etc.)
  };

  const handleFilterChange = (filters) => {
    setActiveFilters(filters);
    console.log('Filters applied:', filters);
    // Apply filters to data
  };

  const handleExportData = () => {
    console.log('Exporting MRV data...');
    // Handle data export
  };

  useEffect(() => {
    // Initialize with some mock recent uploads
    setRecentUploads([
      {
        id: 1,
        name: "carbon_data_aug_2024.csv",
        size: 2048576,
        type: "text/csv",
        uploadedAt: new Date(Date.now() - 3600000),
        status: "processed"
      },
      {
        id: 2,
        name: "sensor_readings_weekly.json",
        size: 1536000,
        type: "application/json",
        uploadedAt: new Date(Date.now() - 7200000),
        status: "processing"
      }
    ]);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuToggle={handleMobileMenuToggle} isMenuOpen={isMobileMenuOpen} />
      <Sidebar isCollapsed={isSidebarCollapsed} onToggle={handleSidebarToggle} />
      <main className={`pt-16 transition-all duration-200 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
      }`}>
        <div className="p-4 lg:p-6">
          {/* Page Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
            <div className="mb-4 lg:mb-0">
              <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-2">
                MRV Dashboard
              </h1>
              <p className="text-muted-foreground">
                Monitor, report, and verify blue carbon project data with real-time insights
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
              <Button
                variant="outline"
                onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
                iconName="Filter"
                iconPosition="left"
                className="lg:hidden"
              >
                Filters
              </Button>
              <Button
                variant="outline"
                onClick={handleExportData}
                iconName="Download"
                iconPosition="left"
              >
                Export Data
              </Button>
              <Button
                variant="default"
                iconName="RefreshCw"
                iconPosition="left"
              >
                Refresh
              </Button>
            </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-6">
            {/* Main Content */}
            <div className="flex-1 space-y-6">
              {/* KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {kpiData?.map((kpi, index) => (
                  <KPICard
                    key={index}
                    title={kpi?.title}
                    value={kpi?.value}
                    unit={kpi?.unit}
                    change={kpi?.change}
                    changeType={kpi?.changeType}
                    icon={kpi?.icon}
                    color={kpi?.color}
                  />
                ))}
              </div>

              {/* Charts Section */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                <div className="xl:col-span-2">
                  <CarbonSequestrationChart 
                    data={carbonData}
                    onFilterChange={handleFilterChange}
                  />
                </div>
                <div className="xl:col-span-2">
                  <EcosystemHealthChart data={ecosystemData} />
                </div>
              </div>

              {/* Data Management Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <VerificationTasksList 
                  tasks={verificationTasks}
                  onTaskAction={handleTaskAction}
                />
                <AlertsPanel 
                  alerts={systemAlerts}
                  onAlertAction={handleAlertAction}
                />
              </div>

              {/* Upload Panel - Mobile/Tablet */}
              <div className="lg:hidden">
                <DataUploadPanel 
                  onFileUpload={handleFileUpload}
                  recentUploads={recentUploads}
                />
              </div>
            </div>

            {/* Right Sidebar - Desktop Only */}
            <div className="hidden lg:block w-80 space-y-6">
              <DataUploadPanel 
                onFileUpload={handleFileUpload}
                recentUploads={recentUploads}
              />
            </div>
          </div>
        </div>
      </main>
      {/* Filter Panel - Desktop */}
      {isFilterPanelOpen && (
        <div className="hidden lg:block fixed left-60 top-20 z-50">
          <FilterPanel
            onFilterChange={handleFilterChange}
            isCollapsed={false}
            onToggle={() => setIsFilterPanelOpen(false)}
          />
        </div>
      )}
      {/* Filter Panel - Mobile Overlay */}
      {isFilterPanelOpen && (
        <div className="lg:hidden fixed inset-0 bg-black/50 z-50" onClick={() => setIsFilterPanelOpen(false)}>
          <div className="fixed right-0 top-0 h-full w-80 max-w-full" onClick={(e) => e?.stopPropagation()}>
            <FilterPanel
              onFilterChange={handleFilterChange}
              isCollapsed={false}
              onToggle={() => setIsFilterPanelOpen(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default MRVDashboard;