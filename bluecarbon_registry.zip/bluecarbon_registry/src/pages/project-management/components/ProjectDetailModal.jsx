import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';


const ProjectDetailModal = ({ project, isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState('overview');

  if (!isOpen || !project) return null;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'Info' },
    { id: 'mrv', label: 'MRV Data', icon: 'BarChart3' },
    { id: 'verification', label: 'Verification', icon: 'CheckCircle' },
    { id: 'blockchain', label: 'Blockchain', icon: 'Link' }
  ];

  const blockchainTransactions = [
    {
      id: '0x1a2b3c4d',
      type: 'Project Registration',
      timestamp: '2024-08-25 14:30:00',
      status: 'Confirmed',
      gasUsed: '45,231'
    },
    {
      id: '0x5e6f7g8h',
      type: 'MRV Data Hash',
      timestamp: '2024-08-28 09:15:00',
      status: 'Confirmed',
      gasUsed: '32,156'
    },
    {
      id: '0x9i0j1k2l',
      type: 'Verification Update',
      timestamp: '2024-08-30 16:45:00',
      status: 'Pending',
      gasUsed: '28,943'
    }
  ];

  const verificationTimeline = [
    {
      stage: 'Project Submission',
      date: '2024-08-20',
      status: 'completed',
      description: 'Initial project documentation submitted'
    },
    {
      stage: 'Document Review',
      date: '2024-08-22',
      status: 'completed',
      description: 'All required documents verified'
    },
    {
      stage: 'Field Verification',
      date: '2024-08-25',
      status: 'in_progress',
      description: 'On-site verification in progress'
    },
    {
      stage: 'Third Party Review',
      date: '2024-09-01',
      status: 'pending',
      description: 'Awaiting independent verification'
    },
    {
      stage: 'Final Approval',
      date: '2024-09-05',
      status: 'pending',
      description: 'Final approval and credit issuance'
    }
  ];

  const mrvData = [
    { metric: 'Carbon Sequestration', value: '1,245 tCO2', trend: '+12%', period: 'Last Quarter' },
    { metric: 'Biomass Growth', value: '2.3 tons/ha', trend: '+8%', period: 'Last Month' },
    { metric: 'Water Quality Index', value: '8.2/10', trend: '+5%', period: 'Last Week' },
    { metric: 'Biodiversity Score', value: '87/100', trend: '+3%', period: 'Last Month' }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return 'CheckCircle';
      case 'in_progress': return 'Clock';
      case 'pending': return 'Circle';
      default: return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-green-600';
      case 'in_progress': return 'text-yellow-600';
      case 'pending': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-1000 p-4">
      <div className="bg-card rounded-lg border border-border w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name="Waves" size={24} className="text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-foreground">{project?.name}</h2>
              <p className="text-sm text-muted-foreground">ID: {project?.id} • {project?.location}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Tabs */}
        <div className="border-b border-border">
          <nav className="flex space-x-8 px-6">
            {tabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab?.id
                    ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon name={tab?.icon} size={16} />
                <span>{tab?.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">Project Details</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Ecosystem Type:</span>
                      <span className="text-foreground capitalize">{project?.ecosystem}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Area:</span>
                      <span className="text-foreground">{project?.area} hectares</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <span className="text-foreground capitalize">{project?.status?.replace('_', ' ')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Credits Issued:</span>
                      <span className="text-foreground">{project?.creditsIssued} tCO2</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">Location</h3>
                  <div className="w-full h-48 bg-muted rounded-lg overflow-hidden">
                    <iframe
                      width="100%"
                      height="100%"
                      loading="lazy"
                      title={project?.name}
                      referrerPolicy="no-referrer-when-downgrade"
                      src={`https://www.google.com/maps?q=${project?.coordinates?.lat},${project?.coordinates?.lng}&z=14&output=embed`}
                    />
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-4">Description</h3>
                <p className="text-muted-foreground leading-relaxed">{project?.description}</p>
              </div>
            </div>
          )}

          {activeTab === 'mrv' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-foreground">MRV Data Overview</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mrvData?.map((data, index) => (
                  <div key={index} className="bg-muted/50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium text-foreground">{data?.metric}</h4>
                      <span className="text-xs text-green-600 font-medium">{data?.trend}</span>
                    </div>
                    <p className="text-2xl font-bold text-foreground">{data?.value}</p>
                    <p className="text-xs text-muted-foreground">{data?.period}</p>
                  </div>
                ))}
              </div>
              <div className="flex space-x-4">
                <Button variant="outline" iconName="Upload">Upload New Data</Button>
                <Button variant="outline" iconName="Download">Export Data</Button>
              </div>
            </div>
          )}

          {activeTab === 'verification' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-foreground">Verification Timeline</h3>
              <div className="space-y-4">
                {verificationTimeline?.map((stage, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      stage?.status === 'completed' ? 'bg-green-100' :
                      stage?.status === 'in_progress' ? 'bg-yellow-100' : 'bg-gray-100'
                    }`}>
                      <Icon 
                        name={getStatusIcon(stage?.status)} 
                        size={16} 
                        className={getStatusColor(stage?.status)}
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium text-foreground">{stage?.stage}</h4>
                        <span className="text-xs text-muted-foreground">{stage?.date}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{stage?.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'blockchain' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-foreground">Blockchain Transactions</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 text-sm font-medium text-muted-foreground">Transaction ID</th>
                      <th className="text-left py-3 text-sm font-medium text-muted-foreground">Type</th>
                      <th className="text-left py-3 text-sm font-medium text-muted-foreground">Timestamp</th>
                      <th className="text-left py-3 text-sm font-medium text-muted-foreground">Status</th>
                      <th className="text-left py-3 text-sm font-medium text-muted-foreground">Gas Used</th>
                    </tr>
                  </thead>
                  <tbody>
                    {blockchainTransactions?.map((tx, index) => (
                      <tr key={index} className="border-b border-border">
                        <td className="py-3 text-sm text-foreground font-mono">{tx?.id}</td>
                        <td className="py-3 text-sm text-foreground">{tx?.type}</td>
                        <td className="py-3 text-sm text-muted-foreground">{tx?.timestamp}</td>
                        <td className="py-3">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            tx?.status === 'Confirmed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {tx?.status}
                          </span>
                        </td>
                        <td className="py-3 text-sm text-muted-foreground">{tx?.gasUsed}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-4 p-6 border-t border-border">
          <Button variant="outline" onClick={onClose}>Close</Button>
          <Button variant="default" iconName="Edit">Edit Project</Button>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetailModal;