import React from 'react';
import Icon from '../../../components/AppIcon';

const ProjectSummaryCards = ({ projects }) => {
  const summaryData = [
    {
      title: 'Total Projects',
      value: projects?.length,
      icon: 'FolderOpen',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      change: '+12%',
      changeType: 'positive'
    },
    {
      title: 'Verified Projects',
      value: projects?.filter(p => p?.status === 'verified')?.length,
      icon: 'CheckCircle',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      change: '+8%',
      changeType: 'positive'
    },
    {
      title: 'Under Review',
      value: projects?.filter(p => p?.status === 'under_review')?.length,
      icon: 'Clock',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      change: '+3%',
      changeType: 'positive'
    },
    {
      title: 'Carbon Credits',
      value: '24.5K',
      icon: 'Leaf',
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      change: '+15%',
      changeType: 'positive'
    }
  ];

  return (
    <div className="space-y-4">
      {summaryData?.map((item, index) => (
        <div key={index} className="bg-card rounded-lg border border-border p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className={`w-12 h-12 ${item?.bgColor} rounded-lg flex items-center justify-center`}>
                <Icon name={item?.icon} size={24} className={item?.color} />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">{item?.title}</p>
                <p className="text-2xl font-bold text-foreground">{item?.value}</p>
              </div>
            </div>
            <div className={`text-sm font-medium ${item?.changeType === 'positive' ? 'text-green-600' : 'text-red-600'}`}>
              {item?.change}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProjectSummaryCards;