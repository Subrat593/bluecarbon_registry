import React, { useState, useMemo } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const ProjectTable = ({ projects, onProjectSelect, onBulkAction, selectedProjects, onSelectionChange }) => {
  const [sortConfig, setSortConfig] = useState({ key: 'lastUpdate', direction: 'desc' });
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    ecosystem: '',
    status: '',
    location: '',
    dateRange: ''
  });

  const ecosystemOptions = [
    { value: '', label: 'All Ecosystems' },
    { value: 'mangroves', label: 'Mangroves' },
    { value: 'wetlands', label: 'Wetlands' },
    { value: 'seagrass', label: 'Seagrass' }
  ];

  const statusOptions = [
    { value: '', label: 'All Status' },
    { value: 'draft', label: 'Draft' },
    { value: 'submitted', label: 'Submitted' },
    { value: 'under_review', label: 'Under Review' },
    { value: 'verified', label: 'Verified' },
    { value: 'rejected', label: 'Rejected' }
  ];

  const locationOptions = [
    { value: '', label: 'All Locations' },
    { value: 'florida', label: 'Florida, USA' },
    { value: 'queensland', label: 'Queensland, Australia' },
    { value: 'sundarbans', label: 'Sundarbans, Bangladesh' },
    { value: 'madagascar', label: 'Madagascar' }
  ];

  const dateRangeOptions = [
    { value: '', label: 'All Time' },
    { value: 'last_week', label: 'Last Week' },
    { value: 'last_month', label: 'Last Month' },
    { value: 'last_quarter', label: 'Last Quarter' },
    { value: 'last_year', label: 'Last Year' }
  ];

  const getStatusColor = (status) => {
    const colors = {
      draft: 'bg-gray-100 text-gray-800',
      submitted: 'bg-blue-100 text-blue-800',
      under_review: 'bg-yellow-100 text-yellow-800',
      verified: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800'
    };
    return colors?.[status] || 'bg-gray-100 text-gray-800';
  };

  const getVerificationStageColor = (stage) => {
    const colors = {
      'Not Started': 'bg-gray-100 text-gray-600',
      'Data Collection': 'bg-blue-100 text-blue-600',
      'Field Verification': 'bg-yellow-100 text-yellow-600',
      'Third Party Review': 'bg-orange-100 text-orange-600',
      'Completed': 'bg-green-100 text-green-600'
    };
    return colors?.[stage] || 'bg-gray-100 text-gray-600';
  };

  const filteredAndSortedProjects = useMemo(() => {
    let filtered = projects?.filter(project => {
      const matchesSearch = project?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                           project?.location?.toLowerCase()?.includes(searchTerm?.toLowerCase());
      const matchesEcosystem = !filters?.ecosystem || project?.ecosystem === filters?.ecosystem;
      const matchesStatus = !filters?.status || project?.status === filters?.status;
      const matchesLocation = !filters?.location || project?.location?.toLowerCase()?.includes(filters?.location);
      
      return matchesSearch && matchesEcosystem && matchesStatus && matchesLocation;
    });

    if (sortConfig?.key) {
      filtered?.sort((a, b) => {
        let aValue = a?.[sortConfig?.key];
        let bValue = b?.[sortConfig?.key];
        
        if (sortConfig?.key === 'lastUpdate') {
          aValue = new Date(aValue);
          bValue = new Date(bValue);
        }
        
        if (aValue < bValue) return sortConfig?.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig?.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [projects, searchTerm, filters, sortConfig]);

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev?.key === key && prev?.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      onSelectionChange(filteredAndSortedProjects?.map(p => p?.id));
    } else {
      onSelectionChange([]);
    }
  };

  const handleSelectProject = (projectId, checked) => {
    if (checked) {
      onSelectionChange([...selectedProjects, projectId]);
    } else {
      onSelectionChange(selectedProjects?.filter(id => id !== projectId));
    }
  };

  const isAllSelected = filteredAndSortedProjects?.length > 0 && 
    filteredAndSortedProjects?.every(project => selectedProjects?.includes(project?.id));

  return (
    <div className="bg-card rounded-lg border border-border">
      {/* Filters */}
      <div className="p-6 border-b border-border">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="lg:col-span-2">
            <Input
              type="search"
              placeholder="Search projects..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e?.target?.value)}
            />
          </div>
          <Select
            placeholder="Ecosystem Type"
            options={ecosystemOptions}
            value={filters?.ecosystem}
            onChange={(value) => setFilters(prev => ({ ...prev, ecosystem: value }))}
          />
          <Select
            placeholder="Status"
            options={statusOptions}
            value={filters?.status}
            onChange={(value) => setFilters(prev => ({ ...prev, status: value }))}
          />
          <Select
            placeholder="Date Range"
            options={dateRangeOptions}
            value={filters?.dateRange}
            onChange={(value) => setFilters(prev => ({ ...prev, dateRange: value }))}
          />
        </div>
      </div>
      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted">
            <tr>
              <th className="w-12 px-6 py-3 text-left">
                <Checkbox
                  checked={isAllSelected}
                  onChange={(e) => handleSelectAll(e?.target?.checked)}
                />
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button
                  onClick={() => handleSort('name')}
                  className="flex items-center space-x-1 hover:text-foreground"
                >
                  <span>Project Name</span>
                  <Icon name="ArrowUpDown" size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button
                  onClick={() => handleSort('ecosystem')}
                  className="flex items-center space-x-1 hover:text-foreground"
                >
                  <span>Ecosystem</span>
                  <Icon name="ArrowUpDown" size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button
                  onClick={() => handleSort('location')}
                  className="flex items-center space-x-1 hover:text-foreground"
                >
                  <span>Location</span>
                  <Icon name="ArrowUpDown" size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button
                  onClick={() => handleSort('status')}
                  className="flex items-center space-x-1 hover:text-foreground"
                >
                  <span>Status</span>
                  <Icon name="ArrowUpDown" size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <button
                  onClick={() => handleSort('lastUpdate')}
                  className="flex items-center space-x-1 hover:text-foreground"
                >
                  <span>Last Update</span>
                  <Icon name="ArrowUpDown" size={14} />
                </button>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Verification Stage
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-card divide-y divide-border">
            {filteredAndSortedProjects?.map((project) => (
              <tr 
                key={project?.id} 
                className="hover:bg-muted/50 cursor-pointer"
                onClick={() => onProjectSelect(project)}
              >
                <td className="px-6 py-4 whitespace-nowrap" onClick={(e) => e?.stopPropagation()}>
                  <Checkbox
                    checked={selectedProjects?.includes(project?.id)}
                    onChange={(e) => handleSelectProject(project?.id, e?.target?.checked)}
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
                      <Icon name="Waves" size={20} className="text-primary" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-foreground">{project?.name}</div>
                      <div className="text-sm text-muted-foreground">ID: {project?.id}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Icon 
                      name={project?.ecosystem === 'mangroves' ? 'Trees' : 
                            project?.ecosystem === 'wetlands' ? 'Droplets' : 'Waves'} 
                      size={16} 
                      className="mr-2 text-muted-foreground" 
                    />
                    <span className="text-sm text-foreground capitalize">{project?.ecosystem}</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Icon name="MapPin" size={16} className="mr-2 text-muted-foreground" />
                    <span className="text-sm text-foreground">{project?.location}</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(project?.status)}`}>
                    {project?.status?.replace('_', ' ')?.toUpperCase()}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground">
                  {new Date(project.lastUpdate)?.toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getVerificationStageColor(project?.verificationStage)}`}>
                    {project?.verificationStage}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium" onClick={(e) => e?.stopPropagation()}>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="xs" iconName="Eye" />
                    <Button variant="ghost" size="xs" iconName="Edit" />
                    <Button variant="ghost" size="xs" iconName="Upload" />
                    <Button variant="ghost" size="xs" iconName="MoreHorizontal" />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {filteredAndSortedProjects?.length === 0 && (
        <div className="text-center py-12">
          <Icon name="Search" size={48} className="mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No projects found</h3>
          <p className="text-muted-foreground">Try adjusting your search or filter criteria</p>
        </div>
      )}
    </div>
  );
};

export default ProjectTable;