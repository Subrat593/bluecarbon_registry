import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActionPanel = ({ selectedProjects, onBulkAction }) => {
  const quickActions = [
    {
      title: 'Upload MRV Data',
      description: 'Bulk upload monitoring data',
      icon: 'Upload',
      action: 'upload_mrv',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Update Status',
      description: 'Change project status',
      icon: 'RefreshCw',
      action: 'update_status',
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Generate Report',
      description: 'Create project reports',
      icon: 'FileText',
      action: 'generate_report',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      title: 'Export Data',
      description: 'Download project data',
      icon: 'Download',
      action: 'export_data',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    }
  ];

  const recentActivities = [
    {
      id: 1,
      action: 'Project verified',
      project: 'Mangrove Restoration FL-001',
      time: '2 hours ago',
      icon: 'CheckCircle',
      color: 'text-green-600'
    },
    {
      id: 2,
      action: 'MRV data uploaded',
      project: 'Wetland Conservation QLD-003',
      time: '4 hours ago',
      icon: 'Upload',
      color: 'text-blue-600'
    },
    {
      id: 3,
      action: 'Status updated',
      project: 'Seagrass Protection BD-002',
      time: '6 hours ago',
      icon: 'RefreshCw',
      color: 'text-yellow-600'
    },
    {
      id: 4,
      action: 'New project registered',
      project: 'Coastal Restoration MG-004',
      time: '1 day ago',
      icon: 'Plus',
      color: 'text-purple-600'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
        <div className="space-y-3">
          {quickActions?.map((action, index) => (
            <button
              key={index}
              onClick={() => onBulkAction(action?.action)}
              disabled={selectedProjects?.length === 0}
              className="w-full flex items-center p-3 rounded-lg border border-border hover:bg-muted transition-smooth disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className={`w-10 h-10 ${action?.bgColor} rounded-lg flex items-center justify-center mr-3`}>
                <Icon name={action?.icon} size={20} className={action?.color} />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-medium text-foreground">{action?.title}</p>
                <p className="text-xs text-muted-foreground">{action?.description}</p>
              </div>
              <Icon name="ChevronRight" size={16} className="text-muted-foreground" />
            </button>
          ))}
        </div>
        
        {selectedProjects?.length > 0 && (
          <div className="mt-4 p-3 bg-primary/10 rounded-lg">
            <p className="text-sm text-primary font-medium">
              {selectedProjects?.length} project{selectedProjects?.length > 1 ? 's' : ''} selected
            </p>
          </div>
        )}
      </div>
      {/* Recent Activities */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Recent Activities</h3>
          <Button variant="ghost" size="sm" iconName="ExternalLink">
            View All
          </Button>
        </div>
        <div className="space-y-3">
          {recentActivities?.map((activity) => (
            <div key={activity?.id} className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                <Icon name={activity?.icon} size={14} className={activity?.color} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground">{activity?.action}</p>
                <p className="text-xs text-muted-foreground truncate">{activity?.project}</p>
                <p className="text-xs text-muted-foreground">{activity?.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* System Status */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">System Status</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              <span className="text-sm text-foreground">Blockchain Network</span>
            </div>
            <span className="text-xs text-green-600 font-medium">Online</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              <span className="text-sm text-foreground">MRV Data Sync</span>
            </div>
            <span className="text-xs text-green-600 font-medium">Active</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></div>
              <span className="text-sm text-foreground">Verification Queue</span>
            </div>
            <span className="text-xs text-yellow-600 font-medium">3 Pending</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickActionPanel;