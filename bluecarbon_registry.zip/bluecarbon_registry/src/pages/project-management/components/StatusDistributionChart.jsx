import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const StatusDistributionChart = ({ projects }) => {
  const statusCounts = projects?.reduce((acc, project) => {
    acc[project.status] = (acc?.[project?.status] || 0) + 1;
    return acc;
  }, {});

  const data = Object.entries(statusCounts)?.map(([status, count]) => ({
    name: status?.replace('_', ' ')?.toUpperCase(),
    value: count,
    status: status
  }));

  const COLORS = {
    draft: '#6B7280',
    submitted: '#3B82F6',
    under_review: '#F59E0B',
    verified: '#10B981',
    rejected: '#EF4444'
  };

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload?.length) {
      const data = payload?.[0];
      return (
        <div className="bg-popover border border-border rounded-lg shadow-modal p-3">
          <p className="text-sm font-medium text-popover-foreground">
            {data?.payload?.name}: {data?.value} projects
          </p>
          <p className="text-xs text-muted-foreground">
            {((data?.value / projects?.length) * 100)?.toFixed(1)}% of total
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h3 className="text-lg font-semibold text-foreground mb-4">Status Distribution</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={40}
              outerRadius={80}
              paddingAngle={2}
              dataKey="value"
            >
              {data?.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS?.[entry?.status]} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend 
              verticalAlign="bottom" 
              height={36}
              formatter={(value) => <span className="text-sm text-foreground">{value}</span>}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default StatusDistributionChart;