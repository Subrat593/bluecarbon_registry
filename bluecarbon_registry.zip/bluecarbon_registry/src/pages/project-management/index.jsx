import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';

import Button from '../../components/ui/Button';
import ProjectTable from './components/ProjectTable';
import ProjectSummaryCards from './components/ProjectSummaryCards';
import StatusDistributionChart from './components/StatusDistributionChart';
import QuickActionPanel from './components/QuickActionPanel';
import ProjectDetailModal from './components/ProjectDetailModal';

const ProjectManagement = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedProjects, setSelectedProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Mock project data
  const projects = [
    {
      id: 'FL-001',
      name: 'Mangrove Restoration Project',
      ecosystem: 'mangroves',
      location: 'Florida Keys, USA',
      status: 'verified',
      lastUpdate: '2024-08-30',
      verificationStage: 'Completed',
      area: 150,
      creditsIssued: 2450,
      coordinates: { lat: 25.0343, lng: -80.4531 },
      description: `This comprehensive mangrove restoration project focuses on rehabilitating degraded coastal ecosystems in the Florida Keys. The project encompasses 150 hectares of critical mangrove habitat, implementing innovative restoration techniques including seedling propagation, hydrological restoration, and community engagement programs.\n\nThe initiative aims to sequester approximately 2,450 tons of CO2 equivalent while providing essential ecosystem services such as storm protection, nursery habitat for marine species, and water quality improvement.`
    },
    {
      id: 'QLD-003',
      name: 'Wetland Conservation Initiative',
      ecosystem: 'wetlands',
      location: 'Queensland, Australia',
      status: 'under_review',
      lastUpdate: '2024-08-28',
      verificationStage: 'Field Verification',
      area: 320,
      creditsIssued: 0,
      coordinates: { lat: -27.4698, lng: 153.0251 },
      description: `A large-scale wetland conservation project in Queensland focusing on protecting and restoring critical freshwater wetland ecosystems. The project covers 320 hectares of diverse wetland habitats including freshwater marshes, swamps, and riparian zones.\n\nKey activities include invasive species management, water level restoration, native vegetation replanting, and establishment of buffer zones to protect water quality and wildlife corridors.`
    },
    {
      id: 'BD-002',
      name: 'Seagrass Protection Program',
      ecosystem: 'seagrass',
      location: 'Sundarbans, Bangladesh',
      status: 'submitted',
      lastUpdate: '2024-08-25',
      verificationStage: 'Data Collection',
      area: 85,
      creditsIssued: 0,
      coordinates: { lat: 21.9497, lng: 89.1833 },
      description: `An innovative seagrass protection and restoration program in the Sundarbans region, targeting critical seagrass meadows that serve as carbon sinks and marine biodiversity hotspots. The project encompasses 85 hectares of seagrass beds in shallow coastal waters.\n\nImplementation includes community-based monitoring, sustainable fishing practices, pollution reduction measures, and seagrass transplantation in degraded areas.`
    },
    {
      id: 'MG-004',
      name: 'Coastal Restoration Project',
      ecosystem: 'mangroves',
      location: 'Mahajanga, Madagascar',
      status: 'draft',
      lastUpdate: '2024-08-20',
      verificationStage: 'Not Started',
      area: 200,
      creditsIssued: 0,
      coordinates: { lat: -15.7167, lng: 46.3167 },
      description: `A comprehensive coastal restoration project in Madagascar focusing on mangrove ecosystem rehabilitation along the western coast. The project targets 200 hectares of degraded mangrove areas, implementing community-based restoration approaches.\n\nThe initiative combines scientific restoration techniques with local traditional knowledge, creating sustainable livelihoods while restoring critical coastal protection and carbon sequestration services.`
    },
    {
      id: 'CA-005',
      name: 'Pacific Wetland Restoration',
      ecosystem: 'wetlands',
      location: 'California, USA',
      status: 'verified',
      lastUpdate: '2024-08-29',
      verificationStage: 'Completed',
      area: 275,
      creditsIssued: 3200,
      coordinates: { lat: 37.7749, lng: -122.4194 },
      description: `A flagship wetland restoration project in California's San Francisco Bay Area, focusing on tidal marsh restoration and enhancement. The project covers 275 hectares of former agricultural land being converted back to functional wetland ecosystems.\n\nKey components include sediment management, native plant establishment, wildlife habitat creation, and integration with existing conservation areas to create wildlife corridors.`
    },
    {
      id: 'TH-006',name: 'Mangrove Conservation Thailand',ecosystem: 'mangroves',location: 'Krabi, Thailand',status: 'under_review',lastUpdate: '2024-08-27',
      verificationStage: 'Third Party Review',
      area: 180,
      creditsIssued: 0,
      coordinates: { lat: 8.0863, lng: 98.9063 },
      description: `A community-driven mangrove conservation project in Krabi Province, Thailand, focusing on protecting existing mangrove forests while restoring degraded areas. The project encompasses 180 hectares of mangrove ecosystems along the Andaman Sea coast.\n\nThe initiative emphasizes sustainable ecotourism development, community education, and alternative livelihood creation to reduce pressure on mangrove resources while maintaining ecosystem integrity.`
    },
    {
      id: 'BR-007',name: 'Amazon Wetland Protection',ecosystem: 'wetlands',location: 'Pantanal, Brazil',status: 'rejected',lastUpdate: '2024-08-15',
      verificationStage: 'Not Started',
      area: 450,
      creditsIssued: 0,
      coordinates: { lat: -16.5000, lng: -56.6167 },
      description: `An ambitious wetland protection project in Brazil's Pantanal region, targeting one of the world's largest tropical wetland areas. The project aimed to protect 450 hectares of critical wetland habitat through conservation agreements and sustainable management practices.\n\nDespite comprehensive planning, the project was rejected due to insufficient baseline data and concerns about long-term monitoring capabilities in the remote location.`
    },
    {
      id: 'PH-008',name: 'Seagrass Restoration Philippines',ecosystem: 'seagrass',location: 'Palawan, Philippines',status: 'submitted',lastUpdate: '2024-08-26',
      verificationStage: 'Data Collection',
      area: 120,
      creditsIssued: 0,
      coordinates: { lat: 9.8349, lng: 118.7384 },
      description: `A marine ecosystem restoration project in Palawan, Philippines, focusing on seagrass meadow rehabilitation in coral reef lagoons. The project covers 120 hectares of seagrass habitat critical for marine biodiversity and carbon sequestration.\n\nImplementation includes community-based seagrass monitoring, sustainable fishing zone establishment, marine protected area management, and seagrass transplantation using locally adapted species.`
    }
  ];

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMenuToggle = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleProjectSelect = (project) => {
    setSelectedProject(project);
    setIsDetailModalOpen(true);
  };

  const handleBulkAction = (action) => {
    console.log(`Performing bulk action: ${action} on projects:`, selectedProjects);
    // Handle bulk actions here
  };

  const handleAddProject = () => {
    window.location.href = '/project-registration';
  };

  const handleExportData = () => {
    console.log('Exporting project data...');
    // Handle data export
  };

  useEffect(() => {
    document.title = 'Project Management - BlueCarbon Registry';
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuToggle={handleMenuToggle} isMenuOpen={isMenuOpen} />
      <Sidebar isCollapsed={isSidebarCollapsed} onToggle={handleSidebarToggle} />
      
      <main className={`pt-16 transition-all duration-200 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
      }`}>
        <div className="p-6">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Project Management</h1>
                <p className="mt-2 text-muted-foreground">
                  Manage and monitor your blue carbon projects with comprehensive tracking and verification tools
                </p>
              </div>
              <div className="mt-4 sm:mt-0 flex flex-col sm:flex-row gap-3">
                <Button 
                  variant="outline" 
                  onClick={handleExportData}
                  iconName="Download"
                  iconPosition="left"
                >
                  Export Data
                </Button>
                <Button 
                  variant="default" 
                  onClick={handleAddProject}
                  iconName="Plus"
                  iconPosition="left"
                >
                  Add New Project
                </Button>
              </div>
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
            {/* Left Section - Project Table */}
            <div className="xl:col-span-8">
              <ProjectTable
                projects={projects}
                onProjectSelect={handleProjectSelect}
                onBulkAction={handleBulkAction}
                selectedProjects={selectedProjects}
                onSelectionChange={setSelectedProjects}
              />
            </div>

            {/* Right Section - Summary and Actions */}
            <div className="xl:col-span-4 space-y-6">
              <ProjectSummaryCards projects={projects} />
              <StatusDistributionChart projects={projects} />
              <QuickActionPanel 
                selectedProjects={selectedProjects}
                onBulkAction={handleBulkAction}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Project Detail Modal */}
      <ProjectDetailModal
        project={selectedProject}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
      />
    </div>
  );
};

export default ProjectManagement;