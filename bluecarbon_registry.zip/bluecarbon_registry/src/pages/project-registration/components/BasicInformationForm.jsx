import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';

const BasicInformationForm = ({ formData, onUpdate, errors = {} }) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  const ecosystemTypes = [
    { value: 'mangroves', label: 'Mangroves', description: 'Coastal wetland forests' },
    { value: 'seagrass', label: 'Seagrass Meadows', description: 'Marine flowering plants' },
    { value: 'salt_marshes', label: 'Salt Marshes', description: 'Coastal wetlands with salt-tolerant plants' },
    { value: 'kelp_forests', label: 'Kelp Forests', description: 'Large brown algae underwater forests' },
    { value: 'coastal_wetlands', label: 'Coastal Wetlands', description: 'Mixed coastal ecosystems' }
  ];

  const projectTypes = [
    { value: 'restoration', label: 'Restoration', description: 'Restoring degraded ecosystems' },
    { value: 'conservation', label: 'Conservation', description: 'Protecting existing ecosystems' },
    { value: 'sustainable_management', label: 'Sustainable Management', description: 'Improved management practices' },
    { value: 'avoided_conversion', label: 'Avoided Conversion', description: 'Preventing ecosystem destruction' }
  ];

  const handleInputChange = (field, value) => {
    onUpdate({ [field]: value });
  };

  return (
    <div className="space-y-6">
      {/* Project Name */}
      <Input
        label="Project Name"
        type="text"
        placeholder="Enter your blue carbon project name"
        value={formData?.projectName || ''}
        onChange={(e) => handleInputChange('projectName', e?.target?.value)}
        error={errors?.projectName}
        required
        description="Choose a descriptive name that reflects your project's purpose"
      />
      {/* Project Description */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-foreground">
          Project Description <span className="text-destructive">*</span>
        </label>
        <textarea
          className="w-full min-h-[120px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
          placeholder="Provide a detailed description of your blue carbon project, including objectives, expected outcomes, and environmental benefits..."
          value={formData?.projectDescription || ''}
          onChange={(e) => handleInputChange('projectDescription', e?.target?.value)}
          maxLength={2000}
        />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Minimum 100 characters recommended</span>
          <span>{(formData?.projectDescription || '')?.length}/2000</span>
        </div>
        {errors?.projectDescription && (
          <p className="text-sm text-destructive">{errors?.projectDescription}</p>
        )}
      </div>
      {/* Ecosystem Type */}
      <Select
        label="Primary Ecosystem Type"
        description="Select the main blue carbon ecosystem in your project"
        options={ecosystemTypes}
        value={formData?.ecosystemType || ''}
        onChange={(value) => handleInputChange('ecosystemType', value)}
        error={errors?.ecosystemType}
        required
        searchable
        placeholder="Choose ecosystem type"
      />
      {/* Project Type */}
      <Select
        label="Project Type"
        description="Select the type of intervention your project involves"
        options={projectTypes}
        value={formData?.projectType || ''}
        onChange={(value) => handleInputChange('projectType', value)}
        error={errors?.projectType}
        required
        placeholder="Choose project type"
      />
      {/* Project Duration */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Project Start Date"
          type="date"
          value={formData?.startDate || ''}
          onChange={(e) => handleInputChange('startDate', e?.target?.value)}
          error={errors?.startDate}
          required
        />
        <Input
          label="Project End Date"
          type="date"
          value={formData?.endDate || ''}
          onChange={(e) => handleInputChange('endDate', e?.target?.value)}
          error={errors?.endDate}
          required
        />
      </div>
      {/* Advanced Options Toggle */}
      <div className="border-t border-border pt-6">
        <button
          type="button"
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center space-x-2 text-sm font-medium text-primary hover:text-primary/80 transition-smooth"
        >
          <Icon 
            name={showAdvanced ? 'ChevronUp' : 'ChevronDown'} 
            size={16} 
          />
          <span>Advanced Project Details</span>
        </button>

        {showAdvanced && (
          <div className="mt-6 space-y-6 bg-muted/30 p-6 rounded-lg">
            {/* Project Scale */}
            <Input
              label="Project Scale (hectares)"
              type="number"
              placeholder="Enter total project area"
              value={formData?.projectScale || ''}
              onChange={(e) => handleInputChange('projectScale', e?.target?.value)}
              error={errors?.projectScale}
              min="0.1"
              step="0.1"
              description="Total area covered by the project in hectares"
            />

            {/* Expected Carbon Sequestration */}
            <Input
              label="Expected Annual Carbon Sequestration (tCO2e)"
              type="number"
              placeholder="Estimated carbon sequestration per year"
              value={formData?.expectedSequestration || ''}
              onChange={(e) => handleInputChange('expectedSequestration', e?.target?.value)}
              error={errors?.expectedSequestration}
              min="0"
              step="0.01"
              description="Projected annual carbon sequestration in metric tons CO2 equivalent"
            />

            {/* Project Partners */}
            <Input
              label="Key Project Partners"
              type="text"
              placeholder="List main partners, organizations, or collaborators"
              value={formData?.projectPartners || ''}
              onChange={(e) => handleInputChange('projectPartners', e?.target?.value)}
              error={errors?.projectPartners}
              description="Separate multiple partners with commas"
            />

            {/* Funding Source */}
            <Input
              label="Primary Funding Source"
              type="text"
              placeholder="Government, Private, NGO, Mixed, etc."
              value={formData?.fundingSource || ''}
              onChange={(e) => handleInputChange('fundingSource', e?.target?.value)}
              error={errors?.fundingSource}
            />

            {/* Certification Standards */}
            <div className="space-y-3">
              <label className="block text-sm font-medium text-foreground">
                Certification Standards
              </label>
              <div className="space-y-2">
                <Checkbox
                  label="Verified Carbon Standard (VCS)"
                  checked={formData?.certifications?.vcs || false}
                  onChange={(e) => handleInputChange('certifications', {
                    ...formData?.certifications,
                    vcs: e?.target?.checked
                  })}
                />
                <Checkbox
                  label="Gold Standard"
                  checked={formData?.certifications?.goldStandard || false}
                  onChange={(e) => handleInputChange('certifications', {
                    ...formData?.certifications,
                    goldStandard: e?.target?.checked
                  })}
                />
                <Checkbox
                  label="Climate Action Reserve (CAR)"
                  checked={formData?.certifications?.car || false}
                  onChange={(e) => handleInputChange('certifications', {
                    ...formData?.certifications,
                    car: e?.target?.checked
                  })}
                />
                <Checkbox
                  label="Plan Vivo"
                  checked={formData?.certifications?.planVivo || false}
                  onChange={(e) => handleInputChange('certifications', {
                    ...formData?.certifications,
                    planVivo: e?.target?.checked
                  })}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BasicInformationForm;