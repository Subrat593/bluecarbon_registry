import React, { useState, useCallback } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const DocumentationUploadForm = ({ formData, onUpdate, errors = {} }) => {
  const [dragActive, setDragActive] = useState({});
  const [uploadProgress, setUploadProgress] = useState({});

  const documentCategories = [
    {
      id: 'satellite_imagery',
      title: 'Satellite Imagery',
      description: 'High-resolution satellite images of the project area',
      acceptedFormats: ['.jpg', '.jpeg', '.png', '.tiff', '.geotiff'],
      maxSize: '50MB',
      icon: 'Satellite'
    },
    {
      id: 'iot_data',
      title: 'IoT Sensor Data',
      description: 'CSV/JSON files from environmental sensors',
      acceptedFormats: ['.csv', '.json', '.xlsx'],
      maxSize: '10MB',
      icon: 'Database'
    },
    {
      id: 'field_measurements',
      title: 'Field Measurement Data',
      description: 'Direct field measurements and sampling data',
      acceptedFormats: ['.csv', '.xlsx', '.pdf'],
      maxSize: '25MB',
      icon: 'FileText'
    },
    {
      id: 'project_documents',
      title: 'Project Documents',
      description: 'Project design documents, permits, and reports',
      acceptedFormats: ['.pdf', '.doc', '.docx'],
      maxSize: '25MB',
      icon: 'FileText'
    },
    {
      id: 'baseline_studies',
      title: 'Baseline Studies',
      description: 'Environmental baseline and feasibility studies',
      acceptedFormats: ['.pdf', '.doc', '.docx'],
      maxSize: '50MB',
      icon: 'BookOpen'
    },
    {
      id: 'monitoring_protocols',
      title: 'Monitoring Protocols',
      description: 'Detailed monitoring and verification protocols',
      acceptedFormats: ['.pdf', '.doc', '.docx'],
      maxSize: '25MB',
      icon: 'Activity'
    }
  ];

  const handleDrag = useCallback((e, categoryId) => {
    e?.preventDefault();
    e?.stopPropagation();
    if (e?.type === 'dragenter' || e?.type === 'dragover') {
      setDragActive(prev => ({ ...prev, [categoryId]: true }));
    } else if (e?.type === 'dragleave') {
      setDragActive(prev => ({ ...prev, [categoryId]: false }));
    }
  }, []);

  const handleDrop = useCallback((e, categoryId) => {
    e?.preventDefault();
    e?.stopPropagation();
    setDragActive(prev => ({ ...prev, [categoryId]: false }));

    if (e?.dataTransfer?.files && e?.dataTransfer?.files?.[0]) {
      handleFiles(e?.dataTransfer?.files, categoryId);
    }
  }, []);

  const handleFiles = (files, categoryId) => {
    const fileArray = Array.from(files);
    const currentFiles = formData?.[categoryId] || [];
    
    // Simulate file upload with progress
    fileArray?.forEach((file, index) => {
      const fileId = `${categoryId}_${Date.now()}_${index}`;
      
      // Add file to form data immediately
      const newFile = {
        id: fileId,
        name: file?.name,
        size: file?.size,
        type: file?.type,
        uploadProgress: 0,
        uploaded: false
      };
      
      onUpdate({
        [categoryId]: [...currentFiles, newFile]
      });

      // Simulate upload progress
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 30;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          
          // Update file as uploaded
          onUpdate({
            [categoryId]: (formData?.[categoryId] || [])?.map(f => 
              f?.id === fileId ? { ...f, uploadProgress: 100, uploaded: true } : f
            )
          });
        }
        
        setUploadProgress(prev => ({
          ...prev,
          [fileId]: Math.min(progress, 100)
        }));
      }, 200);
    });
  };

  const handleFileInput = (e, categoryId) => {
    if (e?.target?.files) {
      handleFiles(e?.target?.files, categoryId);
    }
  };

  const removeFile = (categoryId, fileId) => {
    const updatedFiles = (formData?.[categoryId] || [])?.filter(file => file?.id !== fileId);
    onUpdate({ [categoryId]: updatedFiles });
    
    // Remove progress tracking
    setUploadProgress(prev => {
      const newProgress = { ...prev };
      delete newProgress?.[fileId];
      return newProgress;
    });
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i))?.toFixed(2)) + ' ' + sizes?.[i];
  };

  const getUploadStats = () => {
    let totalFiles = 0;
    let uploadedFiles = 0;
    
    documentCategories?.forEach(category => {
      const files = formData?.[category?.id] || [];
      totalFiles += files?.length;
      uploadedFiles += files?.filter(f => f?.uploaded)?.length;
    });
    
    return { totalFiles, uploadedFiles };
  };

  const { totalFiles, uploadedFiles } = getUploadStats();

  return (
    <div className="space-y-6">
      {/* Upload Progress Summary */}
      {totalFiles > 0 && (
        <div className="bg-muted/30 p-4 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-foreground">Upload Progress</span>
            <span className="text-sm text-muted-foreground">{uploadedFiles}/{totalFiles} files</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${totalFiles > 0 ? (uploadedFiles / totalFiles) * 100 : 0}%` }}
            />
          </div>
        </div>
      )}
      {/* Document Categories */}
      <div className="space-y-6">
        {documentCategories?.map((category) => {
          const files = formData?.[category?.id] || [];
          const isDragActive = dragActive?.[category?.id];
          
          return (
            <div key={category?.id} className="space-y-4">
              <div className="flex items-center space-x-3">
                <Icon name={category?.icon} size={24} className="text-primary" />
                <div>
                  <h3 className="text-lg font-medium text-foreground">{category?.title}</h3>
                  <p className="text-sm text-muted-foreground">{category?.description}</p>
                </div>
              </div>
              {/* Upload Area */}
              <div
                className={`relative border-2 border-dashed rounded-lg p-6 transition-all duration-200 ${
                  isDragActive 
                    ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50 bg-muted/20'
                }`}
                onDragEnter={(e) => handleDrag(e, category?.id)}
                onDragLeave={(e) => handleDrag(e, category?.id)}
                onDragOver={(e) => handleDrag(e, category?.id)}
                onDrop={(e) => handleDrop(e, category?.id)}
              >
                <input
                  type="file"
                  multiple
                  accept={category?.acceptedFormats?.join(',')}
                  onChange={(e) => handleFileInput(e, category?.id)}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                
                <div className="text-center">
                  <Icon 
                    name="Upload" 
                    size={48} 
                    className={`mx-auto mb-4 ${isDragActive ? 'text-primary' : 'text-muted-foreground'}`} 
                  />
                  <p className="text-lg font-medium text-foreground mb-2">
                    {isDragActive ? 'Drop files here' : 'Drag & drop files or click to browse'}
                  </p>
                  <p className="text-sm text-muted-foreground mb-4">
                    Accepted formats: {category?.acceptedFormats?.join(', ')} • Max size: {category?.maxSize}
                  </p>
                  <Button variant="outline" size="sm">
                    Choose Files
                  </Button>
                </div>
              </div>
              {/* File List */}
              {files?.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-foreground">Uploaded Files ({files?.length})</h4>
                  <div className="space-y-2">
                    {files?.map((file) => {
                      let progress = uploadProgress?.[file?.id] || 0;
                      
                      return (
                        <div key={file?.id} className="flex items-center space-x-3 p-3 bg-card border border-border rounded-lg">
                          <div className="flex-shrink-0">
                            {file?.uploaded ? (
                              <div className="w-8 h-8 bg-success rounded-full flex items-center justify-center">
                                <Icon name="Check" size={16} color="white" />
                              </div>
                            ) : (
                              <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                                <Icon name="File" size={16} className="text-muted-foreground" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <p className="text-sm font-medium text-foreground truncate">{file?.name}</p>
                              <span className="text-xs text-muted-foreground">{formatFileSize(file?.size)}</span>
                            </div>
                            
                            {!file?.uploaded && (
                              <div className="w-full bg-muted rounded-full h-1.5">
                                <div 
                                  className="bg-primary h-1.5 rounded-full transition-all duration-300"
                                  style={{ width: `${progress}%` }}
                                />
                              </div>
                            )}
                            
                            {file?.uploaded && (
                              <p className="text-xs text-success">Upload complete</p>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeFile(category?.id, file?.id)}
                            iconName="X"
                            iconSize={16}
                            className="text-muted-foreground hover:text-destructive"
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
              {errors?.[category?.id] && (
                <p className="text-sm text-destructive">{errors?.[category?.id]}</p>
              )}
            </div>
          );
        })}
      </div>
      {/* Upload Guidelines */}
      <div className="bg-muted/30 p-6 rounded-lg space-y-4">
        <div className="flex items-center space-x-2">
          <Icon name="Info" size={20} className="text-primary" />
          <h3 className="text-lg font-medium text-foreground">Upload Guidelines</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-muted-foreground">
          <div className="space-y-2">
            <h4 className="font-medium text-foreground">File Requirements:</h4>
            <ul className="space-y-1 list-disc list-inside">
              <li>Files must be in the specified formats for each category</li>
              <li>Maximum file size limits apply per category</li>
              <li>Multiple files can be uploaded for each category</li>
              <li>File names should be descriptive and meaningful</li>
            </ul>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-medium text-foreground">Data Quality:</h4>
            <ul className="space-y-1 list-disc list-inside">
              <li>Ensure data is complete and accurate</li>
              <li>Include metadata and documentation where possible</li>
              <li>Verify file integrity before uploading</li>
              <li>Use consistent naming conventions</li>
            </ul>
          </div>
        </div>
        
        <div className="flex items-start space-x-2 p-3 bg-warning/10 border border-warning/20 rounded-md">
          <Icon name="AlertTriangle" size={16} className="text-warning mt-0.5" />
          <div className="text-sm">
            <p className="font-medium text-warning">Important:</p>
            <p className="text-muted-foreground">All uploaded files will be reviewed during the verification process. Ensure all data is accurate and complete before submission.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentationUploadForm;