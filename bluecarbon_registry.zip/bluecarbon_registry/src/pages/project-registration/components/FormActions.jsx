import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const FormActions = ({ 
  formData, 
  validationErrors, 
  onSave, 
  onSubmit, 
  onPreview,
  isLoading = false,
  autoSaveStatus = 'saved' // 'saving', 'saved', 'error'
}) => {
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [submitType, setSubmitType] = useState('');

  const getFormCompletionStatus = () => {
    const requiredFields = [
      'projectName', 'projectDescription', 'ecosystemType', 'projectType', 
      'startDate', 'endDate', 'country', 'region', 'city', 
      'centerLatitude', 'centerLongitude', 'waterBodyType',
      'methodology', 'baselineCarbon', 'baselineDate', 'monitoringFrequency'
    ];

    const completedFields = requiredFields?.filter(field => {
      const value = formData?.[field];
      return value && value?.toString()?.trim() !== '';
    });

    const hasErrors = Object.keys(validationErrors)?.length > 0;
    const completionPercentage = Math.round((completedFields?.length / requiredFields?.length) * 100);
    const isComplete = completionPercentage === 100 && !hasErrors;

    return {
      completionPercentage,
      isComplete,
      hasErrors,
      missingFields: requiredFields?.filter(field => !formData?.[field] || formData?.[field]?.toString()?.trim() === '')
    };
  };

  const { completionPercentage, isComplete, hasErrors, missingFields } = getFormCompletionStatus();

  const handleSubmitClick = (type) => {
    if (type === 'submit' && (!isComplete || hasErrors)) {
      setSubmitType(type);
      setShowConfirmDialog(true);
      return;
    }
    
    if (type === 'submit') {
      onSubmit();
    } else {
      onSave();
    }
  };

  const handleConfirmSubmit = () => {
    setShowConfirmDialog(false);
    if (submitType === 'submit') {
      onSubmit();
    }
  };

  const getAutoSaveIcon = () => {
    switch (autoSaveStatus) {
      case 'saving':
        return { name: 'Loader2', color: 'text-warning', spin: true };
      case 'saved':
        return { name: 'Check', color: 'text-success' };
      case 'error':
        return { name: 'AlertCircle', color: 'text-destructive' };
      default:
        return { name: 'Save', color: 'text-muted-foreground' };
    }
  };

  const autoSaveIcon = getAutoSaveIcon();

  return (
    <>
      <div className="sticky bottom-0 bg-card border-t border-border p-4">
        <div className="flex flex-col space-y-4">
          {/* Form Status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {/* Auto-save Status */}
              <div className="flex items-center space-x-2 text-sm">
                <Icon 
                  name={autoSaveIcon?.name} 
                  size={16} 
                  className={`${autoSaveIcon?.color} ${autoSaveIcon?.spin ? 'animate-spin' : ''}`}
                />
                <span className="text-muted-foreground">
                  {autoSaveStatus === 'saving' && 'Saving...'}
                  {autoSaveStatus === 'saved' && 'All changes saved'}
                  {autoSaveStatus === 'error' && 'Save failed'}
                </span>
              </div>

              {/* Completion Status */}
              <div className="hidden sm:flex items-center space-x-2 text-sm">
                <div className="w-16 bg-muted rounded-full h-1.5">
                  <div 
                    className="bg-primary h-1.5 rounded-full transition-all duration-300"
                    style={{ width: `${completionPercentage}%` }}
                  />
                </div>
                <span className="text-muted-foreground">{completionPercentage}% complete</span>
              </div>
            </div>

            {/* Form Validation Status */}
            {hasErrors && (
              <div className="flex items-center space-x-2 text-sm text-destructive">
                <Icon name="AlertCircle" size={16} />
                <span>Please fix errors before submitting</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
            {/* Save Draft */}
            <Button
              variant="outline"
              onClick={() => handleSubmitClick('save')}
              disabled={isLoading}
              loading={isLoading && submitType === 'save'}
              iconName="Save"
              iconPosition="left"
              iconSize={16}
              className="flex-1 sm:flex-none"
            >
              Save Draft
            </Button>

            {/* Preview */}
            <Button
              variant="secondary"
              onClick={onPreview}
              disabled={isLoading}
              iconName="Eye"
              iconPosition="left"
              iconSize={16}
              className="flex-1 sm:flex-none"
            >
              Preview Application
            </Button>

            {/* Submit */}
            <Button
              variant="default"
              onClick={() => handleSubmitClick('submit')}
              disabled={isLoading}
              loading={isLoading && submitType === 'submit'}
              iconName="Send"
              iconPosition="left"
              iconSize={16}
              className="flex-1 sm:flex-none"
            >
              Submit for Review
            </Button>
          </div>

          {/* Mobile Completion Status */}
          <div className="sm:hidden">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Form completion</span>
              <span className="font-medium text-foreground">{completionPercentage}%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-1.5 mt-1">
              <div 
                className="bg-primary h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${completionPercentage}%` }}
              />
            </div>
          </div>

          {/* Warning for incomplete form */}
          {!isComplete && (
            <div className="bg-warning/10 border border-warning/20 rounded-lg p-3">
              <div className="flex items-start space-x-2">
                <Icon name="AlertTriangle" size={16} className="text-warning mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-warning">Form Incomplete</p>
                  <p className="text-muted-foreground mt-1">
                    {missingFields?.length} required field{missingFields?.length !== 1 ? 's' : ''} remaining. 
                    You can save as draft and complete later, or fill all fields to submit for review.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* Confirmation Dialog */}
      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-lg max-w-md w-full p-6">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-10 h-10 bg-warning/10 rounded-full flex items-center justify-center">
                <Icon name="AlertTriangle" size={20} className="text-warning" />
              </div>
              
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Submit Incomplete Form?
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Your form is {completionPercentage}% complete with {missingFields?.length} required fields missing. 
                  Submitting an incomplete form may delay the review process.
                </p>
                
                {missingFields?.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-foreground mb-2">Missing required fields:</p>
                    <ul className="text-xs text-muted-foreground space-y-1 max-h-32 overflow-y-auto">
                      {missingFields?.slice(0, 10)?.map((field) => (
                        <li key={field} className="capitalize">
                          • {field?.replace(/([A-Z])/g, ' $1')?.replace(/^./, str => str?.toUpperCase())}
                        </li>
                      ))}
                      {missingFields?.length > 10 && (
                        <li className="text-muted-foreground">... and {missingFields?.length - 10} more</li>
                      )}
                    </ul>
                  </div>
                )}
              </div>
            </div>

            <div className="flex space-x-3 mt-6">
              <Button
                variant="outline"
                onClick={() => setShowConfirmDialog(false)}
                className="flex-1"
              >
                Continue Editing
              </Button>
              <Button
                variant="default"
                onClick={handleConfirmSubmit}
                className="flex-1"
              >
                Submit Anyway
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default FormActions;