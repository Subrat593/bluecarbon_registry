import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const FormProgressSidebar = ({ 
  currentSection, 
  onSectionChange, 
  formData, 
  validationErrors,
  isCollapsed = false,
  onToggle 
}) => {
  const sections = [
    {
      id: 'basic',
      title: 'Basic Information',
      icon: 'FileText',
      fields: ['projectName', 'projectDescription', 'ecosystemType', 'projectType', 'startDate', 'endDate']
    },
    {
      id: 'location',
      title: 'Location Details',
      icon: 'MapPin',
      fields: ['country', 'region', 'city', 'centerLatitude', 'centerLongitude', 'waterBodyType']
    },
    {
      id: 'technical',
      title: 'Technical Specifications',
      icon: 'Settings',
      fields: ['methodology', 'baselineCarbon', 'baselineDate', 'monitoringFrequency', 'measurementMethods']
    },
    {
      id: 'documentation',
      title: 'Documentation Upload',
      icon: 'Upload',
      fields: ['satellite_imagery', 'iot_data', 'field_measurements', 'project_documents']
    }
  ];

  const getSectionStatus = (section) => {
    const requiredFields = section?.fields;
    let completedFields = requiredFields?.filter(field => {
      const value = formData?.[field];
      if (Array.isArray(value)) {
        return value?.length > 0;
      }
      return value && value?.toString()?.trim() !== '';
    });

    const hasErrors = requiredFields?.some(field => validationErrors?.[field]);
    const isComplete = completedFields?.length === requiredFields?.length;
    const isPartial = completedFields?.length > 0 && completedFields?.length < requiredFields?.length;

    if (hasErrors) return 'error';
    if (isComplete) return 'complete';
    if (isPartial) return 'partial';
    return 'pending';
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'complete':
        return { name: 'CheckCircle', color: 'text-success' };
      case 'partial':
        return { name: 'Clock', color: 'text-warning' };
      case 'error':
        return { name: 'AlertCircle', color: 'text-destructive' };
      default:
        return { name: 'Circle', color: 'text-muted-foreground' };
    }
  };

  const getCompletionPercentage = () => {
    let totalFields = 0;
    let completedFields = 0;

    sections?.forEach(section => {
      totalFields += section?.fields?.length;
      completedFields += section?.fields?.filter(field => {
        const value = formData?.[field];
        if (Array.isArray(value)) {
          return value?.length > 0;
        }
        return value && value?.toString()?.trim() !== '';
      })?.length;
    });

    return totalFields > 0 ? Math.round((completedFields / totalFields) * 100) : 0;
  };

  const completionPercentage = getCompletionPercentage();

  return (
    <div className={`bg-card border-r border-border transition-all duration-200 ${
      isCollapsed ? 'w-16' : 'w-80'
    }`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div>
              <h2 className="text-lg font-semibold text-foreground">Form Progress</h2>
              <p className="text-sm text-muted-foreground">{completionPercentage}% Complete</p>
            </div>
          )}
          
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggle}
            iconName={isCollapsed ? 'ChevronRight' : 'ChevronLeft'}
            iconSize={20}
          />
        </div>

        {!isCollapsed && (
          <div className="mt-4">
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${completionPercentage}%` }}
              />
            </div>
          </div>
        )}
      </div>
      {/* Section Navigation */}
      <nav className="p-2">
        <div className="space-y-1">
          {sections?.map((section, index) => {
            const status = getSectionStatus(section);
            const statusIcon = getStatusIcon(status);
            const isActive = currentSection === section?.id;
            
            return (
              <button
                key={section?.id}
                onClick={() => onSectionChange(section?.id)}
                className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-smooth ${
                  isActive 
                    ? 'bg-primary text-primary-foreground' 
                    : 'hover:bg-muted text-foreground'
                }`}
                title={isCollapsed ? section?.title : undefined}
              >
                {/* Section Number */}
                <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                  isActive 
                    ? 'bg-primary-foreground text-primary' 
                    : 'bg-muted text-muted-foreground'
                }`}>
                  {index + 1}
                </div>
                {!isCollapsed && (
                  <>
                    {/* Section Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <Icon name={section?.icon} size={16} />
                        <span className="text-sm font-medium truncate">{section?.title}</span>
                      </div>
                    </div>

                    {/* Status Icon */}
                    <div className="flex-shrink-0">
                      <Icon 
                        name={statusIcon?.name} 
                        size={16} 
                        className={isActive ? 'text-primary-foreground' : statusIcon?.color}
                      />
                    </div>
                  </>
                )}
                {isCollapsed && (
                  <div className="flex-shrink-0">
                    <Icon 
                      name={statusIcon?.name} 
                      size={16} 
                      className={statusIcon?.color}
                    />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </nav>
      {/* Section Details */}
      {!isCollapsed && (
        <div className="p-4 border-t border-border">
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-foreground">Section Status</h3>
            
            {sections?.map((section) => {
              const status = getSectionStatus(section);
              const completedCount = section?.fields?.filter(field => {
                const value = formData?.[field];
                if (Array.isArray(value)) {
                  return value?.length > 0;
                }
                return value && value?.toString()?.trim() !== '';
              })?.length;
              
              return (
                <div key={section?.id} className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{section?.title}</span>
                  <span className={`font-medium ${
                    status === 'complete' ? 'text-success' :
                    status === 'partial' ? 'text-warning' :
                    status === 'error'? 'text-destructive' : 'text-muted-foreground'
                  }`}>
                    {completedCount}/{section?.fields?.length}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
      {/* Help Section */}
      {!isCollapsed && (
        <div className="p-4 border-t border-border">
          <div className="bg-muted/50 p-3 rounded-lg">
            <div className="flex items-start space-x-2">
              <Icon name="HelpCircle" size={16} className="text-primary mt-0.5" />
              <div className="text-xs">
                <p className="font-medium text-foreground mb-1">Need Help?</p>
                <p className="text-muted-foreground">
                  Complete all required fields in each section to proceed with your project registration.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FormProgressSidebar;