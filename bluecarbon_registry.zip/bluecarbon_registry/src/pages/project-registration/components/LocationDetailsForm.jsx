import React, { useState, useEffect } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const LocationDetailsForm = ({ formData, onUpdate, errors = {} }) => {
  const [mapMode, setMapMode] = useState('view'); // 'view', 'draw', 'edit'
  const [coordinates, setCoordinates] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState('');

  const countries = [
    { value: 'us', label: 'United States' },
    { value: 'ca', label: 'Canada' },
    { value: 'mx', label: 'Mexico' },
    { value: 'au', label: 'Australia' },
    { value: 'br', label: 'Brazil' },
    { value: 'in', label: 'India' },
    { value: 'id', label: 'Indonesia' },
    { value: 'ph', label: 'Philippines' },
    { value: 'th', label: 'Thailand' },
    { value: 'my', label: 'Malaysia' }
  ];

  const waterBodies = [
    { value: 'ocean', label: 'Ocean' },
    { value: 'sea', label: 'Sea' },
    { value: 'bay', label: 'Bay' },
    { value: 'estuary', label: 'Estuary' },
    { value: 'lagoon', label: 'Lagoon' },
    { value: 'river_mouth', label: 'River Mouth' },
    { value: 'coastal_lake', label: 'Coastal Lake' }
  ];

  const handleInputChange = (field, value) => {
    onUpdate({ [field]: value });
  };

  const handleCoordinateAdd = () => {
    const newCoordinate = {
      id: Date.now(),
      latitude: '',
      longitude: '',
      label: `Point ${coordinates?.length + 1}`
    };
    setCoordinates([...coordinates, newCoordinate]);
  };

  const handleCoordinateUpdate = (id, field, value) => {
    setCoordinates(coords => 
      coords?.map(coord => 
        coord?.id === id ? { ...coord, [field]: value } : coord
      )
    );
    onUpdate({ coordinates: coordinates });
  };

  const handleCoordinateRemove = (id) => {
    const updatedCoords = coordinates?.filter(coord => coord?.id !== id);
    setCoordinates(updatedCoords);
    onUpdate({ coordinates: updatedCoords });
  };

  const generateMapUrl = () => {
    const lat = formData?.centerLatitude || '25.7617';
    const lng = formData?.centerLongitude || '-80.1918';
    return `https://www.google.com/maps?q=${lat},${lng}&z=14&output=embed`;
  };

  useEffect(() => {
    if (formData?.coordinates) {
      setCoordinates(formData?.coordinates);
    }
  }, [formData?.coordinates]);

  return (
    <div className="space-y-6">
      {/* Country and Region */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Select
          label="Country"
          description="Select the country where your project is located"
          options={countries}
          value={formData?.country || ''}
          onChange={(value) => {
            handleInputChange('country', value);
            setSelectedCountry(value);
          }}
          error={errors?.country}
          required
          searchable
          placeholder="Choose country"
        />
        
        <Input
          label="State/Province/Region"
          type="text"
          placeholder="Enter state, province, or region"
          value={formData?.region || ''}
          onChange={(e) => handleInputChange('region', e?.target?.value)}
          error={errors?.region}
          required
        />
      </div>
      {/* City and Postal Code */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="City/Municipality"
          type="text"
          placeholder="Enter nearest city or municipality"
          value={formData?.city || ''}
          onChange={(e) => handleInputChange('city', e?.target?.value)}
          error={errors?.city}
          required
        />
        
        <Input
          label="Postal/ZIP Code"
          type="text"
          placeholder="Enter postal or ZIP code"
          value={formData?.postalCode || ''}
          onChange={(e) => handleInputChange('postalCode', e?.target?.value)}
          error={errors?.postalCode}
        />
      </div>
      {/* Water Body Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Select
          label="Adjacent Water Body Type"
          description="Type of water body adjacent to the project site"
          options={waterBodies}
          value={formData?.waterBodyType || ''}
          onChange={(value) => handleInputChange('waterBodyType', value)}
          error={errors?.waterBodyType}
          required
          placeholder="Choose water body type"
        />
        
        <Input
          label="Water Body Name"
          type="text"
          placeholder="Name of the water body (if known)"
          value={formData?.waterBodyName || ''}
          onChange={(e) => handleInputChange('waterBodyName', e?.target?.value)}
          error={errors?.waterBodyName}
        />
      </div>
      {/* Center Coordinates */}
      <div className="bg-muted/30 p-6 rounded-lg space-y-4">
        <div className="flex items-center space-x-2">
          <Icon name="MapPin" size={20} className="text-primary" />
          <h3 className="text-lg font-medium text-foreground">Project Center Coordinates</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Center Latitude"
            type="number"
            placeholder="e.g., 25.7617"
            value={formData?.centerLatitude || ''}
            onChange={(e) => handleInputChange('centerLatitude', e?.target?.value)}
            error={errors?.centerLatitude}
            required
            step="0.000001"
            min="-90"
            max="90"
            description="Decimal degrees (-90 to 90)"
          />
          
          <Input
            label="Center Longitude"
            type="number"
            placeholder="e.g., -80.1918"
            value={formData?.centerLongitude || ''}
            onChange={(e) => handleInputChange('centerLongitude', e?.target?.value)}
            error={errors?.centerLongitude}
            required
            step="0.000001"
            min="-180"
            max="180"
            description="Decimal degrees (-180 to 180)"
          />
        </div>
      </div>
      {/* Interactive Map */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Map" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Project Location Map</h3>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant={mapMode === 'view' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setMapMode('view')}
              iconName="Eye"
              iconSize={16}
            >
              View
            </Button>
            <Button
              variant={mapMode === 'draw' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setMapMode('draw')}
              iconName="Edit"
              iconSize={16}
            >
              Draw Boundary
            </Button>
          </div>
        </div>

        <div className="w-full h-96 border border-border rounded-lg overflow-hidden bg-muted">
          <iframe
            width="100%"
            height="100%"
            loading="lazy"
            title="Project Location Map"
            referrerPolicy="no-referrer-when-downgrade"
            src={generateMapUrl()}
            className="w-full h-full"
          />
        </div>

        <div className="text-sm text-muted-foreground bg-muted/50 p-3 rounded-md">
          <p className="flex items-center space-x-2">
            <Icon name="Info" size={16} />
            <span>Use the map to visualize your project location. In draw mode, you can define project boundaries by clicking points on the map.</span>
          </p>
        </div>
      </div>
      {/* Boundary Coordinates */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Navigation" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Boundary Coordinates</h3>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handleCoordinateAdd}
            iconName="Plus"
            iconSize={16}
          >
            Add Point
          </Button>
        </div>

        {coordinates?.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Icon name="MapPin" size={48} className="mx-auto mb-4 opacity-50" />
            <p>No boundary points defined yet.</p>
            <p className="text-sm">Add coordinate points to define your project boundaries.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {coordinates?.map((coord, index) => (
              <div key={coord?.id} className="flex items-center space-x-3 p-4 bg-card border border-border rounded-lg">
                <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                  {index + 1}
                </div>
                
                <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-3">
                  <Input
                    label="Label"
                    type="text"
                    placeholder="Point label"
                    value={coord?.label}
                    onChange={(e) => handleCoordinateUpdate(coord?.id, 'label', e?.target?.value)}
                    className="text-sm"
                  />
                  <Input
                    label="Latitude"
                    type="number"
                    placeholder="Latitude"
                    value={coord?.latitude}
                    onChange={(e) => handleCoordinateUpdate(coord?.id, 'latitude', e?.target?.value)}
                    step="0.000001"
                    className="text-sm"
                  />
                  <Input
                    label="Longitude"
                    type="number"
                    placeholder="Longitude"
                    value={coord?.longitude}
                    onChange={(e) => handleCoordinateUpdate(coord?.id, 'longitude', e?.target?.value)}
                    step="0.000001"
                    className="text-sm"
                  />
                </div>
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleCoordinateRemove(coord?.id)}
                  iconName="Trash2"
                  iconSize={16}
                  className="text-destructive hover:text-destructive"
                />
              </div>
            ))}
          </div>
        )}
      </div>
      {/* Additional Location Details */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-foreground">Additional Location Details</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Elevation (meters above sea level)"
            type="number"
            placeholder="Average elevation"
            value={formData?.elevation || ''}
            onChange={(e) => handleInputChange('elevation', e?.target?.value)}
            error={errors?.elevation}
            step="0.1"
            description="Average elevation of the project site"
          />
          
          <Input
            label="Distance from Coast (km)"
            type="number"
            placeholder="Distance to nearest coastline"
            value={formData?.distanceFromCoast || ''}
            onChange={(e) => handleInputChange('distanceFromCoast', e?.target?.value)}
            error={errors?.distanceFromCoast}
            step="0.1"
            min="0"
            description="Distance to the nearest coastline"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-foreground">
            Site Access and Logistics
          </label>
          <textarea
            className="w-full min-h-[100px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
            placeholder="Describe how to access the project site, transportation methods, and any logistical considerations for monitoring and verification activities..."
            value={formData?.siteAccess || ''}
            onChange={(e) => handleInputChange('siteAccess', e?.target?.value)}
            maxLength={1000}
          />
          <div className="text-xs text-muted-foreground text-right">
            {(formData?.siteAccess || '')?.length}/1000
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationDetailsForm;