import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const TechnicalSpecificationsForm = ({ formData, onUpdate, errors = {} }) => {
  const [showMethodologyDetails, setShowMethodologyDetails] = useState(false);
  const [showBaselineData, setShowBaselineData] = useState(false);

  const methodologies = [
    { value: 'vm0007', label: 'VM0007 - REDD+ Methodology Framework', description: 'REDD+ methodology for blue carbon ecosystems' },
    { value: 'vm0033', label: 'VM0033 - Methodology for Tidal Wetland and Seagrass Restoration', description: 'Restoration of coastal wetlands' },
    { value: 'ar-acm0003', label: 'AR-ACM0003 - Afforestation and Reforestation of Lands', description: 'Afforestation/reforestation methodology' },
    { value: 'vm0024', label: 'VM0024 - Methodology for Coastal Wetland Creation', description: 'Creation of new coastal wetlands' },
    { value: 'custom', label: 'Custom Methodology', description: 'Project-specific methodology under development' }
  ];

  const monitoringFrequencies = [
    { value: 'monthly', label: 'Monthly' },
    { value: 'quarterly', label: 'Quarterly' },
    { value: 'biannual', label: 'Bi-annual' },
    { value: 'annual', label: 'Annual' },
    { value: 'custom', label: 'Custom Schedule' }
  ];

  const measurementMethods = [
    { value: 'field_sampling', label: 'Field Sampling', description: 'Direct field measurements and sampling' },
    { value: 'remote_sensing', label: 'Remote Sensing', description: 'Satellite and aerial imagery analysis' },
    { value: 'iot_sensors', label: 'IoT Sensors', description: 'Automated sensor networks' },
    { value: 'drone_surveys', label: 'Drone Surveys', description: 'Unmanned aerial vehicle surveys' },
    { value: 'underwater_surveys', label: 'Underwater Surveys', description: 'Diving and underwater measurements' }
  ];

  const handleInputChange = (field, value) => {
    onUpdate({ [field]: value });
  };

  const handleArrayUpdate = (field, value, checked) => {
    const currentArray = formData?.[field] || [];
    if (checked) {
      onUpdate({ [field]: [...currentArray, value] });
    } else {
      onUpdate({ [field]: currentArray?.filter(item => item !== value) });
    }
  };

  return (
    <div className="space-y-6">
      {/* Carbon Sequestration Methodology */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Icon name="BookOpen" size={20} className="text-primary" />
          <h3 className="text-lg font-medium text-foreground">Carbon Sequestration Methodology</h3>
        </div>

        <Select
          label="Primary Methodology"
          description="Select the carbon accounting methodology for your project"
          options={methodologies}
          value={formData?.methodology || ''}
          onChange={(value) => handleInputChange('methodology', value)}
          error={errors?.methodology}
          required
          searchable
          placeholder="Choose methodology"
        />

        {formData?.methodology === 'custom' && (
          <div className="bg-muted/30 p-4 rounded-lg space-y-4">
            <Input
              label="Custom Methodology Name"
              type="text"
              placeholder="Enter your custom methodology name"
              value={formData?.customMethodologyName || ''}
              onChange={(e) => handleInputChange('customMethodologyName', e?.target?.value)}
              error={errors?.customMethodologyName}
              required
            />
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-foreground">
                Methodology Description
              </label>
              <textarea
                className="w-full min-h-[120px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
                placeholder="Describe your custom methodology, including calculation methods, assumptions, and validation approach..."
                value={formData?.customMethodologyDescription || ''}
                onChange={(e) => handleInputChange('customMethodologyDescription', e?.target?.value)}
                maxLength={1500}
              />
              <div className="text-xs text-muted-foreground text-right">
                {(formData?.customMethodologyDescription || '')?.length}/1500
              </div>
            </div>
          </div>
        )}

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowMethodologyDetails(!showMethodologyDetails)}
          iconName={showMethodologyDetails ? 'ChevronUp' : 'ChevronDown'}
          iconSize={16}
          className="text-primary"
        >
          {showMethodologyDetails ? 'Hide' : 'Show'} Methodology Details
        </Button>

        {showMethodologyDetails && (
          <div className="bg-muted/30 p-6 rounded-lg space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Methodology Version"
                type="text"
                placeholder="e.g., v1.0, v2.1"
                value={formData?.methodologyVersion || ''}
                onChange={(e) => handleInputChange('methodologyVersion', e?.target?.value)}
                error={errors?.methodologyVersion}
              />
              
              <Input
                label="Crediting Period (years)"
                type="number"
                placeholder="e.g., 10, 20, 30"
                value={formData?.creditingPeriod || ''}
                onChange={(e) => handleInputChange('creditingPeriod', e?.target?.value)}
                error={errors?.creditingPeriod}
                min="1"
                max="100"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-foreground">
                Key Methodology Parameters
              </label>
              <textarea
                className="w-full min-h-[100px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
                placeholder="List key parameters, equations, and assumptions used in the methodology..."
                value={formData?.methodologyParameters || ''}
                onChange={(e) => handleInputChange('methodologyParameters', e?.target?.value)}
                maxLength={1000}
              />
            </div>
          </div>
        )}
      </div>
      {/* Baseline Data */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="TrendingUp" size={20} className="text-primary" />
            <h3 className="text-lg font-medium text-foreground">Baseline Data</h3>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowBaselineData(!showBaselineData)}
            iconName={showBaselineData ? 'ChevronUp' : 'ChevronDown'}
            iconSize={16}
            className="text-primary"
          >
            {showBaselineData ? 'Hide' : 'Show'} Details
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Baseline Carbon Stock (tCO2e/ha)"
            type="number"
            placeholder="Initial carbon stock per hectare"
            value={formData?.baselineCarbon || ''}
            onChange={(e) => handleInputChange('baselineCarbon', e?.target?.value)}
            error={errors?.baselineCarbon}
            required
            step="0.01"
            min="0"
            description="Existing carbon stock before project implementation"
          />
          
          <Input
            label="Baseline Assessment Date"
            type="date"
            value={formData?.baselineDate || ''}
            onChange={(e) => handleInputChange('baselineDate', e?.target?.value)}
            error={errors?.baselineDate}
            required
            description="Date when baseline measurements were taken"
          />
        </div>

        {showBaselineData && (
          <div className="bg-muted/30 p-6 rounded-lg space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                label="Aboveground Biomass (tC/ha)"
                type="number"
                placeholder="Above-ground carbon"
                value={formData?.abovegroundBiomass || ''}
                onChange={(e) => handleInputChange('abovegroundBiomass', e?.target?.value)}
                step="0.01"
                min="0"
              />
              
              <Input
                label="Belowground Biomass (tC/ha)"
                type="number"
                placeholder="Below-ground carbon"
                value={formData?.belowgroundBiomass || ''}
                onChange={(e) => handleInputChange('belowgroundBiomass', e?.target?.value)}
                step="0.01"
                min="0"
              />
              
              <Input
                label="Soil Carbon (tC/ha)"
                type="number"
                placeholder="Soil carbon stock"
                value={formData?.soilCarbon || ''}
                onChange={(e) => handleInputChange('soilCarbon', e?.target?.value)}
                step="0.01"
                min="0"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-foreground">
                Baseline Assessment Methodology
              </label>
              <textarea
                className="w-full min-h-[100px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
                placeholder="Describe how baseline measurements were conducted, sampling methods, and data collection protocols..."
                value={formData?.baselineMethodology || ''}
                onChange={(e) => handleInputChange('baselineMethodology', e?.target?.value)}
                maxLength={1000}
              />
            </div>
          </div>
        )}
      </div>
      {/* Monitoring Plan */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Icon name="Activity" size={20} className="text-primary" />
          <h3 className="text-lg font-medium text-foreground">Monitoring Plan</h3>
        </div>

        <Select
          label="Monitoring Frequency"
          description="How often will monitoring activities be conducted"
          options={monitoringFrequencies}
          value={formData?.monitoringFrequency || ''}
          onChange={(value) => handleInputChange('monitoringFrequency', value)}
          error={errors?.monitoringFrequency}
          required
          placeholder="Choose frequency"
        />

        {formData?.monitoringFrequency === 'custom' && (
          <Input
            label="Custom Monitoring Schedule"
            type="text"
            placeholder="Describe your custom monitoring schedule"
            value={formData?.customMonitoringSchedule || ''}
            onChange={(e) => handleInputChange('customMonitoringSchedule', e?.target?.value)}
            error={errors?.customMonitoringSchedule}
            required
          />
        )}

        <div className="space-y-3">
          <label className="block text-sm font-medium text-foreground">
            Measurement Methods <span className="text-destructive">*</span>
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {measurementMethods?.map((method) => (
              <Checkbox
                key={method?.value}
                label={method?.label}
                description={method?.description}
                checked={(formData?.measurementMethods || [])?.includes(method?.value)}
                onChange={(e) => handleArrayUpdate('measurementMethods', method?.value, e?.target?.checked)}
              />
            ))}
          </div>
          {errors?.measurementMethods && (
            <p className="text-sm text-destructive">{errors?.measurementMethods}</p>
          )}
        </div>
      </div>
      {/* Quality Assurance */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Icon name="Shield" size={20} className="text-primary" />
          <h3 className="text-lg font-medium text-foreground">Quality Assurance & Control</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Data Quality Standards"
            type="text"
            placeholder="e.g., ISO 14064, IPCC Guidelines"
            value={formData?.qualityStandards || ''}
            onChange={(e) => handleInputChange('qualityStandards', e?.target?.value)}
            error={errors?.qualityStandards}
            description="Standards followed for data quality assurance"
          />
          
          <Input
            label="Uncertainty Level (%)"
            type="number"
            placeholder="Expected measurement uncertainty"
            value={formData?.uncertaintyLevel || ''}
            onChange={(e) => handleInputChange('uncertaintyLevel', e?.target?.value)}
            error={errors?.uncertaintyLevel}
            step="0.1"
            min="0"
            max="100"
            description="Estimated uncertainty in measurements"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-foreground">
            Quality Control Procedures
          </label>
          <textarea
            className="w-full min-h-[100px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
            placeholder="Describe quality control procedures, data validation methods, and error checking protocols..."
            value={formData?.qualityControlProcedures || ''}
            onChange={(e) => handleInputChange('qualityControlProcedures', e?.target?.value)}
            maxLength={1000}
          />
          <div className="text-xs text-muted-foreground text-right">
            {(formData?.qualityControlProcedures || '')?.length}/1000
          </div>
        </div>
      </div>
      {/* Risk Assessment */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Icon name="AlertTriangle" size={20} className="text-warning" />
          <h3 className="text-lg font-medium text-foreground">Risk Assessment</h3>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-foreground">
              Environmental Risks
            </label>
            <textarea
              className="w-full min-h-[80px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
              placeholder="Identify potential environmental risks (climate change, sea level rise, storms, etc.)..."
              value={formData?.environmentalRisks || ''}
              onChange={(e) => handleInputChange('environmentalRisks', e?.target?.value)}
              maxLength={800}
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-foreground">
              Technical Risks
            </label>
            <textarea
              className="w-full min-h-[80px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
              placeholder="Identify potential technical risks (equipment failure, data loss, methodology changes, etc.)..."
              value={formData?.technicalRisks || ''}
              onChange={(e) => handleInputChange('technicalRisks', e?.target?.value)}
              maxLength={800}
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-foreground">
              Risk Mitigation Strategies
            </label>
            <textarea
              className="w-full min-h-[100px] px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-vertical"
              placeholder="Describe strategies to mitigate identified risks and ensure project continuity..."
              value={formData?.riskMitigation || ''}
              onChange={(e) => handleInputChange('riskMitigation', e?.target?.value)}
              maxLength={1000}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechnicalSpecificationsForm;