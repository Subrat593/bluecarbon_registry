import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import BasicInformationForm from './components/BasicInformationForm';
import LocationDetailsForm from './components/LocationDetailsForm';
import TechnicalSpecificationsForm from './components/TechnicalSpecificationsForm';
import DocumentationUploadForm from './components/DocumentationUploadForm';
import FormProgressSidebar from './components/FormProgressSidebar';
import FormActions from './components/FormActions';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const ProjectRegistration = () => {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [currentSection, setCurrentSection] = useState('basic');
  const [isLoading, setIsLoading] = useState(false);
  const [autoSaveStatus, setAutoSaveStatus] = useState('saved');
  const [showPreview, setShowPreview] = useState(false);

  // Form data state
  const [formData, setFormData] = useState({
    // Basic Information
    projectName: '',
    projectDescription: '',
    ecosystemType: '',
    projectType: '',
    startDate: '',
    endDate: '',
    projectScale: '',
    expectedSequestration: '',
    projectPartners: '',
    fundingSource: '',
    certifications: {},

    // Location Details
    country: '',
    region: '',
    city: '',
    postalCode: '',
    waterBodyType: '',
    waterBodyName: '',
    centerLatitude: '',
    centerLongitude: '',
    coordinates: [],
    elevation: '',
    distanceFromCoast: '',
    siteAccess: '',

    // Technical Specifications
    methodology: '',
    customMethodologyName: '',
    customMethodologyDescription: '',
    methodologyVersion: '',
    creditingPeriod: '',
    methodologyParameters: '',
    baselineCarbon: '',
    baselineDate: '',
    abovegroundBiomass: '',
    belowgroundBiomass: '',
    soilCarbon: '',
    baselineMethodology: '',
    monitoringFrequency: '',
    customMonitoringSchedule: '',
    measurementMethods: [],
    qualityStandards: '',
    uncertaintyLevel: '',
    qualityControlProcedures: '',
    environmentalRisks: '',
    technicalRisks: '',
    riskMitigation: '',

    // Documentation
    satellite_imagery: [],
    iot_data: [],
    field_measurements: [],
    project_documents: [],
    baseline_studies: [],
    monitoring_protocols: []
  });

  const [validationErrors, setValidationErrors] = useState({});

  // Auto-save functionality
  useEffect(() => {
    const autoSaveTimer = setTimeout(() => {
      handleAutoSave();
    }, 2000);

    return () => clearTimeout(autoSaveTimer);
  }, [formData]);

  // Load saved data on component mount
  useEffect(() => {
    const savedData = localStorage.getItem('project-registration-draft');
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData);
        setFormData(parsedData);
      } catch (error) {
        console.error('Error loading saved data:', error);
      }
    }
  }, []);

  const handleAutoSave = async () => {
    setAutoSaveStatus('saving');
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Save to localStorage
      localStorage.setItem('project-registration-draft', JSON.stringify(formData));
      setAutoSaveStatus('saved');
    } catch (error) {
      console.error('Auto-save failed:', error);
      setAutoSaveStatus('error');
    }
  };

  const handleFormUpdate = (updates) => {
    setFormData(prev => ({ ...prev, ...updates }));
    
    // Clear validation errors for updated fields
    const updatedFields = Object.keys(updates);
    setValidationErrors(prev => {
      const newErrors = { ...prev };
      updatedFields?.forEach(field => {
        delete newErrors?.[field];
      });
      return newErrors;
    });
  };

  const validateForm = () => {
    const errors = {};

    // Basic Information validation
    if (!formData?.projectName?.trim()) {
      errors.projectName = 'Project name is required';
    }
    if (!formData?.projectDescription?.trim() || formData?.projectDescription?.length < 100) {
      errors.projectDescription = 'Project description must be at least 100 characters';
    }
    if (!formData?.ecosystemType) {
      errors.ecosystemType = 'Ecosystem type is required';
    }
    if (!formData?.projectType) {
      errors.projectType = 'Project type is required';
    }
    if (!formData?.startDate) {
      errors.startDate = 'Start date is required';
    }
    if (!formData?.endDate) {
      errors.endDate = 'End date is required';
    }
    if (formData?.startDate && formData?.endDate && new Date(formData.startDate) >= new Date(formData.endDate)) {
      errors.endDate = 'End date must be after start date';
    }

    // Location validation
    if (!formData?.country) {
      errors.country = 'Country is required';
    }
    if (!formData?.region?.trim()) {
      errors.region = 'State/Province/Region is required';
    }
    if (!formData?.city?.trim()) {
      errors.city = 'City is required';
    }
    if (!formData?.centerLatitude || isNaN(formData?.centerLatitude) || formData?.centerLatitude < -90 || formData?.centerLatitude > 90) {
      errors.centerLatitude = 'Valid latitude is required (-90 to 90)';
    }
    if (!formData?.centerLongitude || isNaN(formData?.centerLongitude) || formData?.centerLongitude < -180 || formData?.centerLongitude > 180) {
      errors.centerLongitude = 'Valid longitude is required (-180 to 180)';
    }
    if (!formData?.waterBodyType) {
      errors.waterBodyType = 'Water body type is required';
    }

    // Technical validation
    if (!formData?.methodology) {
      errors.methodology = 'Methodology is required';
    }
    if (formData?.methodology === 'custom' && !formData?.customMethodologyName?.trim()) {
      errors.customMethodologyName = 'Custom methodology name is required';
    }
    if (!formData?.baselineCarbon || isNaN(formData?.baselineCarbon) || formData?.baselineCarbon < 0) {
      errors.baselineCarbon = 'Valid baseline carbon stock is required';
    }
    if (!formData?.baselineDate) {
      errors.baselineDate = 'Baseline assessment date is required';
    }
    if (!formData?.monitoringFrequency) {
      errors.monitoringFrequency = 'Monitoring frequency is required';
    }
    if (!formData?.measurementMethods || formData?.measurementMethods?.length === 0) {
      errors.measurementMethods = 'At least one measurement method is required';
    }

    setValidationErrors(errors);
    return Object.keys(errors)?.length === 0;
  };

  const handleSaveDraft = async () => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      localStorage.setItem('project-registration-draft', JSON.stringify(formData));
      console.log('Draft saved successfully');
      
      // Show success message (you could add a toast notification here)
      setAutoSaveStatus('saved');
    } catch (error) {
      console.error('Error saving draft:', error);
      setAutoSaveStatus('error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitForReview = async () => {
    const isValid = validateForm();
    
    if (!isValid) {
      // Find first section with errors and navigate to it
      const errorFields = Object.keys(validationErrors);
      if (errorFields?.some(field => ['projectName', 'projectDescription', 'ecosystemType', 'projectType', 'startDate', 'endDate']?.includes(field))) {
        setCurrentSection('basic');
      } else if (errorFields?.some(field => ['country', 'region', 'city', 'centerLatitude', 'centerLongitude', 'waterBodyType']?.includes(field))) {
        setCurrentSection('location');
      } else if (errorFields?.some(field => ['methodology', 'baselineCarbon', 'baselineDate', 'monitoringFrequency', 'measurementMethods']?.includes(field))) {
        setCurrentSection('technical');
      } else {
        setCurrentSection('documentation');
      }
      return;
    }

    setIsLoading(true);
    try {
      // Simulate API submission
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Clear draft from localStorage
      localStorage.removeItem('project-registration-draft');
      
      console.log('Project submitted successfully:', formData);
      
      // Navigate to success page or project management
      navigate('/project-management', { 
        state: { 
          message: 'Project submitted successfully for review',
          projectName: formData?.projectName 
        }
      });
    } catch (error) {
      console.error('Error submitting project:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePreview = () => {
    setShowPreview(true);
  };

  const renderCurrentSection = () => {
    switch (currentSection) {
      case 'basic':
        return (
          <BasicInformationForm
            formData={formData}
            onUpdate={handleFormUpdate}
            errors={validationErrors}
          />
        );
      case 'location':
        return (
          <LocationDetailsForm
            formData={formData}
            onUpdate={handleFormUpdate}
            errors={validationErrors}
          />
        );
      case 'technical':
        return (
          <TechnicalSpecificationsForm
            formData={formData}
            onUpdate={handleFormUpdate}
            errors={validationErrors}
          />
        );
      case 'documentation':
        return (
          <DocumentationUploadForm
            formData={formData}
            onUpdate={handleFormUpdate}
            errors={validationErrors}
          />
        );
      default:
        return null;
    }
  };

  const getSectionTitle = () => {
    switch (currentSection) {
      case 'basic':
        return 'Basic Information';
      case 'location':
        return 'Location Details';
      case 'technical':
        return 'Technical Specifications';
      case 'documentation':
        return 'Documentation Upload';
      default:
        return 'Project Registration';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuToggle={() => setIsMenuOpen(!isMenuOpen)} isMenuOpen={isMenuOpen} />
      <div className="flex pt-16">
        {/* Progress Sidebar */}
        <FormProgressSidebar
          currentSection={currentSection}
          onSectionChange={setCurrentSection}
          formData={formData}
          validationErrors={validationErrors}
          isCollapsed={isSidebarCollapsed}
          onToggle={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />

        {/* Main Content */}
        <div className={`flex-1 transition-all duration-200 ${
          isSidebarCollapsed ? 'ml-16' : 'ml-80'
        }`}>
          <div className="max-w-4xl mx-auto p-6">
            {/* Page Header */}
            <div className="mb-8">
              <div className="flex items-center space-x-3 mb-4">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigate('/dashboard')}
                  iconName="ArrowLeft"
                  iconSize={20}
                />
                <div>
                  <h1 className="text-3xl font-bold text-foreground">Project Registration</h1>
                  <p className="text-muted-foreground">Register your blue carbon project for verification and tokenization</p>
                </div>
              </div>

              {/* Section Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                    <Icon name="FileText" size={20} color="white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-foreground">{getSectionTitle()}</h2>
                    <p className="text-sm text-muted-foreground">
                      Complete all sections to submit your project for review
                    </p>
                  </div>
                </div>

                {/* Desktop Section Navigation */}
                <div className="hidden lg:flex items-center space-x-2">
                  {['basic', 'location', 'technical', 'documentation']?.map((section, index) => (
                    <Button
                      key={section}
                      variant={currentSection === section ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCurrentSection(section)}
                      className="text-xs"
                    >
                      {index + 1}
                    </Button>
                  ))}
                </div>
              </div>
            </div>

            {/* Form Content */}
            <div className="bg-card border border-border rounded-lg">
              <div className="p-6">
                {renderCurrentSection()}
              </div>

              {/* Form Actions */}
              <FormActions
                formData={formData}
                validationErrors={validationErrors}
                onSave={handleSaveDraft}
                onSubmit={handleSubmitForReview}
                onPreview={handlePreview}
                isLoading={isLoading}
                autoSaveStatus={autoSaveStatus}
              />
            </div>
          </div>
        </div>
      </div>
      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h3 className="text-lg font-semibold text-foreground">Project Preview</h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowPreview(false)}
                iconName="X"
                iconSize={20}
              />
            </div>
            
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-medium text-foreground mb-3">Basic Information</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium text-muted-foreground">Project Name:</span>
                      <p className="text-foreground">{formData?.projectName || 'Not specified'}</p>
                    </div>
                    <div>
                      <span className="font-medium text-muted-foreground">Ecosystem Type:</span>
                      <p className="text-foreground capitalize">{formData?.ecosystemType || 'Not specified'}</p>
                    </div>
                    <div className="md:col-span-2">
                      <span className="font-medium text-muted-foreground">Description:</span>
                      <p className="text-foreground">{formData?.projectDescription || 'Not specified'}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-medium text-foreground mb-3">Location</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium text-muted-foreground">Country:</span>
                      <p className="text-foreground">{formData?.country || 'Not specified'}</p>
                    </div>
                    <div>
                      <span className="font-medium text-muted-foreground">Region:</span>
                      <p className="text-foreground">{formData?.region || 'Not specified'}</p>
                    </div>
                    <div>
                      <span className="font-medium text-muted-foreground">Coordinates:</span>
                      <p className="text-foreground">
                        {formData?.centerLatitude && formData?.centerLongitude 
                          ? `${formData?.centerLatitude}, ${formData?.centerLongitude}`
                          : 'Not specified'
                        }
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-medium text-foreground mb-3">Technical Details</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium text-muted-foreground">Methodology:</span>
                      <p className="text-foreground">{formData?.methodology || 'Not specified'}</p>
                    </div>
                    <div>
                      <span className="font-medium text-muted-foreground">Baseline Carbon:</span>
                      <p className="text-foreground">
                        {formData?.baselineCarbon ? `${formData?.baselineCarbon} tCO2e/ha` : 'Not specified'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectRegistration;