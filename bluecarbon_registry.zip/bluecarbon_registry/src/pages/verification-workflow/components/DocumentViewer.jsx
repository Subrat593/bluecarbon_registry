import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DocumentViewer = ({ project, onAnnotationAdd }) => {
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [annotations, setAnnotations] = useState([]);
  const [isAnnotating, setIsAnnotating] = useState(false);
  const [annotationType, setAnnotationType] = useState('comment');

  const documents = project ? [
    {
      id: 1,
      name: 'Project Design Document',
      type: 'pdf',
      size: '2.4 MB',
      uploadDate: '2025-08-25',
      status: 'reviewed',
      url: 'https://example.com/pdd.pdf'
    },
    {
      id: 2,
      name: 'Monitoring Plan',
      type: 'pdf',
      size: '1.8 MB',
      uploadDate: '2025-08-24',
      status: 'pending',
      url: 'https://example.com/monitoring.pdf'
    },
    {
      id: 3,
      name: 'Baseline Study',
      type: 'pdf',
      size: '3.2 MB',
      uploadDate: '2025-08-23',
      status: 'approved',
      url: 'https://example.com/baseline.pdf'
    },
    {
      id: 4,
      name: 'Stakeholder Consultation Report',
      type: 'pdf',
      size: '1.5 MB',
      uploadDate: '2025-08-22',
      status: 'requires_revision',
      url: 'https://example.com/stakeholder.pdf'
    },
    {
      id: 5,
      name: 'Environmental Impact Assessment',
      type: 'pdf',
      size: '4.1 MB',
      uploadDate: '2025-08-21',
      status: 'reviewed',
      url: 'https://example.com/eia.pdf'
    },
    {
      id: 6,
      name: 'Satellite Imagery Data',
      type: 'csv',
      size: '856 KB',
      uploadDate: '2025-08-20',
      status: 'pending',
      url: 'https://example.com/satellite.csv'
    }
  ] : [];

  const getFileIcon = (type) => {
    switch (type) {
      case 'pdf': return 'FileText';
      case 'csv': return 'Table';
      case 'xlsx': return 'Sheet';
      case 'docx': return 'FileText';
      default: return 'File';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'bg-success text-success-foreground';
      case 'reviewed': return 'bg-primary text-primary-foreground';
      case 'pending': return 'bg-warning text-warning-foreground';
      case 'requires_revision': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const handleDocumentSelect = (document) => {
    setSelectedDocument(document);
    // In a real app, this would load the document content
  };

  const handleAnnotationClick = (x, y) => {
    if (!isAnnotating) return;
    
    const newAnnotation = {
      id: Date.now(),
      x,
      y,
      type: annotationType,
      text: '',
      author: 'Current Verifier',
      timestamp: new Date()?.toISOString()
    };
    
    setAnnotations([...annotations, newAnnotation]);
    onAnnotationAdd?.(newAnnotation);
  };

  const annotationTypes = [
    { key: 'comment', label: 'Comment', icon: 'MessageCircle', color: 'text-primary' },
    { key: 'issue', label: 'Issue', icon: 'AlertTriangle', color: 'text-destructive' },
    { key: 'approval', label: 'Approved', icon: 'CheckCircle', color: 'text-success' },
    { key: 'question', label: 'Question', icon: 'HelpCircle', color: 'text-warning' }
  ];

  if (!project) {
    return (
      <div className="bg-card border border-border rounded-lg h-full flex items-center justify-center">
        <div className="text-center">
          <Icon name="FileText" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No Documents Available</h3>
          <p className="text-muted-foreground">Select a project to view its documents</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Document Viewer</h3>
          <div className="flex items-center space-x-2">
            <Button
              variant={isAnnotating ? 'default' : 'outline'}
              size="sm"
              onClick={() => setIsAnnotating(!isAnnotating)}
              iconName="Edit3"
              iconPosition="left"
              iconSize={16}
            >
              {isAnnotating ? 'Stop Annotating' : 'Annotate'}
            </Button>
          </div>
        </div>

        {/* Annotation Tools */}
        {isAnnotating && (
          <div className="flex items-center space-x-2 mb-4">
            <span className="text-sm text-muted-foreground">Annotation type:</span>
            {annotationTypes?.map(type => (
              <Button
                key={type?.key}
                variant={annotationType === type?.key ? 'default' : 'ghost'}
                size="xs"
                onClick={() => setAnnotationType(type?.key)}
                iconName={type?.icon}
                iconPosition="left"
                iconSize={14}
                className={type?.color}
              >
                {type?.label}
              </Button>
            ))}
          </div>
        )}
      </div>
      <div className="flex-1 flex">
        {/* Document List */}
        <div className="w-80 border-r border-border flex flex-col">
          <div className="p-3 border-b border-border">
            <h4 className="font-medium text-foreground">Project Documents</h4>
            <p className="text-sm text-muted-foreground">{documents?.length} files</p>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            <div className="p-2 space-y-2">
              {documents?.map(doc => (
                <div
                  key={doc?.id}
                  onClick={() => handleDocumentSelect(doc)}
                  className={`p-3 rounded-lg border cursor-pointer transition-smooth ${
                    selectedDocument?.id === doc?.id
                      ? 'border-primary bg-primary/5' :'border-border bg-card hover:bg-muted/50'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <Icon name={getFileIcon(doc?.type)} size={20} className="text-primary mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <h5 className="font-medium text-foreground text-sm line-clamp-2 mb-1">
                        {doc?.name}
                      </h5>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-muted-foreground">{doc?.size}</span>
                        <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getStatusColor(doc?.status)}`}>
                          {doc?.status?.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Uploaded {doc?.uploadDate}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Document Viewer */}
        <div className="flex-1 flex flex-col">
          {selectedDocument ? (
            <>
              <div className="p-4 border-b border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-foreground">{selectedDocument?.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      {selectedDocument?.type?.toUpperCase()} • {selectedDocument?.size}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Download"
                      iconPosition="left"
                      iconSize={16}
                    >
                      Download
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="ExternalLink"
                      iconPosition="left"
                      iconSize={16}
                    >
                      Open
                    </Button>
                  </div>
                </div>
              </div>

              {/* Document Content Area */}
              <div 
                className="flex-1 bg-muted/20 relative overflow-auto cursor-crosshair"
                onClick={(e) => {
                  const rect = e?.currentTarget?.getBoundingClientRect();
                  const x = e?.clientX - rect?.left;
                  const y = e?.clientY - rect?.top;
                  handleAnnotationClick(x, y);
                }}
              >
                {/* Mock Document Content */}
                <div className="p-8">
                  <div className="bg-white shadow-lg max-w-4xl mx-auto min-h-[800px] p-8">
                    <div className="space-y-6">
                      <div className="text-center border-b border-gray-200 pb-6">
                        <h1 className="text-2xl font-bold text-gray-900 mb-2">
                          {selectedDocument?.name}
                        </h1>
                        <p className="text-gray-600">Blue Carbon Project Documentation</p>
                      </div>
                      
                      <div className="space-y-4">
                        <h2 className="text-xl font-semibold text-gray-900">Executive Summary</h2>
                        <p className="text-gray-700 leading-relaxed">
                          This document outlines the comprehensive approach for the blue carbon project 
                          implementation, including methodology, monitoring protocols, and stakeholder 
                          engagement strategies. The project aims to restore and protect coastal ecosystems 
                          while generating verified carbon credits through sustainable management practices.
                        </p>
                        
                        <h2 className="text-xl font-semibold text-gray-900">Project Objectives</h2>
                        <ul className="list-disc list-inside space-y-2 text-gray-700">
                          <li>Restore degraded mangrove ecosystems across 500 hectares</li>
                          <li>Implement sustainable aquaculture practices</li>
                          <li>Engage local communities in conservation efforts</li>
                          <li>Generate 10,000 carbon credits annually</li>
                          <li>Monitor biodiversity improvements over 10-year period</li>
                        </ul>
                        
                        <h2 className="text-xl font-semibold text-gray-900">Methodology</h2>
                        <p className="text-gray-700 leading-relaxed">
                          The project follows the VM0033 methodology for tidal wetland and seagrass 
                          restoration. Baseline measurements were conducted using satellite imagery 
                          analysis combined with field surveys to establish carbon stock estimates.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Annotations */}
                {annotations?.map(annotation => (
                  <div
                    key={annotation?.id}
                    className="absolute w-6 h-6 rounded-full border-2 border-white shadow-lg cursor-pointer"
                    style={{ 
                      left: annotation?.x - 12, 
                      top: annotation?.y - 12,
                      backgroundColor: annotationType === 'comment' ? '#3b82f6' :
                                     annotationType === 'issue' ? '#ef4444' :
                                     annotationType === 'approval' ? '#10b981' : '#f59e0b'
                    }}
                    title={`${annotation?.type} by ${annotation?.author}`}
                  >
                    <Icon 
                      name={annotationTypes?.find(t => t?.key === annotation?.type)?.icon || 'MessageCircle'} 
                      size={12} 
                      color="white"
                      className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
                    />
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <Icon name="FileText" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h4 className="text-lg font-medium text-foreground mb-2">Select a Document</h4>
                <p className="text-muted-foreground">Choose a document from the list to view its contents</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DocumentViewer;