import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const ProjectDetails = ({ project }) => {
  const [activeTab, setActiveTab] = useState('overview');

  if (!project) {
    return (
      <div className="bg-card border border-border rounded-lg h-full flex items-center justify-center">
        <div className="text-center">
          <Icon name="FolderOpen" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No Project Selected</h3>
          <p className="text-muted-foreground">Select a project from the queue to view details</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { key: 'overview', label: 'Overview', icon: 'Info' },
    { key: 'methodology', label: 'Methodology', icon: 'BookOpen' },
    { key: 'monitoring', label: 'Monitoring', icon: 'BarChart3' },
    { key: 'stakeholders', label: 'Stakeholders', icon: 'Users' },
    { key: 'timeline', label: 'Timeline', icon: 'Calendar' }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-warning text-warning-foreground';
      case 'under_review': return 'bg-primary text-primary-foreground';
      case 'requires_revision': return 'bg-destructive text-destructive-foreground';
      case 'approved': return 'bg-success text-success-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Project Header */}
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h2 className="text-xl font-semibold text-foreground mb-2">{project?.name}</h2>
          <p className="text-muted-foreground mb-4">{project?.description}</p>
          <div className="flex items-center space-x-4">
            <span className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(project?.status)}`}>
              {project?.status?.replace('_', ' ')}
            </span>
            <div className="flex items-center space-x-1 text-sm text-muted-foreground">
              <Icon name="MapPin" size={16} />
              <span>{project?.location}</span>
            </div>
            <div className="flex items-center space-x-1 text-sm text-muted-foreground">
              <Icon name="Calendar" size={16} />
              <span>Submitted {project?.submittedDate}</span>
            </div>
          </div>
        </div>
        <Image
          src={project?.image}
          alt={project?.name}
          className="w-32 h-24 object-cover rounded-lg"
        />
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-muted/50 p-4 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="TreePine" size={20} className="text-success" />
            <span className="font-medium text-foreground">Ecosystem</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{project?.ecosystem}</p>
          <p className="text-sm text-muted-foreground">Primary ecosystem type</p>
        </div>
        
        <div className="bg-muted/50 p-4 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Maximize" size={20} className="text-primary" />
            <span className="font-medium text-foreground">Area</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{project?.area}</p>
          <p className="text-sm text-muted-foreground">Total project area</p>
        </div>
        
        <div className="bg-muted/50 p-4 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Zap" size={20} className="text-accent" />
            <span className="font-medium text-foreground">Credits</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{project?.estimatedCredits}</p>
          <p className="text-sm text-muted-foreground">Estimated annual credits</p>
        </div>
      </div>

      {/* Project Owner */}
      <div className="bg-muted/50 p-4 rounded-lg">
        <h3 className="font-medium text-foreground mb-3">Project Owner</h3>
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
            <Icon name="User" size={20} color="white" />
          </div>
          <div>
            <p className="font-medium text-foreground">{project?.owner}</p>
            <p className="text-sm text-muted-foreground">{project?.ownerEmail}</p>
          </div>
        </div>
      </div>

      {/* Coordinates */}
      <div className="bg-muted/50 p-4 rounded-lg">
        <h3 className="font-medium text-foreground mb-3">Geographic Coordinates</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Latitude</p>
            <p className="font-mono text-foreground">{project?.coordinates?.lat}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Longitude</p>
            <p className="font-mono text-foreground">{project?.coordinates?.lng}</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderMethodology = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium text-foreground mb-3">Applied Methodology</h3>
        <div className="bg-muted/50 p-4 rounded-lg">
          <p className="font-medium text-foreground">{project?.methodology?.name}</p>
          <p className="text-sm text-muted-foreground mt-1">{project?.methodology?.version}</p>
          <p className="text-sm text-foreground mt-2">{project?.methodology?.description}</p>
        </div>
      </div>

      <div>
        <h3 className="font-medium text-foreground mb-3">Baseline Scenario</h3>
        <div className="bg-muted/50 p-4 rounded-lg">
          <p className="text-sm text-foreground">{project?.baseline}</p>
        </div>
      </div>

      <div>
        <h3 className="font-medium text-foreground mb-3">Additionality</h3>
        <div className="bg-muted/50 p-4 rounded-lg">
          <p className="text-sm text-foreground">{project?.additionality}</p>
        </div>
      </div>
    </div>
  );

  const renderMonitoring = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium text-foreground mb-3">Monitoring Plan</h3>
        <div className="space-y-3">
          {project?.monitoringPlan?.map((item, index) => (
            <div key={index} className="bg-muted/50 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Activity" size={16} className="text-primary" />
                <span className="font-medium text-foreground">{item?.parameter}</span>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{item?.method}</p>
              <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                <span>Frequency: {item?.frequency}</span>
                <span>Responsible: {item?.responsible}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderStakeholders = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium text-foreground mb-3">Stakeholder Engagement</h3>
        <div className="space-y-3">
          {project?.stakeholders?.map((stakeholder, index) => (
            <div key={index} className="bg-muted/50 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Users" size={16} className="text-secondary" />
                <span className="font-medium text-foreground">{stakeholder?.group}</span>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{stakeholder?.role}</p>
              <p className="text-sm text-foreground">{stakeholder?.engagement}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderTimeline = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium text-foreground mb-3">Project Timeline</h3>
        <div className="space-y-4">
          {project?.timeline?.map((event, index) => (
            <div key={index} className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                <div className="w-2 h-2 bg-white rounded-full" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-foreground">{event?.milestone}</span>
                  <span className="text-sm text-muted-foreground">{event?.date}</span>
                </div>
                <p className="text-sm text-muted-foreground">{event?.description}</p>
                <div className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full mt-2 ${
                  event?.status === 'completed' ? 'bg-success text-success-foreground' :
                  event?.status === 'in_progress' ? 'bg-warning text-warning-foreground' :
                  'bg-muted text-muted-foreground'
                }`}>
                  {event?.status?.replace('_', ' ')}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview': return renderOverview();
      case 'methodology': return renderMethodology();
      case 'monitoring': return renderMonitoring();
      case 'stakeholders': return renderStakeholders();
      case 'timeline': return renderTimeline();
      default: return renderOverview();
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col">
      {/* Tab Navigation */}
      <div className="border-b border-border">
        <div className="flex space-x-1 p-2">
          {tabs?.map(tab => (
            <Button
              key={tab?.key}
              variant={activeTab === tab?.key ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab(tab?.key)}
              iconName={tab?.icon}
              iconPosition="left"
              iconSize={16}
              className="text-sm"
            >
              {tab?.label}
            </Button>
          ))}
        </div>
      </div>
      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {renderTabContent()}
      </div>
    </div>
  );
};

export default ProjectDetails;