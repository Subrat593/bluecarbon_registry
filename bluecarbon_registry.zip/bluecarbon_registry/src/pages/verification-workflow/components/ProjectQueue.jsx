import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';


const ProjectQueue = ({ projects, selectedProject, onProjectSelect }) => {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProjects = projects?.filter(project => {
    const matchesFilter = filter === 'all' || project?.status === filter;
    const matchesSearch = project?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         project?.owner?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-warning text-warning-foreground';
      case 'under_review': return 'bg-primary text-primary-foreground';
      case 'requires_revision': return 'bg-destructive text-destructive-foreground';
      case 'approved': return 'bg-success text-success-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case 'high': return { name: 'AlertTriangle', color: 'text-destructive' };
      case 'medium': return { name: 'Clock', color: 'text-warning' };
      case 'low': return { name: 'Minus', color: 'text-muted-foreground' };
      default: return { name: 'Minus', color: 'text-muted-foreground' };
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col">
      <div className="p-4 border-b border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Project Queue</h3>
        
        {/* Search */}
        <div className="relative mb-4">
          <Icon name="Search" size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search projects..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {/* Filter Tabs */}
        <div className="flex space-x-1">
          {[
            { key: 'all', label: 'All', count: projects?.length },
            { key: 'pending', label: 'Pending', count: projects?.filter(p => p?.status === 'pending')?.length },
            { key: 'under_review', label: 'Review', count: projects?.filter(p => p?.status === 'under_review')?.length },
            { key: 'requires_revision', label: 'Revision', count: projects?.filter(p => p?.status === 'requires_revision')?.length }
          ]?.map(tab => (
            <button
              key={tab?.key}
              onClick={() => setFilter(tab?.key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-smooth ${
                filter === tab?.key
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {tab?.label} ({tab?.count})
            </button>
          ))}
        </div>
      </div>
      {/* Project List */}
      <div className="flex-1 overflow-y-auto p-2">
        <div className="space-y-2">
          {filteredProjects?.map(project => {
            const priorityIcon = getPriorityIcon(project?.priority);
            const isSelected = selectedProject?.id === project?.id;
            
            return (
              <div
                key={project?.id}
                onClick={() => onProjectSelect(project)}
                className={`p-3 rounded-lg border cursor-pointer transition-smooth ${
                  isSelected
                    ? 'border-primary bg-primary/5' :'border-border bg-card hover:bg-muted/50'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium text-foreground text-sm line-clamp-2">{project?.name}</h4>
                  <Icon name={priorityIcon?.name} size={14} className={priorityIcon?.color} />
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">{project?.owner}</span>
                  <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getStatusColor(project?.status)}`}>
                    {project?.status?.replace('_', ' ')}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{project?.ecosystem}</span>
                  <span>{project?.submittedDate}</span>
                </div>
                <div className="mt-2 flex items-center space-x-3 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Icon name="MapPin" size={12} />
                    <span>{project?.location}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Calendar" size={12} />
                    <span>{project?.daysInQueue} days</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProjectQueue;