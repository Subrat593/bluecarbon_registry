import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import { Checkbox } from '../../../components/ui/Checkbox';

const VerificationChecklist = ({ project, onChecklistUpdate }) => {
  const [checklist, setChecklist] = useState({
    methodology: {
      title: 'Methodology Validation',
      items: [
        { id: 'methodology_approved', label: 'Approved methodology used', checked: false, required: true },
        { id: 'baseline_established', label: 'Baseline properly established', checked: false, required: true },
        { id: 'additionality_proven', label: 'Additionality demonstrated', checked: false, required: true },
        { id: 'leakage_assessed', label: 'Leakage risks assessed', checked: false, required: true }
      ]
    },
    documentation: {
      title: 'Documentation Review',
      items: [
        { id: 'project_design_complete', label: 'Project design document complete', checked: false, required: true },
        { id: 'monitoring_plan_adequate', label: 'Monitoring plan adequate', checked: false, required: true },
        { id: 'stakeholder_consultation', label: 'Stakeholder consultation documented', checked: false, required: true },
        { id: 'environmental_impact', label: 'Environmental impact assessed', checked: false, required: true }
      ]
    },
    data_quality: {
      title: 'Data Quality Assessment',
      items: [
        { id: 'data_accuracy', label: 'Data accuracy verified', checked: false, required: true },
        { id: 'measurement_methods', label: 'Measurement methods appropriate', checked: false, required: true },
        { id: 'uncertainty_analysis', label: 'Uncertainty analysis conducted', checked: false, required: true },
        { id: 'quality_assurance', label: 'Quality assurance procedures followed', checked: false, required: true }
      ]
    },
    compliance: {
      title: 'Regulatory Compliance',
      items: [
        { id: 'legal_requirements', label: 'Legal requirements met', checked: false, required: true },
        { id: 'permits_obtained', label: 'Necessary permits obtained', checked: false, required: true },
        { id: 'safeguards_implemented', label: 'Social/environmental safeguards implemented', checked: false, required: true },
        { id: 'grievance_mechanism', label: 'Grievance mechanism established', checked: false, required: false }
      ]
    }
  });

  const handleItemCheck = (sectionKey, itemId, checked) => {
    setChecklist(prev => ({
      ...prev,
      [sectionKey]: {
        ...prev?.[sectionKey],
        items: prev?.[sectionKey]?.items?.map(item =>
          item?.id === itemId ? { ...item, checked } : item
        )
      }
    }));
    
    onChecklistUpdate?.(checklist);
  };

  const getSectionProgress = (section) => {
    const totalItems = section?.items?.length;
    const checkedItems = section?.items?.filter(item => item?.checked)?.length;
    return { completed: checkedItems, total: totalItems, percentage: (checkedItems / totalItems) * 100 };
  };

  const getOverallProgress = () => {
    const allItems = Object.values(checklist)?.flatMap(section => section?.items);
    const totalItems = allItems?.length;
    const checkedItems = allItems?.filter(item => item?.checked)?.length;
    return { completed: checkedItems, total: totalItems, percentage: (checkedItems / totalItems) * 100 };
  };

  const overallProgress = getOverallProgress();

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Verification Checklist</h3>
          <div className="flex items-center space-x-2">
            <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-300"
                style={{ width: `${overallProgress?.percentage}%` }}
              />
            </div>
            <span className="text-sm text-muted-foreground">
              {overallProgress?.completed}/{overallProgress?.total}
            </span>
          </div>
        </div>
        
        {project && (
          <div className="text-sm text-muted-foreground">
            Verifying: <span className="font-medium text-foreground">{project?.name}</span>
          </div>
        )}
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-6">
          {Object.entries(checklist)?.map(([sectionKey, section]) => {
            const progress = getSectionProgress(section);
            
            return (
              <div key={sectionKey} className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-foreground">{section?.title}</h4>
                  <div className="flex items-center space-x-2">
                    <div className="w-12 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-success transition-all duration-300"
                        style={{ width: `${progress?.percentage}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {progress?.completed}/{progress?.total}
                    </span>
                  </div>
                </div>
                <div className="space-y-2">
                  {section?.items?.map(item => (
                    <div key={item?.id} className="flex items-start space-x-3">
                      <Checkbox
                        checked={item?.checked}
                        onChange={(e) => handleItemCheck(sectionKey, item?.id, e?.target?.checked)}
                        className="mt-0.5"
                      />
                      <div className="flex-1 min-w-0">
                        <label className="text-sm text-foreground cursor-pointer">
                          {item?.label}
                          {item?.required && <span className="text-destructive ml-1">*</span>}
                        </label>
                      </div>
                      {item?.checked && (
                        <Icon name="CheckCircle" size={16} className="text-success mt-0.5" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* Summary */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Overall Progress</span>
          <span className={`font-medium ${
            overallProgress?.percentage === 100 ? 'text-success' : 'text-foreground'
          }`}>
            {Math.round(overallProgress?.percentage)}% Complete
          </span>
        </div>
        
        {overallProgress?.percentage === 100 && (
          <div className="mt-2 flex items-center space-x-2 text-success">
            <Icon name="CheckCircle" size={16} />
            <span className="text-sm font-medium">All requirements verified</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default VerificationChecklist;