import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const VerificationForm = ({ project, onSubmit, onSaveProgress }) => {
  const [formData, setFormData] = useState({
    overallAssessment: '',
    recommendation: '',
    comments: '',
    requiredActions: '',
    verificationDate: new Date()?.toISOString()?.split('T')?.[0],
    verifierName: 'Dr. Sarah Johnson',
    verifierCredentials: 'Certified Carbon Verifier (CCV-2024)',
    confidenceLevel: '',
    riskAssessment: '',
    followUpRequired: false,
    followUpDate: '',
    attachments: []
  });

  const [validationErrors, setValidationErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const recommendationOptions = [
    { value: '', label: 'Select recommendation...' },
    { value: 'approve', label: 'Approve for Credit Issuance' },
    { value: 'conditional_approval', label: 'Conditional Approval' },
    { value: 'request_revisions', label: 'Request Revisions' },
    { value: 'reject', label: 'Reject Application' }
  ];

  const confidenceLevelOptions = [
    { value: '', label: 'Select confidence level...' },
    { value: 'high', label: 'High Confidence (>95%)' },
    { value: 'medium', label: 'Medium Confidence (85-95%)' },
    { value: 'low', label: 'Low Confidence (<85%)' }
  ];

  const riskAssessmentOptions = [
    { value: '', label: 'Select risk level...' },
    { value: 'low', label: 'Low Risk' },
    { value: 'medium', label: 'Medium Risk' },
    { value: 'high', label: 'High Risk' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear validation error when user starts typing
    if (validationErrors?.[field]) {
      setValidationErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const errors = {};
    
    if (!formData?.overallAssessment?.trim()) {
      errors.overallAssessment = 'Overall assessment is required';
    }
    
    if (!formData?.recommendation) {
      errors.recommendation = 'Recommendation is required';
    }
    
    if (!formData?.comments?.trim()) {
      errors.comments = 'Comments are required';
    }
    
    if (!formData?.confidenceLevel) {
      errors.confidenceLevel = 'Confidence level is required';
    }
    
    if (!formData?.riskAssessment) {
      errors.riskAssessment = 'Risk assessment is required';
    }
    
    if (formData?.recommendation === 'request_revisions' && !formData?.requiredActions?.trim()) {
      errors.requiredActions = 'Required actions must be specified for revision requests';
    }
    
    if (formData?.followUpRequired && !formData?.followUpDate) {
      errors.followUpDate = 'Follow-up date is required when follow-up is needed';
    }
    
    setValidationErrors(errors);
    return Object.keys(errors)?.length === 0;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await onSubmit?.(formData);
    } catch (error) {
      console.error('Submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveProgress = () => {
    onSaveProgress?.(formData);
  };

  const getRecommendationColor = (recommendation) => {
    switch (recommendation) {
      case 'approve': return 'text-success';
      case 'conditional_approval': return 'text-warning';
      case 'request_revisions': return 'text-destructive';
      case 'reject': return 'text-destructive';
      default: return 'text-foreground';
    }
  };

  if (!project) {
    return (
      <div className="bg-card border border-border rounded-lg h-full flex items-center justify-center">
        <div className="text-center">
          <Icon name="ClipboardList" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No Project Selected</h3>
          <p className="text-muted-foreground">Select a project to begin verification</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col">
      <div className="p-4 border-b border-border">
        <h3 className="text-lg font-semibold text-foreground mb-2">Verification Form</h3>
        <p className="text-sm text-muted-foreground">
          Complete verification assessment for: <span className="font-medium text-foreground">{project?.name}</span>
        </p>
      </div>
      <form onSubmit={handleSubmit} className="flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {/* Verifier Information */}
          <div className="space-y-4">
            <h4 className="font-medium text-foreground">Verifier Information</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Verifier Name"
                type="text"
                value={formData?.verifierName}
                onChange={(e) => handleInputChange('verifierName', e?.target?.value)}
                disabled
              />
              <Input
                label="Verification Date"
                type="date"
                value={formData?.verificationDate}
                onChange={(e) => handleInputChange('verificationDate', e?.target?.value)}
                required
              />
            </div>
            <Input
              label="Verifier Credentials"
              type="text"
              value={formData?.verifierCredentials}
              onChange={(e) => handleInputChange('verifierCredentials', e?.target?.value)}
              disabled
            />
          </div>

          {/* Assessment */}
          <div className="space-y-4">
            <h4 className="font-medium text-foreground">Verification Assessment</h4>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Overall Assessment <span className="text-destructive">*</span>
                </label>
                <textarea
                  value={formData?.overallAssessment}
                  onChange={(e) => handleInputChange('overallAssessment', e?.target?.value)}
                  placeholder="Provide a comprehensive assessment of the project's compliance with methodology requirements..."
                  rows={4}
                  className={`w-full px-3 py-2 border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none ${
                    validationErrors?.overallAssessment ? 'border-destructive' : 'border-border'
                  }`}
                />
                {validationErrors?.overallAssessment && (
                  <p className="text-sm text-destructive mt-1">{validationErrors?.overallAssessment}</p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select
                  label="Confidence Level"
                  options={confidenceLevelOptions}
                  value={formData?.confidenceLevel}
                  onChange={(value) => handleInputChange('confidenceLevel', value)}
                  error={validationErrors?.confidenceLevel}
                  required
                />
                
                <Select
                  label="Risk Assessment"
                  options={riskAssessmentOptions}
                  value={formData?.riskAssessment}
                  onChange={(value) => handleInputChange('riskAssessment', value)}
                  error={validationErrors?.riskAssessment}
                  required
                />
              </div>
            </div>
          </div>

          {/* Recommendation */}
          <div className="space-y-4">
            <h4 className="font-medium text-foreground">Verification Decision</h4>
            
            <Select
              label="Recommendation"
              options={recommendationOptions}
              value={formData?.recommendation}
              onChange={(value) => handleInputChange('recommendation', value)}
              error={validationErrors?.recommendation}
              required
              className="mb-4"
            />

            {formData?.recommendation && (
              <div className={`p-4 rounded-lg border ${
                formData?.recommendation === 'approve' ? 'border-success bg-success/5' :
                formData?.recommendation === 'conditional_approval'? 'border-warning bg-warning/5' : 'border-destructive bg-destructive/5'
              }`}>
                <div className="flex items-center space-x-2 mb-2">
                  <Icon 
                    name={
                      formData?.recommendation === 'approve' ? 'CheckCircle' :
                      formData?.recommendation === 'conditional_approval'? 'AlertCircle' : 'XCircle'
                    } 
                    size={20} 
                    className={getRecommendationColor(formData?.recommendation)}
                  />
                  <span className={`font-medium ${getRecommendationColor(formData?.recommendation)}`}>
                    {recommendationOptions?.find(opt => opt?.value === formData?.recommendation)?.label}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {formData?.recommendation === 'approve' && 'Project meets all requirements and is ready for credit issuance.'}
                  {formData?.recommendation === 'conditional_approval' && 'Project meets most requirements but needs minor adjustments.'}
                  {formData?.recommendation === 'request_revisions' && 'Project requires significant revisions before approval.'}
                  {formData?.recommendation === 'reject' && 'Project does not meet fundamental requirements.'}
                </p>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Detailed Comments <span className="text-destructive">*</span>
              </label>
              <textarea
                value={formData?.comments}
                onChange={(e) => handleInputChange('comments', e?.target?.value)}
                placeholder="Provide detailed comments explaining your recommendation..."
                rows={4}
                className={`w-full px-3 py-2 border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none ${
                  validationErrors?.comments ? 'border-destructive' : 'border-border'
                }`}
              />
              {validationErrors?.comments && (
                <p className="text-sm text-destructive mt-1">{validationErrors?.comments}</p>
              )}
            </div>

            {(formData?.recommendation === 'request_revisions' || formData?.recommendation === 'conditional_approval') && (
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Required Actions {formData?.recommendation === 'request_revisions' && <span className="text-destructive">*</span>}
                </label>
                <textarea
                  value={formData?.requiredActions}
                  onChange={(e) => handleInputChange('requiredActions', e?.target?.value)}
                  placeholder="List specific actions required before approval..."
                  rows={3}
                  className={`w-full px-3 py-2 border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none ${
                    validationErrors?.requiredActions ? 'border-destructive' : 'border-border'
                  }`}
                />
                {validationErrors?.requiredActions && (
                  <p className="text-sm text-destructive mt-1">{validationErrors?.requiredActions}</p>
                )}
              </div>
            )}
          </div>

          {/* Follow-up */}
          <div className="space-y-4">
            <h4 className="font-medium text-foreground">Follow-up Requirements</h4>
            
            <Checkbox
              label="Follow-up verification required"
              checked={formData?.followUpRequired}
              onChange={(e) => handleInputChange('followUpRequired', e?.target?.checked)}
            />

            {formData?.followUpRequired && (
              <Input
                label="Follow-up Date"
                type="date"
                value={formData?.followUpDate}
                onChange={(e) => handleInputChange('followUpDate', e?.target?.value)}
                error={validationErrors?.followUpDate}
                required
                className="max-w-xs"
              />
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-border">
          <div className="flex items-center justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={handleSaveProgress}
              iconName="Save"
              iconPosition="left"
              iconSize={16}
            >
              Save Progress
            </Button>
            
            <div className="flex items-center space-x-3">
              <Button
                type="button"
                variant="ghost"
                onClick={() => window.history?.back()}
              >
                Cancel
              </Button>
              
              <Button
                type="submit"
                variant="default"
                loading={isSubmitting}
                iconName="Send"
                iconPosition="left"
                iconSize={16}
                disabled={!formData?.recommendation}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Verification'}
              </Button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default VerificationForm;