import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import ProjectQueue from './components/ProjectQueue';
import VerificationChecklist from './components/VerificationChecklist';
import ProjectDetails from './components/ProjectDetails';
import DocumentViewer from './components/DocumentViewer';
import VerificationForm from './components/VerificationForm';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const VerificationWorkflow = () => {
  const [selectedProject, setSelectedProject] = useState(null);
  const [activeView, setActiveView] = useState('details');
  const [isMobile, setIsMobile] = useState(false);

  // Mock projects data
  const projects = [
    {
      id: 1,
      name: 'Mangrove Restoration Initiative - Sundarbans',
      description: `Comprehensive mangrove restoration project covering 500 hectares in the Sundarbans region.\nFocuses on community-based conservation and sustainable aquaculture practices.\nExpected to sequester 15,000 tCO2e annually through restored mangrove ecosystems.`,
      owner: 'Bangladesh Forest Department',
      ownerEmail: 'projects@bfd.gov.bd',
      ecosystem: 'Mangroves',
      location: 'Sundarbans, Bangladesh',
      area: '500 hectares',
      estimatedCredits: '15,000 tCO2e/year',
      status: 'under_review',
      priority: 'high',
      submittedDate: '2025-08-20',
      daysInQueue: 10,
      coordinates: { lat: 22.4054, lng: 89.1943 },
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=300&fit=crop',
      methodology: {
        name: 'VM0033 - Methodology for Tidal Wetland and Seagrass Restoration',
        version: 'v2.0',
        description: 'Approved methodology for blue carbon ecosystem restoration and conservation'
      },
      baseline: `The baseline scenario represents the continued degradation of mangrove ecosystems due to shrimp farming expansion and coastal development.\nWithout intervention, an estimated 50 hectares of mangroves would be lost annually.\nBaseline carbon emissions are calculated at 2,500 tCO2e per year from ecosystem degradation.`,
      additionality: `The project demonstrates additionality through barrier analysis showing financial, technological, and institutional barriers to restoration.\nWithout carbon finance, restoration activities would not be economically viable.\nGovernment policies alone are insufficient to prevent continued degradation.`,
      monitoringPlan: [
        {
          parameter: 'Mangrove Cover Area',
          method: 'Satellite imagery analysis with ground truthing',
          frequency: 'Quarterly',
          responsible: 'Remote Sensing Team'
        },
        {
          parameter: 'Carbon Stock Measurements',
          method: 'Allometric equations and soil sampling',
          frequency: 'Annually',
          responsible: 'Field Research Team'
        },
        {
          parameter: 'Biodiversity Monitoring',
          method: 'Species surveys and camera traps',
          frequency: 'Bi-annually',
          responsible: 'Ecology Team'
        },
        {
          parameter: 'Community Engagement',
          method: 'Stakeholder interviews and surveys',
          frequency: 'Quarterly',
          responsible: 'Social Impact Team'
        }
      ],
      stakeholders: [
        {
          group: 'Local Fishing Communities',
          role: 'Primary Beneficiaries',
          engagement: 'Regular consultation meetings and capacity building programs'
        },
        {
          group: 'Government Agencies',
          role: 'Regulatory Oversight',
          engagement: 'Formal agreements and periodic reporting'
        },
        {
          group: 'NGO Partners',
          role: 'Implementation Support',
          engagement: 'Technical assistance and community mobilization'
        },
        {
          group: 'Research Institutions',
          role: 'Scientific Monitoring',
          engagement: 'Data collection and analysis partnerships'
        }
      ],
      timeline: [
        {
          milestone: 'Project Initiation',
          date: '2025-01-15',
          description: 'Project design and stakeholder engagement commenced',
          status: 'completed'
        },
        {
          milestone: 'Baseline Study Completion',
          date: '2025-03-30',
          description: 'Comprehensive baseline assessment of ecosystem conditions',
          status: 'completed'
        },
        {
          milestone: 'Community Consultation',
          date: '2025-05-15',
          description: 'Stakeholder engagement and consent processes',
          status: 'completed'
        },
        {
          milestone: 'Restoration Activities Begin',
          date: '2025-07-01',
          description: 'Mangrove planting and habitat restoration initiation',
          status: 'in_progress'
        },
        {
          milestone: 'First Monitoring Report',
          date: '2025-10-01',
          description: 'Initial progress assessment and data collection',
          status: 'pending'
        },
        {
          milestone: 'Verification Submission',
          date: '2025-12-15',
          description: 'Submit project for third-party verification',
          status: 'pending'
        }
      ]
    },
    {
      id: 2,
      name: 'Seagrass Conservation Project - Great Barrier Reef',
      description: `Large-scale seagrass restoration and conservation project in the Great Barrier Reef Marine Park.\nTargets 1,200 hectares of degraded seagrass meadows for restoration.\nIntegrates traditional Indigenous knowledge with modern conservation techniques.`,
      owner: 'Marine Conservation Australia',
      ownerEmail: 'projects@marineconservation.org.au',
      ecosystem: 'Seagrass',
      location: 'Queensland, Australia',
      area: '1,200 hectares',
      estimatedCredits: '8,500 tCO2e/year',
      status: 'pending',
      priority: 'medium',
      submittedDate: '2025-08-25',
      daysInQueue: 5,
      coordinates: { lat: -16.2839, lng: 145.7781 },
      image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=300&fit=crop',
      methodology: {
        name: 'VM0033 - Methodology for Tidal Wetland and Seagrass Restoration',
        version: 'v2.0',
        description: 'Approved methodology for blue carbon ecosystem restoration and conservation'
      },
      baseline: `Baseline scenario involves continued seagrass decline due to coastal development, water quality degradation, and climate impacts.\nHistorical data shows 3% annual loss rate of seagrass coverage.\nBaseline emissions estimated at 1,800 tCO2e annually from ecosystem degradation.`,
      additionality: `Project demonstrates additionality through investment analysis and barrier assessment.\nRestoration costs exceed available government funding without carbon revenue.\nTechnical barriers require specialized expertise not available through existing programs.`,
      monitoringPlan: [
        {
          parameter: 'Seagrass Coverage',
          method: 'Underwater surveys and drone mapping',
          frequency: 'Quarterly',
          responsible: 'Marine Biology Team'
        },
        {
          parameter: 'Water Quality Parameters',
          method: 'In-situ sensors and laboratory analysis',
          frequency: 'Monthly',
          responsible: 'Water Quality Team'
        },
        {
          parameter: 'Fish Population Surveys',
          method: 'Underwater visual census',
          frequency: 'Bi-annually',
          responsible: 'Fisheries Team'
        }
      ],
      stakeholders: [
        {
          group: 'Traditional Owners',
          role: 'Cultural Guardians',
          engagement: 'Co-management agreements and cultural protocols'
        },
        {
          group: 'Tourism Industry',
          role: 'Economic Stakeholders',
          engagement: 'Industry consultation and benefit sharing'
        },
        {
          group: 'Research Partners',
          role: 'Scientific Support',
          engagement: 'Collaborative research agreements'
        }
      ],
      timeline: [
        {
          milestone: 'Project Planning',
          date: '2025-02-01',
          description: 'Initial project scoping and design phase',
          status: 'completed'
        },
        {
          milestone: 'Stakeholder Engagement',
          date: '2025-04-15',
          description: 'Community consultation and partnership development',
          status: 'completed'
        },
        {
          milestone: 'Baseline Assessment',
          date: '2025-06-30',
          description: 'Comprehensive ecosystem baseline study',
          status: 'in_progress'
        },
        {
          milestone: 'Restoration Implementation',
          date: '2025-09-01',
          description: 'Begin seagrass restoration activities',
          status: 'pending'
        }
      ]
    },
    {
      id: 3,
      name: 'Coastal Wetland Protection - California',
      description: `Integrated coastal wetland protection and restoration project along the California coast.\nCombines salt marsh restoration with sustainable coastal management practices.\nIncludes innovative blue carbon measurement and monitoring technologies.`,
      owner: 'California Coastal Conservancy',
      ownerEmail: 'bluecarbon@coastal.ca.gov',
      ecosystem: 'Salt Marsh',
      location: 'San Francisco Bay, CA',
      area: '800 hectares',
      estimatedCredits: '12,000 tCO2e/year',
      status: 'requires_revision',
      priority: 'high',
      submittedDate: '2025-08-15',
      daysInQueue: 15,
      coordinates: { lat: 37.7749, lng: -122.4194 },
      image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop',
      methodology: {
        name: 'VM0033 - Methodology for Tidal Wetland and Seagrass Restoration',
        version: 'v2.0',
        description: 'Approved methodology for blue carbon ecosystem restoration and conservation'
      },
      baseline: `Baseline represents continued urban development pressure and sea level rise impacts on coastal wetlands.\nHistorical loss rate of 2% annually due to development and climate change.\nBaseline carbon emissions of 3,200 tCO2e per year from wetland degradation.`,
      additionality: `Additionality demonstrated through regulatory analysis and financial barriers.\nExisting regulations insufficient to prevent continued wetland loss.\nProject requires carbon finance to overcome high restoration costs in urban areas.`,
      monitoringPlan: [
        {
          parameter: 'Wetland Extent',
          method: 'LiDAR and multispectral imagery',
          frequency: 'Quarterly',
          responsible: 'GIS Analysis Team'
        },
        {
          parameter: 'Soil Carbon Content',
          method: 'Core sampling and laboratory analysis',
          frequency: 'Annually',
          responsible: 'Soil Science Team'
        },
        {
          parameter: 'Vegetation Health',
          method: 'Field surveys and spectral analysis',
          frequency: 'Monthly',
          responsible: 'Vegetation Team'
        }
      ],
      stakeholders: [
        {
          group: 'Urban Communities',
          role: 'Local Residents',
          engagement: 'Public meetings and educational programs'
        },
        {
          group: 'Port Authorities',
          role: 'Infrastructure Partners',
          engagement: 'Coordination agreements and impact mitigation'
        },
        {
          group: 'Environmental Groups',
          role: 'Advocacy Partners',
          engagement: 'Collaborative conservation initiatives'
        }
      ],
      timeline: [
        {
          milestone: 'Environmental Assessment',
          date: '2025-01-01',
          description: 'Comprehensive environmental impact assessment',
          status: 'completed'
        },
        {
          milestone: 'Permit Applications',
          date: '2025-03-15',
          description: 'Regulatory permits and approvals process',
          status: 'completed'
        },
        {
          milestone: 'Design Revisions',
          date: '2025-06-01',
          description: 'Project design modifications based on feedback',
          status: 'in_progress'
        },
        {
          milestone: 'Construction Phase',
          date: '2025-10-01',
          description: 'Begin wetland restoration construction',
          status: 'pending'
        }
      ]
    },
    {
      id: 4,
      name: 'Integrated Blue Carbon Initiative - Philippines',
      description: `Multi-ecosystem blue carbon project integrating mangroves, seagrass, and salt marshes.\nCovers 2,000 hectares across multiple islands in the Philippines.\nEmphasizes community-based management and sustainable livelihoods.`,
      owner: 'Philippine Department of Environment',
      ownerEmail: 'bluecarbon@denr.gov.ph',
      ecosystem: 'Mixed Ecosystems',
      location: 'Palawan, Philippines',
      area: '2,000 hectares',
      estimatedCredits: '25,000 tCO2e/year',
      status: 'approved',
      priority: 'low',
      submittedDate: '2025-07-30',
      daysInQueue: 30,
      coordinates: { lat: 9.8349, lng: 118.7384 },
      image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=300&fit=crop',
      methodology: {
        name: 'VM0033 - Methodology for Tidal Wetland and Seagrass Restoration',
        version: 'v2.0',
        description: 'Approved methodology for blue carbon ecosystem restoration and conservation'
      },
      baseline: `Baseline scenario includes continued conversion of coastal ecosystems for aquaculture and tourism development.\nProjected loss of 100 hectares annually without intervention.\nBaseline emissions estimated at 5,500 tCO2e per year from ecosystem conversion.`,
      additionality: `Project demonstrates additionality through comprehensive barrier analysis.\nLack of technical capacity and financing prevents restoration without carbon revenue.\nGovernment resources insufficient for large-scale ecosystem restoration.`,
      monitoringPlan: [
        {
          parameter: 'Multi-ecosystem Coverage',
          method: 'Satellite monitoring with field validation',
          frequency: 'Monthly',
          responsible: 'Remote Sensing Team'
        },
        {
          parameter: 'Community Livelihoods',
          method: 'Socioeconomic surveys and interviews',
          frequency: 'Quarterly',
          responsible: 'Social Development Team'
        },
        {
          parameter: 'Biodiversity Indicators',
          method: 'Species monitoring and habitat assessment',
          frequency: 'Bi-annually',
          responsible: 'Biodiversity Team'
        }
      ],
      stakeholders: [
        {
          group: 'Fishing Communities',
          role: 'Primary Beneficiaries',
          engagement: 'Participatory management and capacity building'
        },
        {
          group: 'Tourism Operators',
          role: 'Economic Partners',
          engagement: 'Sustainable tourism development initiatives'
        },
        {
          group: 'Local Government Units',
          role: 'Governance Partners',
          engagement: 'Policy coordination and implementation support'
        }
      ],
      timeline: [
        {
          milestone: 'Multi-stakeholder Planning',
          date: '2024-12-01',
          description: 'Comprehensive stakeholder engagement and planning',
          status: 'completed'
        },
        {
          milestone: 'Baseline Establishment',
          date: '2025-02-15',
          description: 'Multi-ecosystem baseline assessment',
          status: 'completed'
        },
        {
          milestone: 'Implementation Launch',
          date: '2025-05-01',
          description: 'Project implementation across all sites',
          status: 'completed'
        },
        {
          milestone: 'Mid-term Review',
          date: '2025-08-15',
          description: 'Progress assessment and adaptive management',
          status: 'completed'
        },
        {
          milestone: 'Verification Process',
          date: '2025-11-01',
          description: 'Third-party verification and credit issuance',
          status: 'in_progress'
        }
      ]
    }
  ];

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleProjectSelect = (project) => {
    setSelectedProject(project);
    if (isMobile) {
      setActiveView('details');
    }
  };

  const handleChecklistUpdate = (checklist) => {
    console.log('Checklist updated:', checklist);
  };

  const handleAnnotationAdd = (annotation) => {
    console.log('Annotation added:', annotation);
  };

  const handleVerificationSubmit = async (formData) => {
    console.log('Verification submitted:', formData);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    alert('Verification submitted successfully!');
  };

  const handleSaveProgress = (formData) => {
    console.log('Progress saved:', formData);
    alert('Progress saved successfully!');
  };

  const mobileViews = [
    { key: 'queue', label: 'Queue', icon: 'List' },
    { key: 'details', label: 'Details', icon: 'Info' },
    { key: 'documents', label: 'Documents', icon: 'FileText' },
    { key: 'form', label: 'Verification', icon: 'CheckCircle' }
  ];

  const renderMobileView = () => {
    switch (activeView) {
      case 'queue':
        return (
          <ProjectQueue
            projects={projects}
            selectedProject={selectedProject}
            onProjectSelect={handleProjectSelect}
          />
        );
      case 'details':
        return (
          <ProjectDetails project={selectedProject} />
        );
      case 'documents':
        return (
          <DocumentViewer
            project={selectedProject}
            onAnnotationAdd={handleAnnotationAdd}
          />
        );
      case 'form':
        return (
          <VerificationForm
            project={selectedProject}
            onSubmit={handleVerificationSubmit}
            onSaveProgress={handleSaveProgress}
          />
        );
      default:
        return null;
    }
  };

  return (
    <>
      <Helmet>
        <title>Verification Workflow - BlueCarbon Registry</title>
        <meta name="description" content="Systematic review and approval process for blue carbon projects by authorized verifiers" />
      </Helmet>
      <div className="min-h-screen bg-background">
        <div className="pt-16 lg:pl-60">
          <div className="p-6">
            {/* Header */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Verification Workflow</h1>
                  <p className="text-muted-foreground mt-1">
                    Review and verify blue carbon projects for credit issuance
                  </p>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="hidden sm:flex items-center space-x-2 text-sm text-muted-foreground">
                    <Icon name="Clock" size={16} />
                    <span>Last updated: {new Date()?.toLocaleTimeString()}</span>
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="RefreshCw"
                    iconPosition="left"
                    iconSize={16}
                    onClick={() => window.location?.reload()}
                  >
                    Refresh
                  </Button>
                </div>
              </div>
            </div>

            {/* Mobile Navigation */}
            {isMobile && (
              <div className="mb-6">
                <div className="flex space-x-1 bg-muted p-1 rounded-lg">
                  {mobileViews?.map(view => (
                    <Button
                      key={view?.key}
                      variant={activeView === view?.key ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setActiveView(view?.key)}
                      iconName={view?.icon}
                      iconPosition="left"
                      iconSize={16}
                      className="flex-1 text-xs"
                    >
                      {view?.label}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Desktop Layout */}
            {!isMobile ? (
              <div className="grid grid-cols-12 gap-6 h-[calc(100vh-12rem)]">
                {/* Left Panel */}
                <div className="col-span-4 space-y-6">
                  <div className="h-3/5">
                    <ProjectQueue
                      projects={projects}
                      selectedProject={selectedProject}
                      onProjectSelect={handleProjectSelect}
                    />
                  </div>
                  <div className="h-2/5">
                    <VerificationChecklist
                      project={selectedProject}
                      onChecklistUpdate={handleChecklistUpdate}
                    />
                  </div>
                </div>

                {/* Center Panel */}
                <div className="col-span-5">
                  <div className="grid grid-rows-2 gap-6 h-full">
                    <div className="row-span-1">
                      <ProjectDetails project={selectedProject} />
                    </div>
                    <div className="row-span-1">
                      <DocumentViewer
                        project={selectedProject}
                        onAnnotationAdd={handleAnnotationAdd}
                      />
                    </div>
                  </div>
                </div>

                {/* Right Panel */}
                <div className="col-span-3">
                  <VerificationForm
                    project={selectedProject}
                    onSubmit={handleVerificationSubmit}
                    onSaveProgress={handleSaveProgress}
                  />
                </div>
              </div>
            ) : (
              /* Mobile Layout */
              (<div className="h-[calc(100vh-12rem)]">
                {renderMobileView()}
              </div>)
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default VerificationWorkflow;